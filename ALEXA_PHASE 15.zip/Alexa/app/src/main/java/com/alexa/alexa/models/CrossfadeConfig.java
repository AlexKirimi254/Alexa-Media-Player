package com.alexa.alexa.models;

import android.content.Context;
import android.content.SharedPreferences;

public class CrossfadeConfig {
    private static final String PREFS_NAME = "crossfade_settings";
    private static final String KEY_ENABLED = "crossfade_enabled";
    private static final String KEY_DURATION = "crossfade_duration";

    private final int minDuration = 5000; // 5 seconds
    private final int maxDuration = 30000; // 30 seconds
    private final int defaultDuration = 10000; // 10 seconds

    private boolean enabled;
    private int duration;
    private final Context context;

    public CrossfadeConfig(Context context) {
        this.context = context;
        loadConfig();
    }

    private void loadConfig() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        enabled = prefs.getBoolean(KEY_ENABLED, false);
        duration = prefs.getInt(KEY_DURATION, defaultDuration);
    }

    public void saveConfig(Context context) {
        SharedPreferences.Editor editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        editor.putBoolean(KEY_ENABLED, enabled);
        editor.putInt(KEY_DURATION, duration);
        editor.apply();
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = Math.max(minDuration, Math.min(duration, maxDuration));
    }

    public int getMinDuration() {
        return minDuration;
    }

    public int getMaxDuration() {
        return maxDuration;
    }
}
