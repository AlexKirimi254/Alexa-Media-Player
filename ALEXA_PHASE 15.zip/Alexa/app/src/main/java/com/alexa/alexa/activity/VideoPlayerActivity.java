package com.alexa.alexa.activity;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.alexa.alexa.R;
import com.alexa.alexa.service.VideoPlaybackService;

import java.util.ArrayList;
import java.util.Collections;
import android.view.Gravity;

public class VideoPlayerActivity extends BaseActivity {

    private static final String TAG = "VideoPlayerActivity";
    private static final String PREF_PLAYBACK_MODE = "playback_mode";
    private static final int MODE_VIDEO = 0;
    private static final int MODE_AUDIO_ONLY = 1;

    private SurfaceView surfaceView;
    private ProgressBar progressBar;
    private ArrayList<String> videoList;
    private int currentIndex = 0;
    private int currentPlaybackMode;

    private AudioManager audioManager;
    private GestureDetector gestureDetector;
    private Handler progressHandler = new Handler();

    private float brightness = -1f;
    private int maxVolume;
    private int currentVolume;
    private VideoPlaybackService playbackService;
    private boolean isServiceBound = false;

    private enum ScreenMode { FIT, FILL, CROP, ORIGINAL }
    private ScreenMode currentScreenMode = ScreenMode.FIT;
    private int videoWidth, videoHeight;
    private SurfaceHolder.Callback surfaceCallback;
    private VideoOptionsMenu videoOptionsMenu;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            VideoPlaybackService.LocalBinder binder = (VideoPlaybackService.LocalBinder) service;
            playbackService = binder.getService();
            isServiceBound = true;

            if (playbackService.isPlaying() && playbackService.getVideoList() != null) {
                videoList = playbackService.getVideoList();
                currentIndex = playbackService.getCurrentIndex();
                currentPlaybackMode = playbackService.getPlaybackMode();
            } else {
                playbackService.setVideoList(videoList, currentIndex);
            }

            playbackService.setPlaybackStateListener(playbackListener);
            playbackService.setPlaybackMode(currentPlaybackMode);
            setupSurfaceView();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isServiceBound = false;
        }
    };

    private final PlaybackStateListener playbackListener = new PlaybackStateListener() {
        @Override
        public void onPlaybackStarted() {
            runOnUiThread(new Runnable() {
					@Override
					public void run() {
						progressHandler.post(progressUpdater);
						progressBar.setVisibility(View.GONE);
						updateUiForPlaybackMode();
					}
				});
        }

        @Override
        public void onPlaybackPaused() {
            runOnUiThread(new Runnable() {
					@Override
					public void run() {
						progressHandler.removeCallbacks(progressUpdater);
					}
				});
        }

        @Override
        public void onPlaybackStopped() {
            runOnUiThread(new Runnable() {
					@Override
					public void run() {
						progressHandler.removeCallbacks(progressUpdater);
						finish();
					}
				});
        }

        @Override
        public void onPlaybackCompleted() {
            runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (isServiceBound) {
							playbackService.playNextVideo();
						}
					}
				});
        }

        @Override
        public void onPlaybackError() {
            runOnUiThread(new Runnable() {
					@Override
					public void run() {
						handlePlaybackError();
					}
				});
        }

        @Override
        public void onPlaybackModeChanged(final int mode) {
            runOnUiThread(new Runnable() {
					@Override
					public void run() {
						currentPlaybackMode = mode;
						updateUiForPlaybackMode();
					}
				});
        }
    };

    private final Runnable progressUpdater = new Runnable() {
        @Override
        public void run() {
            if (isServiceBound && playbackService.isPlaying()) {
                int current = playbackService.getCurrentPosition();
                int duration = playbackService.getDuration();
                progressBar.setMax(duration);
                progressBar.setProgress(current);
                progressHandler.postDelayed(this, 1000);
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        boolean fromNotification = getIntent().getBooleanExtra("from_notification", false);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        currentPlaybackMode = prefs.getInt(PREF_PLAYBACK_MODE, MODE_VIDEO);

        surfaceView = findViewById(R.id.surfaceView);
        progressBar = findViewById(R.id.progressBar);

        setupUI();

        if (!fromNotification) {
            videoList = getIntent().getStringArrayListExtra("videoList");
            currentIndex = getIntent().getIntExtra("videoIndex", 0);
        }

        if (savedInstanceState != null) {
            currentIndex = savedInstanceState.getInt("currentIndex", 0);
            currentScreenMode = ScreenMode.values()[savedInstanceState.getInt("screenMode", ScreenMode.FIT.ordinal())];
            currentPlaybackMode = savedInstanceState.getInt("playbackMode", currentPlaybackMode);
        }

        if ((videoList == null || videoList.isEmpty()) && !fromNotification) {
            Toast.makeText(this, "No videos to play.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Intent serviceIntent = new Intent(this, VideoPlaybackService.class);
        if (!fromNotification) {
            serviceIntent.putStringArrayListExtra("videoList", videoList);
            serviceIntent.putExtra("videoIndex", currentIndex);
            serviceIntent.putExtra("playbackMode", currentPlaybackMode);
        }
        startService(serviceIntent);
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        videoOptionsMenu = new VideoOptionsMenu(this, this);
    }

    private void setupUI() {
        Button btnSkipForward = findViewById(R.id.btnSkipForward);
        Button btnSkipBackward = findViewById(R.id.btnSkipBackward);
        Button btnNext = findViewById(R.id.btnNext);
        Button btnPrevious = findViewById(R.id.btnPrevious);
        Button btnShuffle = findViewById(R.id.btnShuffle);
        Button btnScreenMode = findViewById(R.id.btnScreenMode);
        Button btnPlaybackMode = findViewById(R.id.btnPlaybackMode);
        Button btnMoreOptions = findViewById(R.id.btnMoreOptions);

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        gestureDetector = new GestureDetector(this, new GestureListener());
        surfaceView.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					return gestureDetector.onTouchEvent(event);
				}
			});

        btnSkipForward.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (isServiceBound && playbackService != null) {
						int newPos = playbackService.getCurrentPosition() + 10000;
						playbackService.seekTo(newPos);
					}
				}
			});

        btnSkipBackward.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (isServiceBound && playbackService != null) {
						int newPos = playbackService.getCurrentPosition() - 10000;
						playbackService.seekTo(Math.max(newPos, 0));
					}
				}
			});

        btnNext.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (isServiceBound && playbackService != null) {
						playbackService.playNextVideo();
					}
				}
			});

        btnPrevious.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (isServiceBound && playbackService != null) {
						playbackService.playPreviousVideo();
					}
				}
			});

        btnShuffle.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (isServiceBound && playbackService != null && videoList != null) {
						Collections.shuffle(videoList);
						currentIndex = 0;
						playbackService.setVideoList(videoList, currentIndex);
					}
				}
			});

        btnScreenMode.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showScreenModeMenu(v);
				}
			});

        btnPlaybackMode.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					togglePlaybackMode();
				}
			});

        btnMoreOptions.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					videoOptionsMenu.showMenu(v);
				}
			});

        final MediaController mediaController = new MediaController(this);
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable hideRunnable = new Runnable() {
            @Override
            public void run() {
                mediaController.hide();
            }
        };

        mediaController.setAnchorView(surfaceView);
        mediaController.setMediaPlayer(new MediaController.MediaPlayerControl() {
				@Override
				public void start() {
					if (isServiceBound && playbackService != null) {
						playbackService.resume();
					}
				}

				@Override
				public void pause() {
					if (isServiceBound && playbackService != null) {
						playbackService.pause();
					}
				}

				@Override
				public int getDuration() {
					if (isServiceBound && playbackService != null) {
						return playbackService.getDuration();
					}
					return 0;
				}

				@Override
				public int getCurrentPosition() {
					if (isServiceBound && playbackService != null) {
						return playbackService.getCurrentPosition();
					}
					return 0;
				}

				@Override
				public void seekTo(int pos) {
					if (isServiceBound && playbackService != null) {
						playbackService.seekTo(pos);
					}
				}

				@Override
				public boolean isPlaying() {
					return isServiceBound && playbackService != null && playbackService.isPlaying();
				}

				@Override
				public int getBufferPercentage() {
					return 0;
				}

				@Override
				public boolean canPause() {
					return true;
				}

				@Override
				public boolean canSeekBackward() {
					return true;
				}

				@Override
				public boolean canSeekForward() {
					return true;
				}

				@Override
				public int getAudioSessionId() {
					return 0;
				}
			});

        surfaceView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (mediaController.isShowing()) {
						mediaController.hide();
					} else {
						mediaController.show(3000);
						handler.removeCallbacks(hideRunnable);
						handler.postDelayed(hideRunnable, 3000);
					}
				}
			});
    }

    @Override
    public void onBackPressed() {
        if (currentPlaybackMode == MODE_AUDIO_ONLY && isServiceBound && playbackService.isPlaying()) {
            moveTaskToBack(true);
        } else {
            returnToFilePicker();
        }
    }

    private void returnToFilePicker() {
        if (isServiceBound && currentPlaybackMode == MODE_VIDEO) {
            playbackService.stop();
        }

        Intent intent = new Intent(this, VideoFilePickerActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        if (videoList != null) {
            intent.putStringArrayListExtra("videoList", videoList);
            intent.putExtra("videoIndex", currentIndex);
        }

        startActivity(intent);
        finish();
    }

    public void togglePlaybackMode() {
        int newMode = currentPlaybackMode == MODE_VIDEO ? MODE_AUDIO_ONLY : MODE_VIDEO;

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.edit().putInt(PREF_PLAYBACK_MODE, newMode).apply();

        if (isServiceBound) {
            playbackService.setPlaybackMode(newMode);
        }

        currentPlaybackMode = newMode;
        updateUiForPlaybackMode();
    }

    private void updateUiForPlaybackMode() {
        if (currentPlaybackMode == MODE_AUDIO_ONLY) {
            surfaceView.setVisibility(View.GONE);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            surfaceView.setVisibility(View.VISIBLE);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            applyScreenMode();
        }
    }

    private void setupSurfaceView() {
        SurfaceHolder holder = surfaceView.getHolder();
        holder.addCallback(new SurfaceHolder.Callback() {
				@Override
				public void surfaceCreated(SurfaceHolder holder) {
					if (isServiceBound && playbackService.getMediaPlayer() != null) {
						try {
							playbackService.getMediaPlayer().setDisplay(holder);
							videoWidth = playbackService.getMediaPlayer().getVideoWidth();
							videoHeight = playbackService.getMediaPlayer().getVideoHeight();

							if (videoWidth == 0 || videoHeight == 0) {
								Log.e(TAG, "Invalid video dimensions");
								handlePlaybackError();
								return;
							}

							applyScreenMode();

							if (!playbackService.isPlaying()) {
								playbackService.start();
							}
						} catch (IllegalStateException e) {
							Log.e(TAG, "Media player error", e);
							handlePlaybackError();
						}
					}
				}

				@Override
				public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
				}

				@Override
				public void surfaceDestroyed(SurfaceHolder holder) {
					if (isServiceBound && playbackService.getMediaPlayer() != null) {
						playbackService.getMediaPlayer().setDisplay(null);
					}
				}
			});
    }

    private void showScreenModeMenu(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.getMenu().add(0, 0, 0, "Fit");
        popup.getMenu().add(0, 1, 1, "Fill");
        popup.getMenu().add(0, 2, 2, "Crop");
        popup.getMenu().add(0, 3, 3, "100% (Original)");
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					switch (item.getItemId()) {
						case 0:
							currentScreenMode = ScreenMode.FIT;
							break;
						case 1:
							currentScreenMode = ScreenMode.FILL;
							break;
						case 2:
							currentScreenMode = ScreenMode.CROP;
							break;
						case 3:
							currentScreenMode = ScreenMode.ORIGINAL;
							break;
					}
					applyScreenMode();
					return true;
				}
			});
        popup.show();
    }

    private void applyScreenMode() {
        if (currentPlaybackMode == MODE_AUDIO_ONLY || videoWidth == 0 || videoHeight == 0) {
            return;
        }

        FrameLayout container = findViewById(R.id.videoContainer);
        int containerWidth = container.getWidth();
        int containerHeight = container.getHeight();

        if (containerWidth == 0 || containerHeight == 0) {
            container.post(new Runnable() {
					@Override
					public void run() {
						applyScreenMode();
					}
				});
            return;
        }

        float videoAspect = (float) videoWidth / videoHeight;
        float containerAspect = (float) containerWidth / containerHeight;

        ViewGroup.LayoutParams params = surfaceView.getLayoutParams();

        switch (currentScreenMode) {
            case FIT:
                if (videoAspect > containerAspect) {
                    params.width = containerWidth;
                    params.height = (int) (containerWidth / videoAspect);
                } else {
                    params.height = containerHeight;
                    params.width = (int) (containerHeight * videoAspect);
                }
                surfaceView.setScaleX(1f);
                surfaceView.setScaleY(1f);
                break;

            case FILL:
                if (videoAspect > containerAspect) {
                    params.height = containerHeight;
                    params.width = (int) (containerHeight * videoAspect);
                } else {
                    params.width = containerWidth;
                    params.height = (int) (containerWidth / videoAspect);
                }
                surfaceView.setScaleX(1f);
                surfaceView.setScaleY(1f);
                break;

            case CROP:
                params.width = containerWidth;
                params.height = containerHeight;
                if (videoAspect > containerAspect) {
                    float scale = (float) containerHeight / videoHeight;
                    surfaceView.setScaleX(scale * videoAspect / containerAspect);
                    surfaceView.setScaleY(scale);
                } else {
                    float scale = (float) containerWidth / videoWidth;
                    surfaceView.setScaleX(scale);
                    surfaceView.setScaleY(scale * containerAspect / videoAspect);
                }
                break;

            case ORIGINAL:
                params.width = videoWidth;
                params.height = videoHeight;
                surfaceView.setScaleX(1f);
                surfaceView.setScaleY(1f);
                break;
        }

        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) surfaceView.getLayoutParams();
        layoutParams.gravity = Gravity.CENTER;
        surfaceView.setLayoutParams(layoutParams);
        surfaceView.requestLayout();
    }

    private void handlePlaybackError() {
        Toast.makeText(this, "Error playing video", Toast.LENGTH_SHORT).show();
        if (isServiceBound) {
            playbackService.playNextVideo();
        } else {
            finish();
        }
    }

    private class GestureListener extends GestureDetector.SimpleOnGestureListener {
        private static final int SWIPE_THRESHOLD = 50;
        private float initialY;
        private float initialX;
        private boolean isVolumeControl;

        @Override
        public boolean onDown(MotionEvent e) {
            initialY = e.getY();
            initialX = e.getX();
            currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            brightness = getWindow().getAttributes().screenBrightness;
            if (brightness < 0) {
                try {
                    int systemBrightness = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
                    brightness = systemBrightness / 255f;
                } catch (Settings.SettingNotFoundException ex) {
                    brightness = 0.5f;
                }
            }
            isVolumeControl = initialX > surfaceView.getWidth() / 2;
            return true;
        }

        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            float deltaY = e1.getY() - e2.getY();
            float percentChange = deltaY / surfaceView.getHeight();

            if (isVolumeControl) {
                int deltaVolume = (int) (percentChange * maxVolume);
                int newVolume = Math.min(Math.max(currentVolume + deltaVolume, 0), maxVolume);
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0);
            } else {
                float newBrightness = Math.min(Math.max(brightness + percentChange, 0f), 1f);
                WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
                layoutParams.screenBrightness = newBrightness;
                getWindow().setAttributes(layoutParams);
            }
            return true;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("currentIndex", currentIndex);
        outState.putInt("screenMode", currentScreenMode.ordinal());
        outState.putInt("playbackMode", currentPlaybackMode);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (currentPlaybackMode == MODE_VIDEO) {
            applyScreenMode();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isServiceBound && !playbackService.isPlaying()) {
            playbackService.resume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (currentPlaybackMode == MODE_AUDIO_ONLY && isServiceBound && playbackService.isPlaying()) {
            moveTaskToBack(true);
        } else if (isServiceBound) {
            playbackService.pause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isServiceBound && currentPlaybackMode != MODE_AUDIO_ONLY) {
            unbindService(connection);
        }
    }

    public interface PlaybackStateListener {
        void onPlaybackStarted();
        void onPlaybackPaused();
        void onPlaybackStopped();
        void onPlaybackCompleted();
        void onPlaybackError();
        void onPlaybackModeChanged(int mode);
    }
}
