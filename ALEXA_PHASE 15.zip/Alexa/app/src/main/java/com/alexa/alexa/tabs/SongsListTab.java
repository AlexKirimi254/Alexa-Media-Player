
package com.alexa.alexa.tabs;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.SongListAdapter;
import com.alexa.alexa.helper.SortOrder;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.view.tabview.Tab;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import java.util.List;
import com.alexa.alexa.library.SongRetreiverCursor;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.menu.AddToPlaylistDialog;

public class SongsListTab extends Tab {
    private static final String PREFS_NAME = "AppPrefs";
    private static final String GRID_SIZE_KEY = "grid_size";
    private static final String SORT_ORDER_KEY = "sort_order";

    private View root;
    private RecyclerView recyclerView;
    private SongListAdapter adapter;
    private MainActivity act;
    private List<SongItem> songList;
    private SongItem currentSong;
    private boolean isMultiSelectEnabled = false;
    private int gridSize = 2;
    private String currentSortOrder = SortOrder.SongSortOrder.SONG_A_Z;

    public SongsListTab(MainActivity ctx) {
        this.act = ctx;
        this.root = LayoutInflater.from(ctx).inflate(R.layout.default_recyclerview, null, false);
        this.recyclerView = root.findViewById(R.id.recycler_view);
        this.adapter = new SongListAdapter(ctx);
        this.recyclerView.setAdapter(adapter);

        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gridSize = prefs.getInt(GRID_SIZE_KEY, 2);
        currentSortOrder = prefs.getString(SORT_ORDER_KEY, SortOrder.SongSortOrder.SONG_A_Z);

        setGridSize(gridSize);
        loadSongs();

        adapter.setOnItemClickListener(new SongListAdapter.OnItemClickListener() {
				@Override
				public void onItemClick(SongItem songItem) {
					if (isMultiSelectEnabled) {
						adapter.toggleSelection(songItem);
					} else {
						
						//SongItem si = (SongItem) v.getTag();
						AudioService aupod = App.get().getAudioService();
						if(aupod!=null){
							aupod.playSong(songItem);
							
							AudioService.getInstance().clearQueue();
							QueueManager.getInstance().clearQueue();
							AudioService.getInstance().addToQueue(songItem);
							QueueManager.getInstance().addSongToQueue(songItem);	
						}
						
						
					}
				}

				@Override
				public void onItemLongClick(SongItem songItem, boolean enableMultiSelect) {
					isMultiSelectEnabled = enableMultiSelect;
					adapter.enableMultiSelect(true);
					adapter.toggleSelection(songItem);
					showBottomSheet();
				}
			});
    }

    public void setSortOrder(String sortOrder) {
        this.currentSortOrder = sortOrder;
        SharedPreferences prefs = act.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(SORT_ORDER_KEY, currentSortOrder).apply();
        loadSongs();
    }

    private void loadSongs() {
        songList = SongRetreiverCursor.get(act, currentSortOrder);
        adapter.update(songList);
    }

    public void setGridSize(int size) {
        this.gridSize = size;
        recyclerView.setLayoutManager(new GridLayoutManager(act, gridSize));
        SharedPreferences prefs = act.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(GRID_SIZE_KEY, gridSize).apply();
    }

    public int getGridSize() {
        return gridSize;
    }

    public String getSortOrder() {
        return currentSortOrder;
    }

    @Override
    public View getView() {
        return root;
    }

    public void update(Context ctx, String sortOrder) {
        songList = SongRetreiverCursor.get(ctx, sortOrder);
        adapter.update(songList);
    }

    public void setCurrent(SongItem currentSong) {
        this.currentSong = currentSong;
        adapter.setCurrent(currentSong);
    }

    public void showCurrent() {
        if (currentSong != null) {
            int position = adapter.getPos(currentSong);
            if (position != -1) {
                recyclerView.scrollToPosition(position);
            }
        }
    }

    public void clearMultiSelection() {
        isMultiSelectEnabled = false;
        adapter.enableMultiSelect(false);
    }

    public List<SongItem> getSelectedSongs() {
        return adapter.getSelectedSongs();
    }

    private void showBottomSheet() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(act);
        View sheetView = LayoutInflater.from(act).inflate(R.layout.bottom_sheet_song_options, null);

        sheetView.findViewById(R.id.option_play_next).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					for (SongItem song : getSelectedSongs()) {
						AudioService.getInstance().addToQueue(song);
						QueueManager.getInstance().addSongToQueue(song);
						
					}
					clearMultiSelection();
					bottomSheetDialog.dismiss();
				}
			});

        sheetView.findViewById(R.id.option_add_to_playlist).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					List<SongItem> selectedSongs = getSelectedSongs();
					if (selectedSongs != null && !selectedSongs.isEmpty()) {
						AddToPlaylistDialog dialog = new AddToPlaylistDialog(act, selectedSongs, new AddToPlaylistDialog.OnPlaylistAddListener() {
								@Override
								public void onPlaylistAddSuccess() {
									clearMultiSelection();
								}
							});
						dialog.show();
					}
					bottomSheetDialog.dismiss();
				}
			});

        sheetView.findViewById(R.id.option_edit_tags).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Tag editing functionality here
					bottomSheetDialog.dismiss();
				}
			});

        sheetView.findViewById(R.id.option_delete).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Deletion functionality here
					bottomSheetDialog.dismiss();
				}
			});

        bottomSheetDialog.setContentView(sheetView);
        bottomSheetDialog.show();
    }
}

