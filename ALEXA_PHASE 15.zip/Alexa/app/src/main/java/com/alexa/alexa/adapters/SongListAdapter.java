package com.alexa.alexa.adapters;

import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.menu.SongOptions;
import com.alexa.alexa.models.SongItem;
import java.util.ArrayList;
import java.util.List;
import com.alexa.alexa.ThemeManager.Theme;

public class SongListAdapter extends RecyclerView.Adapter<SongListAdapter.SongViewHolder> {

    private List<SongItem> songList = new ArrayList<>();
    private final MainActivity ctx;
    private final List<SongItem> selectedSongs = new ArrayList<>();
    private boolean multiSelectEnabled = false;
    private OnItemClickListener listener;

	private SongItem currentSong;

    private ThemeManager.Theme currentTheme;

    public interface OnItemClickListener {
        void onItemClick(SongItem songItem);

        void onItemLongClick(SongItem songItem, boolean enableMultiSelect);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public SongListAdapter(MainActivity ctx) {
        this.ctx = ctx;
    }

    public void update(List<SongItem> list) {
        this.songList = list;
        notifyDataSetChanged();
    }
	public void setCurrent(SongItem songitem)
    {
        this.currentSong = songitem;
        notifyDataSetChanged();
    }
	public int getPos(SongItem si)
    {
        return songList.indexOf(si);
    }
    public void toggleSelection(SongItem songItem) {
        if (selectedSongs.contains(songItem)) {
            selectedSongs.remove(songItem);
        } else {
            selectedSongs.add(songItem);
        }
        notifyDataSetChanged();
    }

    public void clearSelection() {
        selectedSongs.clear();
        notifyDataSetChanged();
    }

    public List<SongItem> getSelectedSongs() {
        return selectedSongs;
    }

    public void enableMultiSelect(boolean enable) {
        multiSelectEnabled = enable;
        if (!enable) {
            clearSelection();
        }
    }
    public void setTheme(ThemeManager.Theme theme) {
        this.currentTheme = theme;
        notifyDataSetChanged();
    }
    @Override
    public SongViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.adapteritem_song, parent, false);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SongViewHolder holder, int position) {
        final SongItem item = songList.get(position);

        holder.title.setText(item.title);
        holder.artist.setText(item.artist);

		// Highlight selected items
        if (selectedSongs.contains(item)) {
            holder.itemView.setBackgroundColor(ctx.getResources().getColor(R.color.black));
        } else {
            holder.itemView.setBackgroundColor(ctx.getResources().getColor(android.R.color.transparent));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (multiSelectEnabled) {
                        toggleSelection(item);
                    } else if (listener != null) {
                        listener.onItemClick(item);
                    }
                }
            });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (listener != null) {
                        listener.onItemLongClick(item, true);
                    }
                    return true;
                }
            });

        if (item.getIconPath() != null) {
            holder.art.setBackground(new BitmapDrawable(ctx.getResources(), item.getThumbnail()));
        }

        holder.moreButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new SongOptions(ctx, item).show();
                }
            });
    }

    @Override
    public int getItemCount() {
        return songList.size();
    }

    static class SongViewHolder extends RecyclerView.ViewHolder {
        TextView title, artist;
        ImageView art;
        View moreButton;

        public SongViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.songslist_item_title);
            artist = itemView.findViewById(R.id.songslist_item_artist);
            art = itemView.findViewById(R.id.songslist_item_albumart);
            moreButton = itemView.findViewById(R.id.songslist_item_more_icon);
        }
    }
}

