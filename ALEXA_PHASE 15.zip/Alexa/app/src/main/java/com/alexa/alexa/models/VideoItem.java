package com.alexa.alexa.models;

import android.os.Parcel;
import android.os.Parcelable;

public class VideoItem implements MediaItem, Parcelable {
    private String path;
    private String title;
    private long duration;
    private long size;
    private long dateAdded;
    private String id;  // Added for media browsing compatibility

    public VideoItem() {
        // Default constructor
    }

    public VideoItem(String path, String title, long duration, long size, long dateAdded) {
        this.path = path;
        this.title = title;
        this.duration = duration;
        this.size = size;
        this.dateAdded = dateAdded;
        this.id = String.valueOf(path.hashCode());  // Generate ID from path
    }

    // Parcelable implementation
    protected VideoItem(Parcel in) {
        path = in.readString();
        title = in.readString();
        duration = in.readLong();
        size = in.readLong();
        dateAdded = in.readLong();
        id = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(path);
        dest.writeString(title);
        dest.writeLong(duration);
        dest.writeLong(size);
        dest.writeLong(dateAdded);
        dest.writeString(id);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<VideoItem> CREATOR = new Creator<VideoItem>() {
        @Override
        public VideoItem createFromParcel(Parcel in) {
            return new VideoItem(in);
        }

        @Override
        public VideoItem[] newArray(int size) {
            return new VideoItem[size];
        }
    };

    // Getters
    public String getPath() { return path; }
    public String getTitle() { return title; }
    public long getDuration() { return duration; }
    public long getSize() { return size; }
    public long getDateAdded() { return dateAdded; }
    public String getId() { return id; }  // From MediaItem interface

    // Setters (added for media browsing compatibility)
    public void setPath(String path) { 
        this.path = path;
        this.id = String.valueOf(path.hashCode());
    }
    public void setTitle(String title) { this.title = title; }
    public void setDuration(long duration) { this.duration = duration; }
    public void setSize(long size) { this.size = size; }
    public void setDateAdded(long dateAdded) { this.dateAdded = dateAdded; }
    public void setId(String id) { this.id = id; }  // From MediaItem interface

    // Formatted duration for display
    public String getFormattedDuration() {
        long seconds = duration / 1000;
        long minutes = seconds / 60;
        seconds = seconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    // Formatted size for display
    public String getFormattedSize() {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024));
        return String.format("%.1f GB", size / (1024.0 * 1024 * 1024));
    }
}
