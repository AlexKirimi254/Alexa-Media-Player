package com.alexa.alexa.activityAdapters;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;
import java.util.List;

public class PlaylistsActivitySongsAdapter extends BaseAdapter {

    /**
     * Callback interface for when the user chooses to delete a song.
     */
    public interface OnSongDeleteListener {
        /**
         * @param song     The SongItem to delete.
         * @param position The position in the adapter’s list.
         */
        void onSongDelete(SongItem song, int position);
    }

    private Context context;
    private List<SongItem> songList;
    private SongItem currentSong;
    private OnSongDeleteListener deleteListener;

    public PlaylistsActivitySongsAdapter(Context context, List<SongItem> songList) {
        this.context = context;
        this.songList = songList;
    }

    /** Register a listener to be called when “Delete” is tapped */
    public void setOnSongDeleteListener(OnSongDeleteListener listener) {
        this.deleteListener = listener;
    }

    @Override
    public int getCount() {
        return songList.size();
    }

    @Override
    public Object getItem(int position) {
        return songList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /** Call this from the activity after persistence succeeds to update the UI */
    public void removeSongAt(int position) {
        songList.remove(position);
        notifyDataSetChanged();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                .inflate(R.layout.songlist_item, parent, false);
        }

        final SongItem song = songList.get(position);

        TextView titleView  = convertView.findViewById(R.id.songlist_itemTitle);
        TextView artistView = convertView.findViewById(R.id.songlist_itemArtist);
        ImageView optionsView = convertView.findViewById(R.id.songlist_items_more_icon);

        titleView.setText(song.getTitle());
        artistView.setText(song.getArtist());

        // Show popup menu on “more” icon click
        optionsView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showPopupMenu(v, song, position);
				}
			});

        return convertView;
    }

    private void showPopupMenu(View view, final SongItem song, final int position) {
        PopupMenu popupMenu = new PopupMenu(context, view);
        popupMenu.inflate(R.menu.song_options_menu);

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					switch (item.getItemId()) {
						case R.id.menu_play_next:
							// your existing logic...
							return true;
						case R.id.menu_add_to_playlist:
							// your existing logic...
							return true;
						case R.id.menu_delete:
							if (deleteListener != null) {
								deleteListener.onSongDelete(song, position);
							}

							return true;
						default:
							return false;
					}
				}
			});

        popupMenu.show();
    }

    /** Optional: keep track of which song is “current” for highlighting */
    public void setCurrentSong(SongItem song) {
        this.currentSong = song;
    }
}


