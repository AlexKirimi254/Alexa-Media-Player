package com.alexa.alexa;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import com.alexa.alexa.R;
import com.alexa.alexa.utils.Utils;
import com.google.android.material.card.MaterialCardView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;
import com.alexa.alexa.adapters.ArtistListAdapter;
import com.alexa.alexa.models.ArtistItem;
import com.alexa.alexa.models.AlbumItem;
import android.widget.ListView;

public class ThemeManager {
    private static ThemeManager deft;
    private static Theme ctheme;

    private File themeFile;
    private String dir;

    final private static String TAG = "ThemeManager";
    private String key_bg = "background", 
    key_text = "text",
    key_icon = "icons",
    key_div = "dividers";

    private static final String ACCENT_PREF = "com.alexa.alexa.pref_accent";
    private static final String ACCENT_VALUE = "com.alexa.alexa.pref_accent_value";
    private static final String THEME_PREF = "com.alexa.alexa.pref_theme";
    private static final String THEME_VALUE = "com.alexa.alexa.pref_theme_value";
    private static final String SEARCH_BAR_PREF = "com.alexa.alexa.pref_search_bar";
    private static final String SEARCH_BAR_VALUE = "com.alexa.alexa.pref_search_bar_value";

    private static String KEY_ACCENT_COLOR;

    private static String PREFS_NAME;

    public static boolean isMarshmallow() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    public static void setCardStroke(@NonNull final Context context, @NonNull final MaterialCardView container, final int color) {
        container.setStrokeWidth(context.getResources().getDimensionPixelSize(R.dimen.selected_card_stroke_width));
        container.setStrokeColor(color);
    }

    public static void indexArtistAlbums(@NonNull final List<AlbumItem> albums) {
        try {
            for (int i = 0; i < albums.size(); i++) {
                albums.get(i).setId(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Spanned buildSpanned(@NonNull final String res) {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.N ?
            Html.fromHtml(res, Html.FROM_HTML_MODE_LEGACY) :
            Html.fromHtml(res);
    }

    public static void invertTheme(@NonNull final Activity activity) {
        final boolean isDark = isThemeInverted(activity);
        final boolean value = !isDark;
        final SharedPreferences preferences = activity.getSharedPreferences(THEME_PREF, Context.MODE_PRIVATE);
        preferences.edit().putBoolean(THEME_VALUE, value).apply();
        activity.recreate();
    }

    public static boolean isThemeInverted(@NonNull final Context context) {
        boolean isThemeInverted;
        try {
            isThemeInverted = context.getSharedPreferences(THEME_PREF, Context.MODE_PRIVATE).getBoolean(THEME_VALUE, false);
        } catch (Exception e) {
            e.printStackTrace();
            isThemeInverted = false;
        }
        return isThemeInverted;
    }



    public static int getColorFromResource(@NonNull final Context context, final int resource, final int emergencyColor) {
        int color;
        try {
            color = ContextCompat.getColor(context, resource);
        } catch (Exception e) {
            color = ContextCompat.getColor(context, emergencyColor);
        }
        return color;
    }


    private ThemeManager() {
        dir = App.getAppDirectory() + "theme/";
        themeFile = new File(dir + "/default");
        themeFile.getParentFile().mkdirs();
        ctheme = new Theme();
    }

    private static ThemeManager get() {
        if (deft == null) {
            deft = ThemeManager.deft = new ThemeManager();
        }
        return deft;
    }

    public static Theme getTheme() {
        return get().igetTheme();
    }

    private Theme igetTheme() {
        if (ctheme == null) {
            reloadTheme();
        } else {
            File fl = new File(themeFile.getAbsolutePath());
            if (fl.lastModified() != ctheme.lastmod) {
                reloadTheme();
            }
        }
        return ctheme;
    }

    private Theme reloadTheme() {
        if (themeFile.exists()) {
            ctheme = fromFile(themeFile.getAbsolutePath());
        } else {
            ctheme = newDefault(themeFile.getAbsolutePath());
        }
        return ctheme;
    }

    private Theme fromFile(String path) {
        String json = Utils.readTextFile(path);
        JSONObject o = null;
        try {
            o = new JSONObject(json);
        } catch (JSONException e) {
            XApp.logConsumableException(TAG, e);
        }
        ctheme.background = ttc(o, key_bg, "#ffffff");
        ctheme.text = ttc(o, key_text, "#082B56");
        ctheme.icon = ttc(o, key_icon, "#082B56");
        ctheme.dividers = ttc(o, key_div, "#D7D7D7");

        ctheme.lastmod = new File(path).lastModified();
        return ctheme;
    }

    private Theme newDefault(String path) {
        new File(path).getParentFile().mkdirs();
        JSONObject o = new JSONObject();
        try {
            o.put(key_bg, "#ffffff");
            o.put(key_text, "#082B56");
            o.put(key_icon, "#082b56");
            o.put(key_div, "#D7D7D7");
        } catch (JSONException e) {
            XApp.logConsumableException(TAG, e);
        }
        Utils.touch(path, o.toString());
        return fromFile(path);
    }

    private int ttc(JSONObject o, String key, String fallback) {
        int col = Color.parseColor(fallback);
        try {
            col = Color.parseColor(o.getString(key));
            if (!isColorVisible(col)) { // Ensure color visibility
                col = Color.parseColor(fallback);
            }
        } catch (JSONException e) {
            col = Color.parseColor(fallback);
            XApp.logConsumableException(TAG, e);
        } catch (Exception x) {
            col = Color.parseColor(fallback);
            XApp.logConsumableException(TAG, x);
        }
        return col;
    }

    private boolean isColorVisible(int color) {
        // Check brightness and contrast; adjust these thresholds as needed
        double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255;
        return darkness < 0.5; // More than 50% brightness is considered visible
    }

    public void setTheme(Theme theme) {
        if (theme != null) {
            ctheme = theme;
            saveThemeToFile();
        }
    }

    private void saveThemeToFile() {
        JSONObject o = new JSONObject();
        try {
            o.put(key_bg, String.format("#%06X", (0xFFFFFF & ctheme.background)));
            o.put(key_text, String.format("#%06X", (0xFFFFFF & ctheme.text)));
            o.put(key_icon, String.format("#%06X", (0xFFFFFF & ctheme.icon)));
            o.put(key_div, String.format("#%06X", (0xFFFFFF & ctheme.dividers)));
        } catch (JSONException e) {
            XApp.logConsumableException(TAG, e);
        }
        Utils.touch(themeFile.getAbsolutePath(), o.toString());
    }





    public static class Theme {
        public int background =0;// R.color.white;
        public int text = 0;
        public int icon =0;//R.color.white ;
        public int dividers = 0;//R.color.white;
        public long lastmod = 0;
        public long title = 0;
        public long artist = 0;
    }


    public static void setThemeAccent(@NonNull final Activity activity, final int accent) {
        final SharedPreferences preferences = activity.getSharedPreferences(ACCENT_PREF, Context.MODE_PRIVATE);
        preferences.edit().putInt(ACCENT_VALUE, accent).apply();
        activity.recreate();
    }

    public static int getAccent(@NonNull final Context context) {
        int accent;
        try {
            accent = context.getSharedPreferences(ACCENT_PREF, Context.MODE_PRIVATE).getInt(ACCENT_VALUE, R.color.white);
        } catch (Exception e) {
            e.printStackTrace();
            accent = R.color.white;
            //if resource is not found, it means the developer changed resources names
            //when updating the app. This way, we will fix the preference
            final SharedPreferences preferences = context.getSharedPreferences(ACCENT_PREF, Context.MODE_PRIVATE);
            preferences.edit().putInt(ACCENT_VALUE, accent).apply();
        }
        return accent;
    }

    public static void hideSearchToolbar(@NonNull final Activity activity) {
        final boolean isVisible = isSearchBarVisible(activity);
        final boolean newVisibility = !isVisible;
        final SharedPreferences preferences = activity.getSharedPreferences(SEARCH_BAR_PREF, Context.MODE_PRIVATE);
        preferences.edit().putBoolean(SEARCH_BAR_VALUE, newVisibility).apply();
        activity.recreate();
    }

    public static boolean isSearchBarVisible(@NonNull final Context context) {
        boolean isSearchBarHidden;
        try {
            isSearchBarHidden = context.getSharedPreferences(SEARCH_BAR_PREF, Context.MODE_PRIVATE).getBoolean(SEARCH_BAR_VALUE, true);
        } catch (Exception e) {
            e.printStackTrace();
            isSearchBarHidden = false;
        }
        return isSearchBarHidden;
    }

    public static void updateTextView(@NonNull final TextView textView, @NonNull final String text) {
        textView.post(new Runnable() {
                @Override
                public void run() {
                    textView.setText(text);
                }
            });
    }

    public static void setupSearch(@NonNull final SearchView searchView, @NonNull final ArtistListAdapter artistsAdapter, @NonNull final List<ArtistItem> artists, @NonNull final ListView indexBarRecyclerView) {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    processQuery(newText, artistsAdapter, artists);
                    return false;
                }
            });

        searchView.setOnQueryTextFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    //indexBarRecyclerView.setIndexingEnabled(!hasFocus);
                }
            });
    }
    private static void processQuery(@NonNull final String query, @NonNull final ArtistListAdapter artistsAdapter, @NonNull final List<ArtistItem> artists) {
        // in real app you'd have it instantiated just once
        final List<ArtistItem> result = new ArrayList<>();

        try {
            // case insensitive search
            for (ArtistItem artist : artists) {
                if (artist.getName().toLowerCase().startsWith(query.toLowerCase())) {
                    result.add(artist);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (result.size() > 0) {
            artistsAdapter.update(result);
        }
    }
    public static void setTheme(@NonNull final Activity activity, final boolean isThemeInverted, final int accent) {
        final int theme = resolveTheme(isThemeInverted, accent);
        activity.setTheme(theme);
    }

    private static int resolveTheme(final boolean isThemeDark, final int accent) {

        int selectedTheme = 0;

        switch (accent) {

				/*     case R.color.black:
				 selectedTheme = isThemeDark ? R.style. : R.style.AppThemeRed;
				 break;

				 case R.color.pink:
				 selectedTheme = isThemeDark ? R.style.AppThemePinkInverted : R.style.AppThemePink;
				 break;

				 case R.color.purple:
				 selectedTheme = isThemeDark ? R.style.AppThemePurpleInverted : R.style.AppThemePurple;
				 break;

				 case R.color.deep_purple:
				 selectedTheme = isThemeDark ? R.style.AppThemeDeepPurpleInverted : R.style.AppThemeDeepPurple;
				 break;

				 case R.color.indigo:
				 selectedTheme = isThemeDark ? R.style.AppThemeIndigoInverted : R.style.AppThemeIndigo;
				 break;

				 case R.color.blue:
				 selectedTheme = isThemeDark ? R.style.AppThemeBlueInverted : R.style.AppThemeBlue;
				 break;

				 default:
				 case R.color.light_blue:
				 selectedTheme = isThemeDark ? R.style.AppThemeLightBlueInverted : R.style.AppThemeLightBlue;
				 break;

				 case R.color.cyan:
				 selectedTheme = isThemeDark ? R.style.AppThemeCyanInverted : R.style.AppThemeCyan;
				 break;

				 case R.color.teal:
				 selectedTheme = isThemeDark ? R.style.AppThemeTealInverted : R.style.AppThemeTeal;
				 break;

				 case R.color.green:
				 selectedTheme = isThemeDark ? R.style.AppThemeGreenInverted : R.style.AppThemeGreen;
				 break;

				 case R.color.amber:
				 selectedTheme = isThemeDark ? R.style.AppThemeAmberInverted : R.style.AppThemeAmber;
				 break;

				 case R.color.orange:
				 selectedTheme = isThemeDark ? R.style.AppThemeOrangeInverted : R.style.AppThemeOrange;
				 break;

				 case R.color.deep_orange:
				 selectedTheme = isThemeDark ? R.style.AppThemeDeepOrangeInverted : R.style.AppThemeDeepOrange;
				 break;

				 case R.color.brown:
				 selectedTheme = isThemeDark ? R.style.AppThemeBrownInverted : R.style.AppThemeBrown;
				 break;

				 case R.color.gray:
				 selectedTheme = isThemeDark ? R.style.AppThemeGrayLightInverted : R.style.AppThemeGrayLight;
				 break;

				 case R.color.blue_gray:
				 selectedTheme = isThemeDark ? R.style.AppThemeBlueGrayInverted : R.style.AppThemeBlueGray;
				 break;*/
        }
        return selectedTheme;
    }

}
