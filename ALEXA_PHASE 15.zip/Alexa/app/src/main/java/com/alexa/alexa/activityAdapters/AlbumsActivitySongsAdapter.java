package com.alexa.alexa.activityAdapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;

import java.util.List;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.service.AudioService;

public class AlbumsActivitySongsAdapter extends BaseAdapter {

    private Context context;
    private List<SongItem> songList;
    private SongItem currentSong;

    public AlbumsActivitySongsAdapter(Context context, List<SongItem> songList) {
        this.context = context;
        this.songList = songList;
    }

    @Override
    public int getCount() {
        return songList.size();
    }

    @Override
    public Object getItem(int position) {
        return songList.get(position);
    }

    public void setCurrentSong(SongItem song) {
        this.currentSong = song;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.songlist_item, parent, false);
        }

        final SongItem song = songList.get(position);

        TextView titleView = convertView.findViewById(R.id.songlist_itemTitle);
        TextView artistView = convertView.findViewById(R.id.songlist_itemArtist);
        ImageView optionsView = convertView.findViewById(R.id.songlist_items_more_icon); // Add this ImageView to your layout.

        titleView.setText(song.getTitle());
        artistView.setText(song.getArtist());

      /*  if (currentSong != null && song.equals(currentSong)) {
            convertView.setBackgroundColor(context.getResources().getColor(R.color.colorPrimary));
        } else {
            convertView.setBackgroundColor(context.getResources().getColor(R.color.abc_background_cache_hint_selector_material_light));
        }
*/
        // Set up options menu
        optionsView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showPopupMenu(v, song);
				}
			});

        return convertView;
    }

    private void showPopupMenu(View view, final SongItem song) {
        PopupMenu popupMenu = new PopupMenu(context, view);
        popupMenu.inflate(R.menu.song_options_menu); // Define this menu in res/menu/song_options_menu.xml

        // Handle menu item clicks
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					switch (item.getItemId()) {
						case R.id.menu_play_next:
							Toast.makeText(context, "Play next: " + song.getTitle(), Toast.LENGTH_SHORT).show();
							
							QueueManager.getInstance().addSongToQueue(song);
							AudioService.getInstance().addToQueue(song);
							return true;
						case R.id.menu_add_to_playlist:
							Toast.makeText(context, "Add to playlist: " + song.getTitle(), Toast.LENGTH_SHORT).show();
							return true;
						case R.id.menu_delete:
							Toast.makeText(context, "Delete: " + song.getTitle(), Toast.LENGTH_SHORT).show();
							return true;
						default:
							return false;
					}
				}
			});

        popupMenu.show();
    }
}
