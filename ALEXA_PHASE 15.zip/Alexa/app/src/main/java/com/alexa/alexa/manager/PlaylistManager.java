package com.alexa.alexa.manager;




import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Singleton class to manage playlists with persistence.
 */
public class PlaylistManager {
    private static final String TAG = "PlaylistManager";
    private static final String PREFS_NAME = "playlists_prefs";
    private static final String KEY_PLAYLISTS = "playlists_key";

    private static PlaylistManager instance;
    private SharedPreferences sharedPreferences;
    private Gson gson;
    private List<Playlist> playlists;

    /**
     * Private constructor to enforce Singleton pattern.
     *
     * @param context Application context for SharedPreferences.
     */
    private PlaylistManager(Context context) {
        sharedPreferences = context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
        playlists = loadPlaylists();
    }

    /**
     * Initializes the PlaylistManager singleton instance.
     * This should be called once, preferably in the Application class or MainActivity.
     *
     * @param context Application context.
     */
    public static synchronized void initialize(Context context) {
        if (instance == null) {
            instance = new PlaylistManager(context);
            Log.d(TAG, "PlaylistManager instance created and initialized.");
        }
    }

    /**
     * Returns the singleton instance of PlaylistManager.
     *
     * @return The PlaylistManager instance.
     * @throws IllegalStateException if the manager is not initialized.
     */
    public static synchronized PlaylistManager getInstance() {
        if (instance == null) {
            throw new IllegalStateException("PlaylistManager is not initialized, call initialize() first.");
        }
        return instance;
    }

    /**
     * Retrieves a copy of the list of all playlists.
     *
     * @return A new List containing all playlists.
     */
    public synchronized List<Playlist> getPlaylists() {
        return new ArrayList<>(playlists);
    }

    /**
     * Creates a new playlist with the specified name.
     *
     * @param name The name of the new playlist.
     * @return The newly created Playlist object, or null if creation failed.
     */
    public synchronized Playlist createPlaylist(String name) {
        if (name == null || name.trim().isEmpty()) {
            Log.e(TAG, "Failed to create playlist: Name is null or empty.");
            return null;
        }

        // Check for duplicate playlist names (case-insensitive)
        for (Playlist p : playlists) {
            if (p.getName().equalsIgnoreCase(name.trim())) {
                Log.e(TAG, "Failed to create playlist: '" + name + "' already exists.");
                return null;
            }
        }

        Playlist newPlaylist = new Playlist(name.trim());
        playlists.add(newPlaylist);
        savePlaylists();
        Log.d(TAG, "Playlist created: " + newPlaylist.getName());
        return newPlaylist;
    }

    /**
     * Deletes the playlist with the specified name.
     *
     * @param name The name of the playlist to delete.
     * @return True if deletion was successful, false otherwise.
     */
    public synchronized boolean deletePlaylist(String name) {
        if (name == null || name.trim().isEmpty()) {
            Log.e(TAG, "Failed to delete playlist: Name is null or empty.");
            return false;
        }

        for (int i = 0; i < playlists.size(); i++) {
            Playlist p = playlists.get(i);
            if (p.getName().equalsIgnoreCase(name.trim())) {
                playlists.remove(i);
                savePlaylists();
                Log.d(TAG, "Playlist deleted: " + p.getName());
                return true;
            }
        }

        Log.e(TAG, "Failed to delete playlist: '" + name + "' not found.");
        return false;
    }

    /**
     * Adds a song to the specified playlist.
     *
     * @param playlistName The name of the playlist.
     * @param song         The SongItem to add.
     * @return True if the song was added successfully, false otherwise.
     */
    public synchronized boolean addSongToPlaylist(String playlistName, SongItem song) {
        if (playlistName == null || playlistName.trim().isEmpty()) {
            Log.e(TAG, "Failed to add song: Playlist name is null or empty.");
            return false;
        }

        if (song == null) {
            Log.e(TAG, "Failed to add song: SongItem is null.");
            return false;
        }

        for (Playlist p : playlists) {
            if (p.getName().equalsIgnoreCase(playlistName.trim())) {
                boolean added = p.addSong(song);
                if (added) {
                    savePlaylists();
                    Log.d(TAG, "Song '" + song.getTitle() + "' added to playlist '" + p.getName() + "'.");
                } else {
                    Log.e(TAG, "Failed to add song: Song already exists in playlist.");
                }
                return added;
            }
        }

        Log.e(TAG, "Failed to add song: Playlist '" + playlistName + "' not found.");
        return false;
    }

    /**
     * Removes a song from the specified playlist.
     *
     * @param playlistName The name of the playlist.
     * @param song         The SongItem to remove.
     * @return True if the song was removed successfully, false otherwise.
     */
    public synchronized boolean removeSongFromPlaylist(String playlistName, SongItem song) {
        if (playlistName == null || playlistName.trim().isEmpty()) {
            Log.e(TAG, "Failed to remove song: Playlist name is null or empty.");
            return false;
        }

        if (song == null) {
            Log.e(TAG, "Failed to remove song: SongItem is null.");
            return false;
        }

        for (Playlist p : playlists) {
            if (p.getName().equalsIgnoreCase(playlistName.trim())) {
                boolean removed = p.removeSong(song);
                if (removed) {
                    savePlaylists();
                    Log.d(TAG, "Song '" + song.getTitle() + "' removed from playlist '" + p.getName() + "'.");
                } else {
                    Log.e(TAG, "Failed to remove song: '" + song.getTitle() + "' does not exist in playlist '" + p.getName() + "'.");
                }
                return removed;
            }
        }

        Log.e(TAG, "Failed to remove song: Playlist '" + playlistName + "' not found.");
        return false;
    }

    /**
     * Retrieves a specific playlist by its name.
     *
     * @param name The name of the playlist.
     * @return The Playlist object if found, null otherwise.
     */
    public synchronized Playlist getPlaylistByName(String name) {
        if (name == null || name.trim().isEmpty()) {
            Log.e(TAG, "Failed to retrieve playlist: Name is null or empty.");
            return null;
        }

        for (Playlist p : playlists) {
            if (p.getName().equalsIgnoreCase(name.trim())) {
                return p;
            }
        }

        Log.e(TAG, "Failed to retrieve playlist: '" + name + "' not found.");
        return null;
    }

    /**
     * Sorts the playlists alphabetically by their names.
     */
    public synchronized void sortPlaylistsAlphabetically() {
        Collections.sort(playlists, new Comparator<Playlist>() {
                @Override
                public int compare(Playlist p1, Playlist p2) {
                    return p1.getName().compareToIgnoreCase(p2.getName());
                }
            });
        savePlaylists();
        Log.d(TAG, "Playlists sorted alphabetically.");
    }

    /**
     * Sorts the playlists by their creation date.
     */
    public synchronized void sortPlaylistsByCreationDate() {
        Collections.sort(playlists, new Comparator<Playlist>() {
                @Override
                public int compare(Playlist p1, Playlist p2) {
                    return Long.compare(p1.getDateCreated(), p2.getDateCreated());
                }
            });
        savePlaylists();
        Log.d(TAG, "Playlists sorted by creation date.");
    }

    /**
     * Clears all playlists. Use with caution.
     */
    public synchronized void clearAllPlaylists() {
        playlists.clear();
        savePlaylists();
        Log.d(TAG, "All playlists have been cleared.");
    }

    /**
     * Saves playlists to SharedPreferences.
     */
    private void savePlaylists() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String json = gson.toJson(playlists);
        editor.putString(KEY_PLAYLISTS, json);
        editor.apply();
        Log.d(TAG, "Playlists saved to SharedPreferences.");
    }

    /**
     * Loads playlists from SharedPreferences.
     *
     * @return A list of playlists loaded from storage.
     */
    private List<Playlist> loadPlaylists() {
        String json = sharedPreferences.getString(KEY_PLAYLISTS, null);
        if (json != null) {
            Type playlistType = new TypeToken<ArrayList<Playlist>>() {}.getType();
            List<Playlist> loadedPlaylists = gson.fromJson(json, playlistType);
            Log.d(TAG, "Playlists loaded from SharedPreferences.");
            return loadedPlaylists != null ? loadedPlaylists : new ArrayList<Playlist>();
        } else {
            Log.d(TAG, "No playlists found in SharedPreferences. Initializing empty list.");
            return new ArrayList<>(); // Return an empty list if no playlists are found
        }
    }
}
