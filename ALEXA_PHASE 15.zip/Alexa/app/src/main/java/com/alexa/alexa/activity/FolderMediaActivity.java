package com.alexa.alexa.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.R;
import com.alexa.alexa.SearchPanel;
import com.alexa.alexa.adapters.FolderMediaAdapter;
import com.alexa.alexa.library.SongLibrary;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.utils.FileUtils;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.alexa.alexa.manager.QueueManager;

public class FolderMediaActivity extends BaseActivity
implements
AudioService.ConnectionListener,
APEvents.PlaybackStateListener,
APEvents.SongListUpdateListener,
SearchPanel.OnSearchResultItemClickListener,
View.OnClickListener {

    private static final int REQUEST_STORAGE_PERMISSION = 100;
    private static final int REQUEST_MANAGE_STORAGE_PERMISSION = 101;

    private AudioService aupod;
    private ListView mediaListView;
    private FolderMediaAdapter adapter;
    private List<Object> displayItems;
    private File currentDirectory;
    private boolean isRootDirectory = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_folder_media);

        initializeViews();
        checkPermissionsAndProceed();
    }

    private void initializeViews() {
        mediaListView = findViewById(R.id.media_list_view);
        displayItems = new ArrayList<>();
    }

    private void checkPermissionsAndProceed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // For Android 11+ (API 30+), check MANAGE_EXTERNAL_STORAGE
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivityForResult(intent, REQUEST_MANAGE_STORAGE_PERMISSION);
            } else {
                handleIntent();
                setupListViewListener();
            }
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
				   != PackageManager.PERMISSION_GRANTED) {
            // For Android 6.0+ (API 23+), request READ_EXTERNAL_STORAGE
            ActivityCompat.requestPermissions(this,
											  new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
											  REQUEST_STORAGE_PERMISSION);
        } else {
            handleIntent();
            setupListViewListener();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_STORAGE_PERMISSION && grantResults.length > 0
			&& grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            handleIntent();
            setupListViewListener();
        } else {
            showToast("Storage permission is required to browse media");
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_MANAGE_STORAGE_PERMISSION && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                handleIntent();
                setupListViewListener();
            } else {
                showToast("Manage storage permission is required to browse media");
                finish();
            }
        }
    }

    private void handleIntent() {
        String folderPath = getIntent().getStringExtra("folder_path");
        if (folderPath != null) {
            File initialFolder = new File(folderPath);
            if (initialFolder.exists() && initialFolder.isDirectory()) {
                navigateToFolder(initialFolder);
            } else {
                showToast("Invalid folder path");
                finish();
            }
        } else {
            // Default to external storage root
            navigateToFolder(Environment.getExternalStorageDirectory());
        }
    }

    private void setupListViewListener() {
        mediaListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					handleItemClick(position);
				}
			});
    }

    private void handleItemClick(int position) {
        if (position < 0 || position >= displayItems.size()) {
            return;
        }

        Object selectedItem = displayItems.get(position);
        if (selectedItem instanceof File) {
            handleFileSelection((File) selectedItem);
        } else if (selectedItem instanceof SongItem) {
            handleMediaSelection((SongItem) selectedItem);
        }
    }

    private void handleFileSelection(File selectedFile) {
        if (selectedFile.isDirectory()) {
            navigateToFolder(selectedFile);
        } else if (FileUtils.isAudioFile(selectedFile)) {
            SongItem song = SongLibrary.createSongItemFromFile(this, selectedFile);
            if (song != null) {
                playAudio(song);
            }
        } else if (FileUtils.isVideoFile(selectedFile)) {
            playVideo(selectedFile);
        }
    }

    private void handleMediaSelection(SongItem selectedMedia) {
        if (selectedMedia.isVideo()) {
            playVideo(new File(selectedMedia.getPath()));
        } else {
            playAudio(selectedMedia);
        }
    }

    private void playAudio(SongItem song) {
        showToast("Playing: " + song.getTitle());
		AudioService.getInstance().clearQueue();
		QueueManager.getInstance().clearQueue();
        AudioService.getInstance().addToQueue(song);
		QueueManager.getInstance().addSongToQueue(song);

        // Optionally start AudioPlayerActivity
        Intent playerIntent = new Intent(this, PlayerActivity.class);
        playerIntent.putExtra("song_path", song.getPath());
        startActivity(playerIntent);
    }

    private void playVideo(File videoFile) {
        showToast("Playing video: " + videoFile.getName());
        ArrayList<String> videoList = createVideoList();
        int videoIndex = findVideoIndex(videoList, videoFile.getAbsolutePath());

        Intent videoIntent = new Intent(this, VideoPlayerActivity.class);
        videoIntent.putStringArrayListExtra("videoList", videoList);
        videoIntent.putExtra("videoIndex", videoIndex);
        videoIntent.putExtra("playbackMode", 0); // MODE_VIDEO
        startActivity(videoIntent);
    }

    private ArrayList<String> createVideoList() {
        ArrayList<String> videoList = new ArrayList<>();
        for (Object item : displayItems) {
            if (item instanceof SongItem && ((SongItem) item).isVideo()) {
                videoList.add(((SongItem) item).getPath());
            } else if (item instanceof File && FileUtils.isVideoFile((File) item)) {
                videoList.add(((File) item).getAbsolutePath());
            }
        }
        return videoList;
    }

    private int findVideoIndex(ArrayList<String> videoList, String videoPath) {
        for (int i = 0; i < videoList.size(); i++) {
            if (videoList.get(i).equals(videoPath)) {
                return i;
            }
        }
        return 0; // Default to first video if not found
    }

    private void navigateToFolder(File folder) {
        currentDirectory = folder;
        displayItems.clear();

        File parent = folder.getParentFile();
        isRootDirectory = (parent == null || !parent.canRead());

        if (!isRootDirectory) {
            displayItems.add(new File(".."));
        }

        List<File> directories = new ArrayList<>();
        List<File> mediaFiles = new ArrayList<>();
        List<SongItem> mediaItems = new ArrayList<>();

        File[] files = folder.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    directories.add(f);
                } else if (FileUtils.isAudioFile(f) || FileUtils.isVideoFile(f)) {
                    mediaFiles.add(f);
                }
            }

            Collections.sort(directories);
            Collections.sort(mediaFiles);

            displayItems.addAll(directories);

            for (File mediaFile : mediaFiles) {
                SongItem song = SongLibrary.createSongItemFromFile(this, mediaFile);
                if (song != null) {
                    mediaItems.add(song);
                }
            }

            displayItems.addAll(mediaItems);
        }

        updateAdapter();
        updateActionBarTitle();
    }

    private void updateAdapter() {
        if (adapter == null) {
            adapter = new FolderMediaAdapter(this, displayItems);
            mediaListView.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }
    }

    private void updateActionBarTitle() {
        if (getActionBar() != null) {
            getActionBar().setTitle(currentDirectory.getName());
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (!isRootDirectory) {
            navigateToFolder(currentDirectory.getParentFile());
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onAudioServiceConnect(AudioService service) {
        aupod = service;
        aupod.getSongsList();
        aupod.requestPlaystateUpdate();
        if (aupod.isPlaying()) {
            onPlaybackStart();
        }
    }

    @Override
    public void onPlaybackStart() {
        // Implement playback start logic
    }

    @Override
    public void onPlaybackPause() {
        // Implement playback pause logic
    }

    @Override
    public void onPlaybackStop() {
        // Implement playback stop logic
    }

    @Override
    public void onSongChanged(SongItem newsong) {
        // Implement song change logic
    }

    @Override
    public void onSongsListUpdated(List<SongItem> ulist) {
        // Implement song list update logic
    }

    @Override
    public void onSearchResultItemClick(SongItem song) {
        handleMediaSelection(song);
    }

    @Override
    public void onClick(View v) {
        // Implement click handling logic
    }
}
