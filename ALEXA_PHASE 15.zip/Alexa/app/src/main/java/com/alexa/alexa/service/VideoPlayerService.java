package com.alexa.alexa.service;

import android.app.Service; import android.content.Intent; import android.media.MediaPlayer; import android.net.Uri; import android.os.Binder; import android.os.IBinder; import android.util.Log; import java.io.IOException; import java.util.ArrayList;

public class VideoPlayerService extends Service {

	public interface VideoPlaybackListener {
		void onPrepared();
		void onCompletion();
		void onError();
	}

	private MediaPlayer mediaPlayer;
	private final IBinder binder = new LocalBinder();
	private ArrayList<String> videoList;
	private int currentIndex;
	private VideoPlaybackListener playbackListener;

	public class LocalBinder extends Binder {
		public VideoPlayerService getService() {
			return VideoPlayerService.this;
		}
	}

	@Override
	public void onCreate() {
		super.onCreate();
		mediaPlayer = new MediaPlayer();
		mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
				@Override
				public void onPrepared(MediaPlayer mp) {
					mp.start();
					if (playbackListener != null) playbackListener.onPrepared();
				}
			});
		mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
				@Override
				public void onCompletion(MediaPlayer mp) {
					playNext();
					if (playbackListener != null) playbackListener.onCompletion();
				}
			});
		mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
				@Override
				public boolean onError(MediaPlayer mp, int what, int extra) {
					if (playbackListener != null) playbackListener.onError();
					return true;
				}
			});
	}

	@Override
	public IBinder onBind(Intent intent) {
		return binder;
	}

	public void setVideoList(ArrayList<String> list, int startIndex) {
		this.videoList = list;
		this.currentIndex = startIndex;
		playVideo();
	}

	public void setPlaybackListener(VideoPlaybackListener listener) {
		this.playbackListener = listener;
	}

	private void playVideo() {
		if (videoList == null || videoList.isEmpty() || currentIndex < 0 || currentIndex >= videoList.size()) {
			return;
		}
		mediaPlayer.reset();
		try {
			mediaPlayer.setDataSource(getApplicationContext(), Uri.parse(videoList.get(currentIndex)));
			mediaPlayer.prepareAsync();
		} catch (IOException e) {
			Log.e("VideoPlayerService", "Error setting data source", e);
			if (playbackListener != null) playbackListener.onError();
		}
	}

	public void playNext() {
		if (videoList != null && currentIndex < videoList.size() - 1) {
			currentIndex++;
			playVideo();
		}
	}

	public void playPrevious() {
		if (videoList != null && currentIndex > 0) {
			currentIndex--;
			playVideo();
		}
	}

	public boolean isPlaying() {
		return mediaPlayer != null && mediaPlayer.isPlaying();
	}

	public void pause() {
		if (mediaPlayer.isPlaying()) mediaPlayer.pause();
	}

	public void resume() {
		if (!mediaPlayer.isPlaying()) mediaPlayer.start();
	}

	public void stop() {
		if (mediaPlayer.isPlaying()) mediaPlayer.stop();
	}

	@Override
	public void onDestroy() {
		if (mediaPlayer != null) {
			mediaPlayer.release();
			mediaPlayer = null;
		}
		super.onDestroy();
	}

}


