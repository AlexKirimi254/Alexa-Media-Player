package com.alexa.alexa.models;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.alexa.alexa.utils.BitmapUtils;
import java.util.List;
import java.util.HashSet;

/**
 * Represents an Album with relevant details.
 */
public class AlbumItem implements Parcelable {
    private int id;
    private String name;
    private String albumPath; // Path to the album file
    private int songCount;
    private int albumCount;
    private int artistCount; // New field to hold the number of unique artists in the album
    private int thumbnailResId; // New field to hold the thumbnail resource ID
    private List<SongItem> songList;

    // Constructor with all details
    public AlbumItem(int id, String name, String albumPath, int songCount, int albumCount, int artistCount, int thumbnailResId, List<SongItem> songList) {
        this.id = id;
        this.name = name;
        this.albumPath = albumPath;
        this.songCount = songCount;
        this.albumCount = albumCount;
        this.artistCount = artistCount;
        this.thumbnailResId = thumbnailResId;
        this.songList = songList;
    }

    // Alternate constructor (retaining your previous implementation)
    public AlbumItem(String albumName, List<SongItem> songList, int thumbnailResId) {
        this.name = albumName;
        this.songList = songList;
        this.songCount = songList != null ? songList.size() : 0; // Calculate song count from the list
        this.albumCount = 1; // Assume one album in this instance
        this.artistCount = getArtistCountFromSongList(songList); // Count unique artists
        this.thumbnailResId = thumbnailResId; // Set the album thumbnail resource ID
    }

    // Method to calculate the count of unique artists in the song list
    private int getArtistCountFromSongList(List<SongItem> songList) {
        HashSet<String> uniqueArtists = new HashSet<>();
        if (songList != null) {
            for (SongItem song : songList) {
                uniqueArtists.add(song.getArtist()); // Assuming SongItem has getArtist() method
            }
        }
        return uniqueArtists.size(); // Return the number of unique artists
    }

    // Getter and Setter methods
    public int getId() {
        return id;
    }

    public String getAlbumName() {
        return name;
    }

    public String getAlbumPath() {
        return albumPath;
    }

    public int getSongCount() {
        return songCount;
    }

    public int getAlbumCount() {
        return albumCount;
    }

    public int getArtistCount() {
        return artistCount;
    }

    public int getThumbnailResId() {
        return thumbnailResId;
    }

    public List<SongItem> getSongList() {
        return songList;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAlbumPath(String albumPath) {
        this.albumPath = albumPath;
    }

    public void setSongCount(int songCount) {
        this.songCount = songCount;
    }

    public void setAlbumCount(int albumCount) {
        this.albumCount = albumCount;
    }

    public void setArtistCount(int artistCount) {
        this.artistCount = artistCount;
    }

    public void setThumbnailResId(int thumbnailResId) {
        this.thumbnailResId = thumbnailResId;
    }

    public void setSongList(List<SongItem> songList) {
        this.songList = songList;
        this.songCount = songList != null ? songList.size() : 0; // Update song count when setting list
        this.artistCount = getArtistCountFromSongList(songList); // Update unique artist count
    }

    // Parcelable implementation
    protected AlbumItem(Parcel in) {
        id = in.readInt();
        name = in.readString();
        albumPath = in.readString();
        songCount = in.readInt();
        albumCount = in.readInt();
        artistCount = in.readInt();
        thumbnailResId = in.readInt();
        songList = in.createTypedArrayList(SongItem.CREATOR); // Read song list
    }

    public static final Creator<AlbumItem> CREATOR = new Creator<AlbumItem>() {
        @Override
        public AlbumItem createFromParcel(Parcel in) {
            return new AlbumItem(in);
        }

        @Override
        public AlbumItem[] newArray(int size) {
            return new AlbumItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(id);
        parcel.writeString(name);
        parcel.writeString(albumPath); // Write album path
        parcel.writeInt(songCount);
        parcel.writeInt(albumCount);
        parcel.writeInt(artistCount);
        parcel.writeInt(thumbnailResId); // Write thumbnail resource ID
        parcel.writeTypedList(songList); // Write song list
    }

    // Method to retrieve album thumbnail as Bitmap (if needed)
    public Bitmap getThumbnail() {
        try {
            // Implement logic to fetch the thumbnail based on album name or path
            return BitmapUtils.getSongThumbnailFromFile(albumPath); // Use albumPath to get thumbnail
        } catch (Exception e) {
            Log.e("AlbumItem", "Error retrieving thumbnail for album: " + name, e);
            return null; // Return null if there is an error
        }
    }
}

