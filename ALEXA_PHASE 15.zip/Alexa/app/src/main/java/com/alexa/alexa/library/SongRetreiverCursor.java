package com.alexa.alexa.library;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import com.alexa.alexa.models.SongItem;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SongRetreiverCursor {
    // Context ctx; (commented out as per the requirement)

    private SongRetreiverCursor() {
        //this.ctx = ctx; (constructor remains unchanged)
    }

    public static List<SongItem> get(Context ctx, String sortOrder) {
		List<SongItem> sitems = new ArrayList<>();
		if (ctx == null) {
			return sitems;
		}

		Uri suri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
		String selection = MediaStore.Audio.Media.IS_MUSIC + "!=0";

		Cursor c = ctx.getContentResolver().query(
			suri,
			null,
			selection,
			null,
			sortOrder
		);

		if (c == null || c.getCount() == 0) {
			return sitems;
		}
		c.moveToFirst();

		do {
			SongItem si = new SongItem();

			si.path = c.getString(c.getColumnIndex(MediaStore.Audio.Media.DATA));

			if (new File(si.path).exists()) {
				si.id = c.getString(c.getColumnIndex(MediaStore.Audio.Media._ID));
				si.title = c.getString(c.getColumnIndex(MediaStore.Audio.Media.TITLE));
				si.artist = c.getString(c.getColumnIndex(MediaStore.Audio.Media.ARTIST));
				si.album = c.getString(c.getColumnIndex(MediaStore.Audio.Media.ALBUM));
				si.duration = c.getInt(c.getColumnIndex(MediaStore.Audio.Media.DURATION));
				si.artId = c.getLong(c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID));
				sitems.add(si);
			}
		} while (c.moveToNext());

		c.close();

		return sitems;
	}
}



