package com.alexa.alexa.models;

public interface MediaItem {
    String getId();
    String getTitle();
    String getPath();
    long getDuration();
}
