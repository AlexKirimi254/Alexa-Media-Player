package com.alexa.alexa.manager;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.alexa.alexa.models.CrossfadeConfig;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import java.io.IOException;
import com.alexa.alexa.Constants;

public class CrossfadeStateManager {
    private static final int STEPS = 50;
    private static final int CROSSFADE_START_OFFSET = 30000; // 30 seconds before song ends
    private Context context;
    private CrossfadeConfig config;
    private MediaPlayer currentPlayer;
    private MediaPlayer nextPlayer;
    private Handler handler;
    private boolean isCrossfading;
    private Runnable crossfadeRunnable;

    public CrossfadeStateManager(Context context, CrossfadeConfig config) {
        this.context = context;
        this.config = config;
        this.handler = new Handler();
        this.isCrossfading = false;
    }

    public CrossfadeConfig getConfig() {
        return config;
    }

    public boolean isCrossfading() {
        return isCrossfading;
    }

    public void startCrossfade(MediaPlayer currentPlayer, final SongItem nextSong, final int nextIndex, final AudioService audioService) {
        if (!config.isEnabled() || config.getDuration() <= 0 || isCrossfading || nextSong == null) {
            audioService.playNext();
            return;
        }

        this.currentPlayer = currentPlayer;

        try {
            nextPlayer = new MediaPlayer();
            nextPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            nextPlayer.setDataSource(nextSong.path);
            nextPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
					@Override
					public void onPrepared(MediaPlayer mp) {
						if (isCrossfading) {
							// Already crossfading, abort
							nextPlayer.release();
							nextPlayer = null;
							return;
						}
						nextPlayer.start();
						nextPlayer.setVolume(0.0f, 0.0f);
						isCrossfading = true;
						notifyCrossfadeStarted();
						performCrossfade(nextSong, nextIndex, audioService);
					}
				});
            nextPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
					@Override
					public boolean onError(MediaPlayer mp, int what, int extra) {
						if (nextPlayer != null) {
							nextPlayer.release();
							nextPlayer = null;
						}
						audioService.playNext();
						return true;
					}
				});
            nextPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
            if (nextPlayer != null) {
                nextPlayer.release();
                nextPlayer = null;
            }
            audioService.playNext();
        }
    }

    private void performCrossfade(final SongItem nextSong, final int nextIndex, final AudioService audioService) {
        final long interval = config.getDuration() / STEPS;
        final float volumeStep = 1.0f / STEPS;

        handler.removeCallbacksAndMessages(null);
        crossfadeRunnable = new Runnable() {
            private int currentStep = 0;

            @Override
            public void run() {
                if (!isCrossfading || currentPlayer == null || nextPlayer == null || !currentPlayer.isPlaying() || !nextPlayer.isPlaying()) {
                    completeCrossfade(nextSong, nextIndex, audioService);
                    return;
                }

                float outgoingVolume = 1.0f - (volumeStep * currentStep);
                float incomingVolume = volumeStep * currentStep;

                if (outgoingVolume < 0.0f) outgoingVolume = 0.0f;
                if (incomingVolume > 1.0f) incomingVolume = 1.0f;

                currentPlayer.setVolume(outgoingVolume, outgoingVolume);
                nextPlayer.setVolume(incomingVolume, incomingVolume);

                currentStep++;
                if (currentStep <= STEPS) {
                    handler.postDelayed(this, interval);
                } else {
                    completeCrossfade(nextSong, nextIndex, audioService);
                }
            }
        };
        handler.post(crossfadeRunnable);
    }

    private void completeCrossfade(SongItem nextSong, int nextIndex, AudioService audioService) {
        isCrossfading = false;
        handler.removeCallbacksAndMessages(null);

        if (currentPlayer != null) {
            currentPlayer.stop();
            currentPlayer.release();
        }

        audioService.setMediaPlayer(nextPlayer);
        nextPlayer = null;

        audioService.updateCurrentSong(nextSong, nextIndex);
        notifyCrossfadeCompleted();
    }

    public void cancelCrossfade() {
        if (isCrossfading) {
            isCrossfading = false;
            handler.removeCallbacksAndMessages(null);
            if (nextPlayer != null) {
                nextPlayer.stop();
                nextPlayer.release();
                nextPlayer = null;
            }
            if (currentPlayer != null) {
                currentPlayer.setVolume(1.0f, 1.0f);
            }
            notifyCrossfadeCompleted();
        }
    }

    private void notifyCrossfadeStarted() {
        Intent intent = new Intent(Constants.ACTION_CROSSFADE_STARTED);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    private void notifyCrossfadeCompleted() {
        Intent intent = new Intent(Constants.ACTION_CROSSFADE_COMPLETED);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public boolean shouldStartCrossfade(int currentPosition, int duration) {
        return config.isEnabled() && config.getDuration() > 0 && duration > 0 && currentPosition >= (duration - CROSSFADE_START_OFFSET);
    }
}
