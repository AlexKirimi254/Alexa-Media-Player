package com.alexa.alexa.adapters;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.library.SongLibrary;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.menu.AddMultipleToPlaylistDialog;
import com.alexa.alexa.models.ArtistItem;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;

import java.util.ArrayList;
import java.util.List;

public class ArtistListAdapter extends RecyclerView.Adapter<ArtistListAdapter.ArtistViewHolder> {

    private List<ArtistItem> artistList = new ArrayList<>();
    private LayoutInflater inflater;
    private ThemeManager.Theme theme;
    private OnItemClickListener itemClickListener;

    public interface OnItemClickListener {
        void onItemClick(ArtistItem artist);
    }

    public ArtistListAdapter(LayoutInflater inflater) {
        this.inflater = inflater;
    }

    public void update(List<ArtistItem> list) {
        this.artistList = list;
        notifyDataSetChanged();
    }

    public void setTheme(ThemeManager.Theme theme) {
        this.theme = theme;
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.itemClickListener = listener;
    }

    @NonNull
    @Override
    public ArtistViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.adapteritem_artist, parent, false);
        return new ArtistViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ArtistViewHolder holder, int position) {
        ArtistItem artist = artistList.get(position);
        bindView(holder, artist);
    }

    @Override
    public int getItemCount() {
        return artistList.size();
    }

    private void bindView(ArtistViewHolder holder, final ArtistItem artist) {
        holder.nameTextView.setText(artist.getName());
        holder.albumCountTextView.setText(artist.getAlbumCount() + (artist.getAlbumCount() > 1 ? " albums" : " album"));
        holder.songCountTextView.setText(artist.getSongcount() + (artist.getSongcount() > 1 ? " songs" : " song"));

        Bitmap thumbnail = artist.getThumbnail();
        if (thumbnail != null) {
            holder.thumbnailImageView.setImageDrawable(new BitmapDrawable(holder.thumbnailImageView.getResources(), thumbnail));
        } else {
            holder.thumbnailImageView.setImageResource(R.drawable.cover_f);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if (itemClickListener != null) {
						itemClickListener.onItemClick(artist);
					}
				}
			});

        holder.moreIconImageView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showMenuForArtist(v, artist);
				}
			});
    }

    static class ArtistViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView albumCountTextView;
        TextView songCountTextView;
        ImageView thumbnailImageView;
        ImageView moreIconImageView;

        public ArtistViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.artistslist_item_title);
            albumCountTextView = itemView.findViewById(R.id.artistslist_albumcount);
            songCountTextView = itemView.findViewById(R.id.artistslist_songcount);
            thumbnailImageView = itemView.findViewById(R.id.artistslist_item_albumart);
            moreIconImageView = itemView.findViewById(R.id.artistslist_item_more_icon); // Assuming you have the more icon here
        }
    }

    private void showMenuForArtist(final View anchorView, final ArtistItem artist) {
        PopupMenu popupMenu = new PopupMenu(anchorView.getContext(), anchorView);
        MenuInflater inflater = popupMenu.getMenuInflater();
        inflater.inflate(R.menu.song_options_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					int id = item.getItemId();
					if (id == R.id.menu_play_next) {
						playNextSong(artist);
						return true;
					} else if (id == R.id.menu_add_to_playlist) {
						addArtistSongsToPlaylist(anchorView, artist);
						return true;
					}
					return false;
				}
			});

        popupMenu.show();
    }

    private void addArtistSongsToPlaylist(final View view, final ArtistItem artist) {
        SongLibrary.getInstance().getSongsByArtist(artist.getId(), new SongLibrary.ResultCallback<List<SongItem>>() {
				@Override
				public void onResult(List<SongItem> songs) {
					if (songs != null && !songs.isEmpty()) {
						AddMultipleToPlaylistDialog dialog = new AddMultipleToPlaylistDialog(view.getContext(), songs);
						dialog.show();
					} else {
						Toast.makeText(view.getContext(), "No songs found for this artist.", Toast.LENGTH_SHORT).show();
					}
				}
			});
    }

    private void playNextSong(ArtistItem artist) {
        SongLibrary.getInstance().getSongsByArtist(artist.getId(), new SongLibrary.ResultCallback<List<SongItem>>() {
				@Override
				public void onResult(List<SongItem> songs) {
					if (!songs.isEmpty()) {
						for (SongItem song : songs) {
							AudioService.getInstance().addToQueue(song);
							QueueManager.getInstance().addSongToQueue(song);
						}
					}
				}
			});
    }
}
