package com.alexa.alexa.tabs;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import com.alexa.alexa.view.tabview.Tab;

public class SettingsTab {
    private View view;

    public SettingsTab(View view) {
        this.view = view;
    }

    public View getView() {
        return view;
    }
}

