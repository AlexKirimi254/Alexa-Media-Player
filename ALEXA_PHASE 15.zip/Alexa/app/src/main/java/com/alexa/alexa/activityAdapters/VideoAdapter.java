package com.alexa.alexa.activityAdapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.VideoItem;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class VideoAdapter extends BaseAdapter {

    public interface OnVideoOptionsListener {
        void onOptionsClicked(int position, View anchorView);
    }

    public interface OnVideoClickListener {
        void onVideoClicked(int position);
    }

    private Context context;
    private List<VideoItem> videoList;
    private OnVideoOptionsListener optionsListener;
    private OnVideoClickListener clickListener;
    private LayoutInflater inflater;
    private ThumbnailUtils thumbnailUtils;

    public VideoAdapter(Context context, List<VideoItem> videoList, 
						OnVideoOptionsListener optionsListener, 
						OnVideoClickListener clickListener) {
        this.context = context;
        this.videoList = videoList;
        this.optionsListener = optionsListener;
        this.clickListener = clickListener;
        this.inflater = LayoutInflater.from(context);
        this.thumbnailUtils = new ThumbnailUtils();
    }

    @Override
    public int getCount() {
        return videoList.size();
    }

    @Override
    public Object getItem(int position) {
        return videoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    static class ViewHolder {
        ImageView thumbnailImageView;
        TextView titleTextView;
        TextView sizeTextView;
        TextView durationTextView;
        TextView dateAddedTextView;
        ImageView optionsImageView;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_video, parent, false);
            holder = new ViewHolder();

            holder.thumbnailImageView = convertView.findViewById(R.id.videoThumbnail);
            holder.titleTextView = convertView.findViewById(R.id.videoTitle);
            holder.sizeTextView = convertView.findViewById(R.id.videoSize);
            holder.durationTextView = convertView.findViewById(R.id.videoDuration);
            holder.dateAddedTextView = convertView.findViewById(R.id.videoDate);
            holder.optionsImageView = convertView.findViewById(R.id.btnOptions);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final VideoItem videoItem = videoList.get(position);

        // Set thumbnail
        loadThumbnail(videoItem, holder.thumbnailImageView);

        holder.titleTextView.setText(videoItem.getTitle());
        holder.sizeTextView.setText(formatFileSize(videoItem.getSize()));
        holder.durationTextView.setText(formatDuration(videoItem.getDuration()));
        holder.dateAddedTextView.setText(formatDate(videoItem.getDateAdded()));

        holder.optionsImageView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if (optionsListener != null) {
						optionsListener.onOptionsClicked(position, view);
					}
				}
			});

        convertView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if (clickListener != null) {
						clickListener.onVideoClicked(position);
					}
				}
			});

        convertView.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View view) {
					if (optionsListener != null) {
						optionsListener.onOptionsClicked(position, view);
						return true;
					}
					return false;
				}
			});

        return convertView;
    }

    private void loadThumbnail(final VideoItem videoItem, final ImageView imageView) {
        Bitmap thumbnail = getVideoThumbnail(videoItem.getPath());

        if (thumbnail != null) {
            imageView.setImageBitmap(thumbnail);
        } else {
            imageView.setImageResource(R.drawable.video_placeholder);

            new AsyncTask<Void, Void, Bitmap>() {
                @Override
                protected Bitmap doInBackground(Void... voids) {
                    return createVideoThumbnail(videoItem.getPath());
                }

                @Override
                protected void onPostExecute(Bitmap bitmap) {
                    if (bitmap != null) {
                        imageView.setImageBitmap(bitmap);
                    }
                }
            }.execute();
        }
    }

    private Bitmap getVideoThumbnail(String videoPath) {
        return createVideoThumbnail(videoPath);
    }

    private Bitmap createVideoThumbnail(String videoPath) {
        Bitmap thumbnail = ThumbnailUtils.createVideoThumbnail(
            videoPath, 
            MediaStore.Video.Thumbnails.MINI_KIND);

        if (thumbnail == null) {
            thumbnail = BitmapFactory.decodeResource(context.getResources(), R.drawable.video_placeholder);
        }

        return thumbnail;
    }

    public String formatFileSize(long sizeInBytes) {
        return Formatter.formatFileSize(context, sizeInBytes);
    }

    public String formatDuration(long durationInMillis) {
        long hours = TimeUnit.MILLISECONDS.toHours(durationInMillis);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(durationInMillis) % 60;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(durationInMillis) % 60;

        if (hours > 0) {
            return String.format("%d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%d:%02d", minutes, seconds);
        }
    }

    public String formatDate(long timestampMillis) {
        return DateFormat.format("dd MMM yyyy", timestampMillis).toString();
    }
}
