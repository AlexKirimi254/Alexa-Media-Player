package com.alexa.alexa.model.smartplaylist;

import android.content.Context;
import android.os.Parcel;
import androidx.annotation.NonNull;
import com.alexa.alexa.R;
import com.alexa.alexa.loader.TopAndRecentlyPlayedSongsLoader;
import com.alexa.alexa.model.Song;
import com.alexa.alexa.model.smartplaylist.HistoryPlaylist;
import com.alexa.alexa.provider.HistoryStore;
import java.util.ArrayList;

public class HistoryPlaylist extends AbsSmartPlaylist {

    public HistoryPlaylist(@NonNull Context context) {
        super(context.getString(R.string.app_name), R.drawable.ic_equalizer);
    }

    @NonNull
    @Override
    public ArrayList<Song> getSongs(@NonNull Context context) {
        return TopAndRecentlyPlayedSongsLoader.getRecentlyPlayedSongs(context);
    }

    @Override
    public void clear(@NonNull Context context) {
        HistoryStore.getInstance(context).clear();
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }

    protected HistoryPlaylist(Parcel in) {
        super(in);
    }
/*
    public static final Creator<HistoryPlaylist> CREATOR = new Creator<HistoryPlaylist>() {
        public HistoryPlaylist createFromParcel(Parcel source) {
            return new HistoryPlaylist(source);
        }*

        public HistoryPlaylist[] newArray(int size) {
            return new HistoryPlaylist[size];
        }
    };*/
}
