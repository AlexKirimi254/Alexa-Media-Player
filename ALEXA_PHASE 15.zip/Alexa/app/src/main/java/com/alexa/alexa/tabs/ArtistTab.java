package com.alexa.alexa.tabs;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activity.ArtistDetailsActivity;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.ArtistListAdapter;
import com.alexa.alexa.library.SongLibrary;
import com.alexa.alexa.models.ArtistItem;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.view.tabview.Tab;
import java.util.ArrayList;
import java.util.List;

public class ArtistTab extends Tab {

    private MainActivity activity;
    private View rootView;
    private RecyclerView recyclerView;
    private ArtistListAdapter adapter;
    private boolean isDataLoaded = false;
	private static final String PREFS_NAME = "AppPrefs";
    private static final String GRID_SIZE_KEY = "grid_size";
	private int gridSize = 2;
    public ArtistTab(MainActivity activity) {
        this.activity = activity;
        initializeTab();
    }

    // Initialize the tab view and adapter
    private void initializeTab() {
        LayoutInflater inflater = LayoutInflater.from(activity);
        rootView = inflater.inflate(R.layout.default_recyclerview, null, false); // Use the new layout
        recyclerView = rootView.findViewById(R.id.recycler_view);

        // Set up the RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(activity));
        adapter = new ArtistListAdapter(inflater);
        recyclerView.setAdapter(adapter);
		SharedPreferences prefs = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gridSize = prefs.getInt(GRID_SIZE_KEY, 1); // Default to 2 columns
         // Default sort order

        setGridSize(gridSize);
		
        // Set up the item click listener for the adapter
        adapter.setOnItemClickListener(new ArtistListAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(ArtistItem artist) {
                    showArtistDetails(artist);
                }
            });
    }

    @Override
    public View getView() {
        return rootView;
    }

    @Override
    public void onTabShown() {
        if (!isDataLoaded) {
            loadArtists();
        }
    }
	public void setGridSize(int size) {
        gridSize = size;
        recyclerView.setLayoutManager(new GridLayoutManager(activity, gridSize));
        adapter.notifyDataSetChanged();

        // Save grid size to SharedPreferences
        SharedPreferences prefs = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(GRID_SIZE_KEY, gridSize).apply();
    }

    public int getGridSize() {
        return gridSize;
    }
    @Override
    public void onTabHidden() {
        // Optional: Handle actions when the tab is hidden
    }

    @Override
    public void onTabAlreadyVisible() {
        // Optional: Handle actions if the tab is already visible
    }

    @Override
    public void onApplyTheme(ThemeManager.Theme theme) {
        // Apply theme to the adapter and RecyclerView
        adapter.setTheme(theme);
    }

    // Load artists from the SongLibrary
    public void loadArtists() {
        SongLibrary.getInstance().getAllArtists(new SongLibrary.ResultCallback<List<ArtistItem>>() {
                @Override
                public void onResult(List<ArtistItem> artists) {
                    adapter.update(artists);
                    isDataLoaded = true;
                }
            });
    }

    // Handle the artist item click event
    private void showArtistDetails(final ArtistItem artist) {
        // Retrieve songs for the selected artist
        SongLibrary.getInstance().getSongsByArtist(artist.getId(), new SongLibrary.ResultCallback<List<SongItem>>() {
                @Override
                public void onResult(List<SongItem> songs) {
                    // Create an Intent to start ArtistDetailsActivity
                    Intent intent = new Intent(activity, ArtistDetailsActivity.class);

                    // Pass artist's details
                    intent.putExtra("artist_name", artist.getName());
                    intent.putExtra("song_count", artist.getSongcount());
                    intent.putExtra("album_count", artist.getAlbumCount());

                    // Pass the list of SongItem objects
                    ArrayList<SongItem> songList = new ArrayList<>(songs);
                    intent.putParcelableArrayListExtra("song_list", songList);

                    // Start the ArtistDetailsActivity
                    activity.startActivity(intent);
                }
            });
    }
}
