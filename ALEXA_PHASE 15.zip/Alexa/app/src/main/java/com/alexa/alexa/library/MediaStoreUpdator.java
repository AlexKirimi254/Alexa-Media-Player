package com.alexa.alexa.library;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.provider.MediaStore;
import com.alexa.alexa.models.SongItem;

public class MediaStoreUpdator
{
    public MediaStoreUpdator(){
        //
    }
    
    public static void update(Context ctx, SongItem si, String artPath){
        ContentResolver cr = ctx.getContentResolver();
        ContentValues vals = new ContentValues();
        vals.put(MediaStore.Audio.Media.TITLE, si.title);
        vals.put(MediaStore.Audio.Media.ARTIST, si.artist);
        vals.put(MediaStore.Audio.Media.ALBUM, si.album);
        if(si.getIconPath()!=null && si.artId!=0 && artPath!=null){
            Uri artworkUris = Uri.parse("content://media/external/audio/albumart");
            cr.delete(ContentUris.withAppendedId(artworkUris, si.artId), null, null);
            
            ContentValues cv = new ContentValues();
            cv.put("album_id",si.artId);
            cv.put("_data", artPath);
            cr.insert(artworkUris, cv);
        }
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        cr.update(uri,vals,MediaStore.Audio.Media._ID +" = ? " , new String[]{si.id});
    }
    
    public static void rescan(Context ctx){
        //
        //MediaScannerConnection.
    }
}
