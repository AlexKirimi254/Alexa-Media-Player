package com.alexa.alexa.adapters;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.menu.SongOptions;
import com.alexa.alexa.models.SongItem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SongsQueueAdapter extends RecyclerView.Adapter<SongsQueueAdapter.SongViewHolder> {

    private List<SongItem> songList = new ArrayList<>();
    private final MainActivity ctx;
    private final List<SongItem> selectedSongs = new ArrayList<>();
    private boolean multiSelectEnabled = false;
    private SongItem currentSong;
    private ThemeManager.Theme currentTheme;
    private long totalDuration = 0;
    private TextView totalDurationView;

    public interface OnItemClickListener {
        void onItemClick(SongItem songItem);
        void onItemLongClick(SongItem songItem, boolean enableMultiSelect);
    }

    private OnItemClickListener listener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public SongsQueueAdapter(MainActivity context, List<SongItem> songList, TextView totalDurationView) {
        this.ctx = context;
        this.songList = songList;
        this.totalDurationView = totalDurationView;
        calculateTotalDuration();
    }

    public void update(List<SongItem> list) {
        this.songList = list;
        calculateTotalDuration();
        notifyDataSetChanged();
    }

    public void setCurrent(SongItem songitem) {
        this.currentSong = songitem;
        notifyDataSetChanged();
    }

    public int getPos(SongItem si) {
        return songList.indexOf(si);
    }

    public void toggleSelection(SongItem songItem) {
        if (selectedSongs.contains(songItem)) {
            selectedSongs.remove(songItem);
        } else {
            selectedSongs.add(songItem);
        }
        notifyDataSetChanged();
    }

    public void clearSelection() {
        selectedSongs.clear();
        notifyDataSetChanged();
    }

    public List<SongItem> getSelectedSongs() {
        return selectedSongs;
    }

    public void enableMultiSelect(boolean enable) {
        multiSelectEnabled = enable;
        if (!enable) {
            clearSelection();
        }
    }

    private void calculateTotalDuration() {
        totalDuration = 0;
        for (SongItem song : songList) {
            totalDuration += song.getDuration();
        }
        updateTotalDurationUI();
    }

    private void updateTotalDurationUI() {
        if (totalDurationView != null) {
            totalDurationView.setText(formatDuration(totalDuration));
        }
    }

    private String formatDuration(long durationMs) {
        long seconds = durationMs / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        seconds %= 60;
        minutes %= 60;

        if (hours > 0) {
            return String.format("%d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%d:%02d", minutes, seconds);
        }
    }

    public boolean onItemMove(int fromPosition, int toPosition) {
        if (fromPosition < songList.size() && toPosition < songList.size()) {
            Collections.swap(songList, fromPosition, toPosition);
            notifyItemMoved(fromPosition, toPosition);

            if (App.get().getAudioService() != null) {
                App.get().getAudioService().onQueueRearranged(songList);
            }
            return true;
        }
        return false;
    }

    public void setTheme(ThemeManager.Theme theme) {
        this.currentTheme = theme;
        notifyDataSetChanged();
    }

    @Override
    public SongViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.adapteritem_queue, parent, false);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SongViewHolder holder, final int position) {
        final SongItem item = songList.get(position);

        holder.title.setText(item.getTitle());
        holder.artist.setText(item.getArtist());

        if (item.getIconPath() != null) {
            holder.art.setBackground(new BitmapDrawable(ctx.getResources(), item.getThumbnail()));
        }

        if (item.equals(currentSong)) {
            holder.itemView.setBackgroundColor(ctx.getResources().getColor(R.color.black));
        } else {
            holder.itemView.setBackgroundColor(ctx.getResources().getColor(android.R.color.transparent));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (multiSelectEnabled) {
						toggleSelection(item);
					} else {
						if (listener != null) {
							listener.onItemClick(item);
						}
						if (App.get().getAudioService() != null) {
							App.get().getAudioService().playQueue(songList, position);
							setCurrent(item);
						}
					}
				}
			});

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					if (listener != null) {
						listener.onItemLongClick(item, true);
					}
					return true;
				}
			});

        holder.moreButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					new SongOptions(ctx, item).show();
				}
			});
    }

    @Override
    public int getItemCount() {
        return songList.size();
    }

    static class SongViewHolder extends RecyclerView.ViewHolder {
        TextView title, artist;
        ImageView art;
        View moreButton;

        public SongViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.queuelist_item_title);
            artist = itemView.findViewById(R.id.queuelist_item_artist);
            art = itemView.findViewById(R.id.queuelist_item_albumart);
            moreButton = itemView.findViewById(R.id.queuelist_item_more_icon);
        }
    }
}
