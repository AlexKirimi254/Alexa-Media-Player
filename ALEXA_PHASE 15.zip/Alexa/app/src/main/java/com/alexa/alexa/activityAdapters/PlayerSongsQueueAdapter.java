package com.alexa.alexa.activityAdapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.activityAdapters.PlayerSongsQueueAdapter;
import com.alexa.alexa.models.SongItem;
import java.util.List;

public class PlayerSongsQueueAdapter extends RecyclerView.Adapter<PlayerSongsQueueAdapter.SongViewHolder>
 {
    private Context context;
    private List<SongItem> songQueue;

    public PlayerSongsQueueAdapter(Context context, List<SongItem> songQueue) {
        this.context = context;
        this.songQueue = songQueue;
    }

    @Override
    public SongViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_song, parent, false);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SongViewHolder holder, int position) {
        SongItem song = songQueue.get(position);
        holder.title.setText(song.getTitle());
        holder.artist.setText(song.getArtist());
    }

    @Override
    public int getItemCount() {
        return songQueue.size();
    }

    public void update(List<SongItem> newQueue) {
        songQueue = newQueue;
        notifyDataSetChanged();
    }

    public class SongViewHolder extends RecyclerView.ViewHolder {
        TextView title, artist;

        public SongViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.item_song_title);
            artist = itemView.findViewById(R.id.item_song_artist);
        }
    }
}

