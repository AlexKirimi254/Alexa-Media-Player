package com.alexa.alexa;

public class Constants {
    public static final String CMD_PLAY_FROM_INTENT = "com.alexa.alexa.CMD_PLAY_FROM_INTENT";
	
	public static final String CMD_START = "com.alexa.alexa.cmd.start_service";
    public static final String CMD_END = "com.alexa.alexa.cmd.end.exit";
    public static final String CMD_MEDIA_BUTTON = "com.alexa.alexa.CMD_MEDIA_BUTTON";
    //
    public static final String CMD_PAUSE = "com.alexa.alexa.CMD_PAUSE";
    public static final String CMD_PLAY = "com.alexa.alexa.CMD_PLAY";
    public static final String CMD_PLAY_NEXT = "com.alexa.alexa.CMD_PLAY_NEXT";
    public static final String CMD_PLAY_PREV = "com.alexa.alexa.CMD_PLAY_PREV";
	
	public static String ACTION_SONG_CHANGED = "com.alexa.alexa.ACTION_SONG_CHANGED";
    public static String ACTION_CROSSFADE_STARTED = "com.alexa.alexa.ACTION_CROSSFADE_STARTED";
    public static String ACTION_CROSSFADE_COMPLETED = "com.alexa.alexa.ACTION_CROSSFADE_COMPLETED";
	
	
}
