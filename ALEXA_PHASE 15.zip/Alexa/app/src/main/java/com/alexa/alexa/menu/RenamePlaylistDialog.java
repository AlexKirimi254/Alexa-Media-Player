package com.alexa.alexa.menu;



import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.alexa.alexa.R;
import com.alexa.alexa.manager.PlaylistManager;
import com.alexa.alexa.models.Playlist;


/**
 * Dialog for renaming an existing playlist.
 */
public class RenamePlaylistDialog {

    private final Context context;
    private final PlaylistManager playlistManager;
    private final Playlist playlist;

    public RenamePlaylistDialog(Context context, Playlist playlist) {
        this.context = context;
        this.playlistManager = PlaylistManager.getInstance();
        this.playlist = playlist;
    }

    public void show() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Rename Playlist");

        // Inflate custom layout
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dialog_rename_playlist, null);
        builder.setView(view);

        final EditText newNameInput = (EditText) view.findViewById(R.id.edittext_new_playlist_name);
        newNameInput.setInputType(InputType.TYPE_CLASS_TEXT);
        newNameInput.setText(playlist.getName());

        Button renameButton = (Button) view.findViewById(R.id.button_rename_playlist);
        Button cancelButton = (Button) view.findViewById(R.id.button_cancel_rename_playlist);

        final AlertDialog dialog = builder.create();

        // Set OnClickListener for the rename button
     /*   renameButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String newName = newNameInput.getText().toString().trim();
                    if (newName.isEmpty()) {
                        Toast.makeText(context, "Playlist name cannot be empty.", Toast.LENGTH_SHORT).show();
                    } else {
                        boolean added = playlistManager.addSongToPlaylist(newPlaylist.getName(), song);
                        if (renamed) {
                            Toast.makeText(context, "Playlist renamed to '" + newName + "'.", Toast.LENGTH_SHORT).show();
                            // Optionally refresh UI components that display playlists
                        } else {
                            Toast.makeText(context, "Failed to rename playlist. It may already exist.", Toast.LENGTH_SHORT).show();
                        }
                        dialog.dismiss();
                    }
                }
            });*/

        // Set OnClickListener for the cancel button
        cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

        dialog.show();
    }
}

