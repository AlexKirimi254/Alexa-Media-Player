package com.alexa.alexa.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.SearchPanel;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activityAdapters.PlaylistsActivitySongsAdapter;
import com.alexa.alexa.activityAdapters.VideoAdapter;
import com.alexa.alexa.menu.VideoFilePickerDialog;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.models.VideoItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.utils.FastBlur;
import com.alexa.alexa.view.TintedImageView;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class VideoFilePickerActivity extends BaseActivity
implements VideoAdapter.OnVideoOptionsListener,
AudioService.ConnectionListener,
APEvents.PlaybackStateListener,
APEvents.SongListUpdateListener,
SearchPanel.OnSearchResultItemClickListener,
View.OnClickListener{
	private static final String PREFS_NAME = "VideoPrefs";
	private static final String PREF_SORT_OPTION = "sort_option";
	private static final int DEFAULT_SORT_OPTION = R.id.menu_sort_name_asc;
    private ListView videoListView;
    private VideoAdapter adapter;
    private List<VideoItem> videoItems = new ArrayList<VideoItem>();
    private int currentSortOption = R.id.menu_sort_name_asc; // Default sort by name ascending
	private AudioService audioService;
	//private VideoAdapter videoAdapter;
	private VideoItem selectedVideo;
	
	private SharedPreferences sharedPrefs;
	private TextView songTitle, songArtist;

	private ArrayList<SongItem> songQueue = new ArrayList<>();


	private Handler handle;
	//private SongItem mCurrentSong;
	private List<Playlist> playlists;
	private ArrayList<SongItem> songList = new ArrayList<>();
	private String playlistName;

	// UI Components
	//private ListView songListView;
	private TextView playlistNameView;
	private PlaylistsActivitySongsAdapter songAdapter;

	private TextView currentTitle, currentArtist;
	private TextView trackTimeCurrent, trackTimeDuration;
	private LinearLayout art2Background;
	private ImageView currentArt;

	private TintedImageView playpauseIcon;
	private SeekBar seeker;
	private Runnable seekerTick;
	private boolean seektouch;
    
	
	//	private ListView fileListView;
		//private Button btnSelect;
		private ArrayList<String> videoPaths = new ArrayList<>();
		private ArrayList<String> selectedVideos = new ArrayList<>();
		private int selectedIndex = 0;

		

		private void loadVideoFiles() {
			// Get all video files from storage
			String[] projection = {
				MediaStore.Video.Media._ID,
				MediaStore.Video.Media.DISPLAY_NAME,
				MediaStore.Video.Media.DATA
			};

			Cursor cursor = getContentResolver().query(
				MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
				projection,
				null,
				null,
				MediaStore.Video.Media.DATE_ADDED + " DESC"
			);

			if (cursor != null) {
				int pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
				while (cursor.moveToNext()) {
					String path = cursor.getString(pathColumn);
					videoPaths.add(path);
				}
				cursor.close();
			}
		}

		/*private void setupFileBrowserr() {
			// Create adapter for the list view
			ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
															  android.R.layout.simple_list_item_multiple_choice, videoPaths);

			fileListView.setAdapter(adapter);
			fileListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

			// Handle item selection
			fileListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
						selectedIndex = position;
					}
				});

			// Select button handler
			btnSelect.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						selectedVideos = getSelectedVideos();
						if (!selectedVideos.isEmpty()) {
							launchVideoPlayer();
						} else {
							Toast.makeText(VideoFilePickerActivity.this, 
										   "Please select at least one video", Toast.LENGTH_SHORT).show();
						}
					}
				});

			// Restore previous selections if available
			if (getIntent().hasExtra("videoList")) {
				ArrayList<String> previousSelection = getIntent().getStringArrayListExtra("videoList");
				for (int i = 0; i < videoPaths.size(); i++) {
					if (previousSelection.contains(videoPaths.get(i))) {
						fileListView.setItemChecked(i, true);
					}
				}
			}
		}

		private ArrayList<String> getSelectedVideos() {
			ArrayList<String> selected = new ArrayList<>();
			SparseBooleanArray checked = fileListView.getCheckedItemPositions();

			for (int i = 0; i < checked.size(); i++) {
				if (checked.valueAt(i)) {
					int position = checked.keyAt(i);
					selected.add(videoPaths.get(position));
				}
			}

			// If nothing selected but user clicked an item, use that
			if (selected.isEmpty() && selectedIndex < videoPaths.size()) {
				selected.add(videoPaths.get(selectedIndex));
			}

			return selected;
		}

		private int getSelectedIndex() {
			// Return the first selected item's position
			SparseBooleanArray checked = fileListView.getCheckedItemPositions();
			for (int i = 0; i < checked.size(); i++) {
				if (checked.valueAt(i)) {
					return checked.keyAt(i);
				}
			}
			return selectedIndex; // Fallback to last clicked position
		}
*
		private void launchVideoPlayer() {
			Intent playerIntent = new Intent(this, VideoPlayerActivity.class);
			playerIntent.putStringArrayListExtra("videoList", getSelectedVideos());
			playerIntent.putExtra("videoIndex", getSelectedIndex());
			startActivity(playerIntent);
		}
*/
		@Override
		public void onBackPressed() {
			// Optional: Add confirmation dialog if selections exist
			if (!selectedVideos.isEmpty()) {
				new AlertDialog.Builder(this)
					.setTitle("Discard selections?")
					.setMessage("You have selected videos. Are you sure you want to exit?")
					.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							VideoFilePickerActivity.super.onBackPressed();
						}
					})
					.setNegativeButton("Cancel", null)
					.show();
			} else {
				super.onBackPressed();
			}
		}

		// Handle runtime permissions for Android 6.0+
		private boolean checkStoragePermission() {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
				if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) 
					!= PackageManager.PERMISSION_GRANTED) {
					requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
					return false;
				}
			}
			return true;
		}

		@Override
		public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
			super.onRequestPermissionsResult(requestCode, permissions, grantResults);
			if (requestCode == 1) {
				if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
					loadVideoFiles();
					//setupFileBrowser();
				} else {
					Toast.makeText(this, "Permission needed to access videos", Toast.LENGTH_SHORT).show();
				}
			}
		}
	
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.video_sort_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_sort_name_asc || id == R.id.menu_sort_name_desc ||
            id == R.id.menu_sort_date_asc || id == R.id.menu_sort_date_desc ||
            id == R.id.menu_sort_size_asc || id == R.id.menu_sort_size_desc ||
            id == R.id.menu_sort_duration_asc || id == R.id.menu_sort_duration_desc) {

            currentSortOption = id;
            sortVideos();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void loadVideos() {
        videoItems.clear();

        ContentResolver contentResolver = getContentResolver();
        Uri videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED
        };

        String sortOrder = getSortOrder();
        Cursor cursor = contentResolver.query(videoUri, projection, null, null, sortOrder);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA));
                String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE));
                long duration = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION));
                long size = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE));
                long dateAdded = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED));

                videoItems.add(new VideoItem(path, title, duration, size, dateAdded * 1000));
            } while (cursor.moveToNext());
            cursor.close();
        }

        sortVideos();
    }
	
		

		

		public void setSortOption(int sortOption) {
			currentSortOption = sortOption;

			// Save to SharedPreferences
			SharedPreferences.Editor editor = sharedPrefs.edit();
			editor.putInt(PREF_SORT_OPTION, sortOption);
			editor.apply();

			sortVideos();
		}

		// Rest of your activity code...
	
	
	
    private String getSortOrder() {
        switch (currentSortOption) {
            case R.id.menu_sort_name_asc:
                return MediaStore.Video.Media.TITLE + " ASC";
            case R.id.menu_sort_name_desc:
                return MediaStore.Video.Media.TITLE + " DESC";
            case R.id.menu_sort_date_asc:
                return MediaStore.Video.Media.DATE_ADDED + " ASC";
            case R.id.menu_sort_date_desc:
                return MediaStore.Video.Media.DATE_ADDED + " DESC";
            case R.id.menu_sort_size_asc:
                return MediaStore.Video.Media.SIZE + " ASC";
            case R.id.menu_sort_size_desc:
                return MediaStore.Video.Media.SIZE + " DESC";
            case R.id.menu_sort_duration_asc:
                return MediaStore.Video.Media.DURATION + " ASC";
            case R.id.menu_sort_duration_desc:
                return MediaStore.Video.Media.DURATION + " DESC";
            default:
                return MediaStore.Video.Media.TITLE + " ASC";
        }
    }

    private void sortVideos() {
        Comparator<VideoItem> comparator = null;

        switch (currentSortOption) {
            case R.id.menu_sort_name_asc:
                comparator = new NameAscendingComparator();
                break;
            case R.id.menu_sort_name_desc:
                comparator = new NameDescendingComparator();
                break;
            case R.id.menu_sort_date_asc:
                comparator = new DateAscendingComparator();
                break;
            case R.id.menu_sort_date_desc:
                comparator = new DateDescendingComparator();
                break;
            case R.id.menu_sort_size_asc:
                comparator = new SizeAscendingComparator();
                break;
            case R.id.menu_sort_size_desc:
                comparator = new SizeDescendingComparator();
                break;
            case R.id.menu_sort_duration_asc:
                comparator = new DurationAscendingComparator();
                break;
            case R.id.menu_sort_duration_desc:
                comparator = new DurationDescendingComparator();
                break;
        }

        if (comparator != null) {
            Collections.sort(videoItems, comparator);
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onOptionsClicked(int position, View anchorView) {
        showVideoOptionsDialog(position, anchorView);
    }

    private void showVideoOptionsDialog(final int position, View anchorView) {
        final VideoItem videoItem = videoItems.get(position);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(videoItem.getTitle());

        String[] options = {"Play", "Share", "Delete", "Details"};
        builder.setItems(options, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					switch (which) {
						case 0: // Play
							playVideo(position);
							break;
						case 1: // Share
							shareVideo(position);
							break;
						case 2: // Delete
							confirmDeleteVideo(position);
							break;
						case 3: // Details
							showVideoDetails(position);
							break;
					}
				}
			});

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void playVideo(int position) {
        ArrayList<String> videoPaths = new ArrayList<String>();
        for (VideoItem item : videoItems) {
            videoPaths.add(item.getPath());
        }

        Intent intent = new Intent(this, VideoPlayerActivity.class);
        intent.putStringArrayListExtra("videoList", videoPaths);
        intent.putExtra("videoIndex", position);
        startActivity(intent);
    }

    private void shareVideo(int position) {
        VideoItem videoItem = videoItems.get(position);
        Uri videoUri = Uri.parse(videoItem.getPath());

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("video/*");
        shareIntent.putExtra(Intent.EXTRA_STREAM, videoUri);
        startActivity(Intent.createChooser(shareIntent, "Share Video"));
    }

    private void confirmDeleteVideo(final int position) {
        new AlertDialog.Builder(this)
            .setTitle("Delete Video")
            .setMessage("Are you sure you want to delete this video?")
            .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    deleteVideo(position);
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void deleteVideo(int position) {
        VideoItem videoItem = videoItems.get(position);

        // Delete from storage
        if (new File(videoItem.getPath()).delete()) {
            // Remove from list
            videoItems.remove(position);
            adapter.notifyDataSetChanged();

            // Update media store
            ContentResolver contentResolver = getContentResolver();
            contentResolver.delete(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
								   MediaStore.Video.Media.DATA + "=?", new String[]{videoItem.getPath()});

            Toast.makeText(this, "Video deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to delete video", Toast.LENGTH_SHORT).show();
        }
    }

    private void showVideoDetails(int position) {
        VideoItem videoItem = videoItems.get(position);

        String details = "Title: " + videoItem.getTitle() + "\n" +
			"Path: " + videoItem.getPath() + "\n" +
			"Size: " + adapter.formatFileSize(videoItem.getSize()) + "\n" +
			"Duration: " + adapter.formatDuration(videoItem.getDuration()) + "\n" +
			"Date Added: " + adapter.formatDate(videoItem.getDateAdded());

        new AlertDialog.Builder(this)
            .setTitle("Video Details")
            .setMessage(details)
            .setPositiveButton("OK", null)
            .show();
    }

    // Comparator classes
    private class NameAscendingComparator implements Comparator<VideoItem> {
        @Override
        public int compare(VideoItem v1, VideoItem v2) {
            return v1.getTitle().compareToIgnoreCase(v2.getTitle());
        }
    }

    private class NameDescendingComparator implements Comparator<VideoItem> {
        @Override
        public int compare(VideoItem v1, VideoItem v2) {
            return v2.getTitle().compareToIgnoreCase(v1.getTitle());
        }
    }

    private class DateAscendingComparator implements Comparator<VideoItem> {
        @Override
        public int compare(VideoItem v1, VideoItem v2) {
            return Long.compare(v1.getDateAdded(), v2.getDateAdded());
        }
    }

    private class DateDescendingComparator implements Comparator<VideoItem> {
        @Override
        public int compare(VideoItem v1, VideoItem v2) {
            return Long.compare(v2.getDateAdded(), v1.getDateAdded());
        }
    }

    private class SizeAscendingComparator implements Comparator<VideoItem> {
        @Override
        public int compare(VideoItem v1, VideoItem v2) {
            return Long.compare(v1.getSize(), v2.getSize());
        }
    }

    private class SizeDescendingComparator implements Comparator<VideoItem> {
        @Override
        public int compare(VideoItem v1, VideoItem v2) {
            return Long.compare(v2.getSize(), v1.getSize());
        }
    }

    private class DurationAscendingComparator implements Comparator<VideoItem> {
        @Override
        public int compare(VideoItem v1, VideoItem v2) {
            return Long.compare(v1.getDuration(), v2.getDuration());
        }
    }

    private class DurationDescendingComparator implements Comparator<VideoItem> {
        @Override
        public int compare(VideoItem v1, VideoItem v2) {
            return Long.compare(v2.getDuration(), v1.getDuration());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadVideos();
		APEvents.getInstance().addPlaybackEventListener(this);
		AudioService.connect(this, this);
		
    }
	

		@Override
		public void onSearchResultItemClick(SongItem si)
		{

		}

		@Override
		public void onSongsListUpdated(List<SongItem> ulist)
		{

		}


		


		


		@Override
		public void onCreate(Bundle savedInstanceState) {

			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_video_file_picker);
			sharedPrefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

			// Load saved sort option or use default
			currentSortOption = sharedPrefs.getInt(PREF_SORT_OPTION, DEFAULT_SORT_OPTION);
			
			
			init();
		}

	private void init() {
		handle = new Handler();

		// Initialize audio player views
		currentTitle = findView(R.id.auplayer_tv_title);
		currentArtist = findView(R.id.auplayer_tv_artist);
		art2Background = findView(R.id.aupalyer_iv_art2_background);
		currentArt = findView(R.id.auplayer_iv_art);
		playpauseIcon = findView(R.id.auplayer_btn_playpause);

		// Initialize video list
		videoListView = findViewById(R.id.list_view_list1);

		// Initialize adapter with click listeners
		adapter = new VideoAdapter(this, videoItems, 
			new VideoAdapter.OnVideoOptionsListener() {
				@Override
				public void onOptionsClicked(int position, View anchorView) {
					showVideoOptionsDialog(position, anchorView);
				}
			},
			new VideoAdapter.OnVideoClickListener() {
				@Override
				public void onVideoClicked(int position) {
					playVideo(position);
				}
			});

		videoListView.setAdapter(adapter);
		loadVideos();

		// Remove the old OnItemClickListener since we're handling clicks in the adapter
		// The adapter now handles both regular clicks and options clicks

		// Initialize SeekBar and its listeners
		seeker = findView(R.id.aupalyer_seeker);
		seeker.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int pos, boolean touch) {
					if (audioService != null && seektouch) {
						audioService.seekTo(pos);
						trackTimeCurrent.setText(formatTime(pos));
					}
				}

				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {
					stopSeeker();
					seektouch = true;
				}

				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {
					seektouch = false;
					if (audioService != null && audioService.isPlaying()) {
						startSeeker();
					}
				}
			});

		seekerTick = new Runnable() {
			@Override
			public void run() {
				if (audioService != null) {
					int pos = audioService.getCurrentPosition();
					seeker.setProgress(pos);
					trackTimeCurrent.setText(formatTime(pos));
					handle.postDelayed(this, 1000);
				}
			}
		};

		trackTimeCurrent = findView(R.id.auplayer_currentpos);
		trackTimeDuration = findView(R.id.auplayer_duration);

		// Set clickable buttons
		setClickable(R.id.auplayer_btn_playpause);
		setClickable(R.id.auplayer_btn_prev);
		setClickable(R.id.auplayer_btn_next);
		setClickable(R.id.auplayer_btn_options);
		setClickable(R.id.auplayer_btn_back);
		
		//fileListView = findViewById(R.id.fileListView);
		//btnSelect = findViewById(R.id.btnSelect);

		// Load any existing video list from intent
		ArrayList<String> existingList = getIntent().getStringArrayListExtra("videoList");
		if (existingList != null) {
			videoPaths.addAll(existingList);
			selectedIndex = getIntent().getIntExtra("videoIndex", 0);
		} else {
			loadVideoFiles();
		}

		//setupFileBrowser();
		
	}

	



		private void updateInfo(){
			final SongItem si = audioService.getCurrentSong();
			if(audioService==null || si==null){
				return;
			}

			currentTitle.setText(si.title);
			currentArtist.setText(si.artist);

			hideView(R.id.auplayer_iv_art_b);
			if(si.getId()!=null){
				currentArt.setImageBitmap(si.getThumbnail());
				setLargeArt(si.getThumbnail());
			}else{
				App.runInBackground(new Runnable(){
						public void run(){
							final Bitmap bmp = BitmapUtils.tint(ctx.getResources(), R.drawable.cover_f, ThemeManager.getTheme().icon);
							if(bmp!=null){
								handle.post(new Runnable(){
										public void run(){
											currentArt.setImageBitmap(bmp);
										}
									});
							}
						}
					});
				//showView(R.id.auplayer_iv_art_b);
				setLargeArt( BitmapFactory.decodeResource(ctx.getResources(), R.drawable.fill));
			}

			if(audioService!=null){
				if(audioService.isPlaying()){
					playpauseIcon.setBackgroundResource(R.drawable.ic_pause);
				}else{
					playpauseIcon.setBackgroundResource(R.drawable.ic_play);
				}
			}

			playpauseIcon.reset();

			//playpauseIcon.setTint(tm.);

			int pos = audioService.getCurrentPosition();
			trackTimeDuration.setText(formatTime((int)si.duration));
			trackTimeCurrent.setText(formatTime(pos));

			seeker.setMax((int)si.duration);
			seeker.setProgress(pos);

			//
		}

		private void setLargeArt(final Bitmap bmp){
			art2Background.setBackgroundDrawable(new BitmapDrawable(bmp));
			App.runInBackground(new Runnable(){
					public void run(){
						final Bitmap img = FastBlur.fastblur(bmp,0.2f,3);
						if(img!=null){
							App.runInUiThread(new Runnable(){
									public void run(){
										art2Background.setBackgroundDrawable(new BitmapDrawable(img));
									}
								});
						}
					}
				});
		}


		ThemeManager.Theme theme;

		// todo: this takes too long
		@Override
		protected void onApplyTheme(ThemeManager.Theme theme)
		{
			super.onApplyTheme(theme);
			this.theme = theme;
			//
			themer.dispatchMessage(new Message());
		}

		Handler themer = new Handler(){
			@Override
			public void handleMessage(Message msg)
			{
				super.handleMessage(msg);
				//
				setTextViewsColor(theme.text,
								  trackTimeCurrent,
								  trackTimeDuration,
								  currentArtist,
								  currentTitle);
				//
				currentTitle.setBackgroundColor(theme.background);
				currentArtist.setBackgroundColor(theme.background);
				//
				setTintablesTint(theme.icon,
								 R.id.au1,
								 R.id.au2,
								 R.id.au3,
								 R.id.au4,
								 R.id.auplayer_btn_playpause);
				//
				seeker.getProgressDrawable().setColorFilter(theme.icon, PorterDuff.Mode.SRC_ATOP);
				seeker.getThumb().setColorFilter(theme.icon, PorterDuff.Mode.SRC_ATOP);
			}
		};


		private void startSeeker(){
			stopSeeker();
			handle.postDelayed(seekerTick,0);
		}

		private void stopSeeker(){
			handle.removeCallbacks(seekerTick);
			handle.removeCallbacks(seekerTick);
		}

		private String formatTime(int time){
			//String t = "";
			int hrs = (int) (time/ (1000*60*60)) % 60;
			int min = (int) ( time/ (1000*60)) % 60;
			int sec = (int) (time /1000) % 60;
			if(hrs==0){
				return d(min)+":"+d(sec);
			}

			return d(hrs)+":"+d(min)+":"+d(sec);
		}

		private String d(int t){
			if(t<10){
				return "0"+t;
			}
			return ""+t;
		}

		@Override
		public void onClick(View v){
			int id = v.getId();
			switch(id){
				case R.id.auplayer_btn_playpause:
					if(audioService != null){
						audioService.playPause();
					}
					break;
				case R.id.auplayer_btn_next:
					if(audioService != null){
						audioService.playNext();
					}
					break;
				case R.id.auplayer_btn_prev:
					if(audioService != null){
						audioService.playPrev();
					}
					break;
				case R.id.auplayer_btn_back:
					finish();
					break;
					// case R.id.auplayer_btn_menu_songs:
					// Get the current song queue from the audio service
					//startActivity(CurrentQueue.class);
					//break;
				case R.id.auplayer_btn_options:
					 new VideoFilePickerDialog(this).show();
				//	sortVideos();
					break;
			}
		}




		@Override
		public void onAudioServiceConnect(AudioService service){
			audioService = service;
			audioService.requestPlaystateUpdate();
		}

		@Override
		public void onPlaybackStart(){
			playpauseIcon.setBackgroundResourceAndReset(R.drawable.ic_pause);
			startSeeker();
		}

		@Override
		public void onPlaybackPause(){
			playpauseIcon.setBackgroundResourceAndReset(R.drawable.ic_play);
			stopSeeker();
		}

		@Override
		public void onPlaybackStop(){
			updateInfo();
			playpauseIcon.setBackgroundResourceAndReset(R.drawable.ic_play);
			stopSeeker();
		}

		@Override
		public void onSongChanged(SongItem newsong){
			updateInfo();
		}


		@Override
		protected void onPause(){
			stopSeeker();
			APEvents.getInstance().removePlaybackEventListener(this);
			super.onPause();
		}


		

		public void launchCurrentQueueActivity() {
			Intent intent = new Intent(this, PlaylistDetailsActivity.class);
			intent.putParcelableArrayListExtra("songQueue", songQueue);
			startActivity(intent);
		} 



		private void updateUI(SongItem song) {
			songTitle.setText(song.title);
			songArtist.setText(song.artist);
		}


			
		

		private void onVideoSelected(VideoItem videoItem) {
			this.selectedVideo = videoItem;
			showOptionsDialog();
		}

		public void showOptionsDialog() {
			if (selectedVideo != null) {
				VideoFilePickerDialog dialog = new VideoFilePickerDialog(this);
				dialog.show();
			}
		}

		// Load videos from storage
		

		

		public int getCurrentSortOption() {
			return currentSortOption;
		}

		

		public void playSelectedVideo() {
			if (selectedVideo != null) {
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setDataAndType(Uri.parse(selectedVideo.getPath()), "video/*");
				intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
				startActivity(intent);
			}
		}

		public void shareSelectedVideo() {
			if (selectedVideo != null) {
				Intent shareIntent = new Intent(Intent.ACTION_SEND);
				shareIntent.setType("video/*");
				shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse(selectedVideo.getPath()));
				startActivity(Intent.createChooser(shareIntent, "Share Video"));
			}
		}

		public void deleteSelectedVideo() {
			if (selectedVideo != null) {
				new AlertDialog.Builder(this)
					.setTitle("Delete Video")
					.setMessage("Are you sure you want to delete " + selectedVideo.getTitle() + "?")
					.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							File file = new File(selectedVideo.getPath());
							if (file.delete()) {
								// Remove from media store
								getContentResolver().delete(
									MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
									MediaStore.Video.Media.DATA + "=?",
									new String[]{selectedVideo.getPath()}
								);

								// Remove from list
								int position = videoItems.indexOf(selectedVideo);
								videoItems.remove(position);
								adapter.notifyDataSetChanged();//(position);
							}
						}
					})
					.setNegativeButton("Cancel", null)
					.show();
			}
		}

		public void showVideoDetails() {
			if (selectedVideo != null) {
				String details = "Name: " + selectedVideo.getTitle() + "\n" +
					"Size: " + formatSize(selectedVideo.getSize()) + "\n" +
					"Duration: " + formatDuration(selectedVideo.getDuration()) + "\n" +
					"Path: " + selectedVideo.getPath();

				new AlertDialog.Builder(this)
					.setTitle("Video Details")
					.setMessage(details)
					.setPositiveButton("OK", null)
					.show();
			}
		}

		private String formatSize(long size) {
			if (size <= 0) return "0 B";
			final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
			int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
			return String.format("%.1f %s", size / Math.pow(1024, digitGroups), units[digitGroups]);
		}

		private String formatDuration(long duration) {
			if (duration <= 0) return "0:00";
			duration /= 1000; // convert to seconds
			long minutes = duration / 60;
			long seconds = duration % 60;
			return String.format("%d:%02d", minutes, seconds);
		}
	}
