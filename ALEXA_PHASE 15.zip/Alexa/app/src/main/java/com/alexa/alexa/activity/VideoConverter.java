package com.alexa.alexa.activity;

import java.io.IOException;

public class VideoConverter
 {

    // Method to convert a video to a compatible format
    public static void convertVideo(String inputPath, String outputPath) {
        // FFmpeg command for converting the video with H.263 codec and AMR-NB audio codec
        String ffmpegCommand = "ffmpeg -i " + inputPath + " -vcodec h263 -acodec amr_nb -ar 8000 -b:v 200k -s 176x144 -r 15 " + outputPath;

        try {
            // Create a new process to run the FFmpeg command
            Process process = Runtime.getRuntime().exec(ffmpegCommand);

            // Wait for the process to complete
            process.waitFor();

            // Print success message when the conversion is completed
            System.out.println("Video conversion completed successfully!");

        } catch (IOException | InterruptedException e) {
            // Catch any exceptions and print the error
            e.printStackTrace();
        }
    }
}
