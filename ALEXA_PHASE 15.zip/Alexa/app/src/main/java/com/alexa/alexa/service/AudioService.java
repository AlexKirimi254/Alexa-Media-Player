package com.alexa.alexa.service;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.App;
import com.alexa.alexa.Constants;
import com.alexa.alexa.XApp;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.library.SongLibrary;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.recievers.ButtonReciever;
import com.alexa.alexa.utils.EqualizerUtils;
import com.alexa.alexa.utils.Notific;
import com.alexa.alexa.utils.SPrefs;
import com.alexa.alexa.utils.Utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class AudioService extends Service implements MediaPlayer.OnCompletionListener,
MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener {

    private List<SongItem> songQueue;
    public static final String PREF_NAME = "AudioPreferences";
    private SharedPreferences sharedPreferences;
    private Gson gson;
    private static String TAG = "AudioService";
    private ComponentName mediaButtonComponent;
    private final int NID = 5374;
    private int currentSongIndex;
    private Context ctx;
    private MediaPlayer mPlayer;
    private MediaPlayer nextPlayer;
    private AudioManager am;
    private PowerManager.WakeLock wakelock;
    private SPrefs prefs;
    private final IBinder binder = new LocalBinder();
    private SongItem currentSong;
    private Handler handle = new Handler();
    private String currentSongPath;
    private boolean restartCurrentOnPrev = false;
    private boolean songset = false;
    private boolean recieversRegistered = false;
    private List<SongItem> songlist = new ArrayList<>();
    private static AudioService instance;
    private boolean isShuffleEnabled = false;
    private RepeatMode repeatMode = RepeatMode.NONE;
    private Activity act;
    private QueueManager queueManager;
    private static final String KEY_CROSSFADE_DURATION = "crossfade_duration";
    private static final int DEFAULT_CROSSFADE_DURATION = 20000;
    private int crossfadeDuration;
    private boolean isCrossfading = false;
    private Handler crossfadeHandler = new Handler();
    private Runnable crossfadeRunnable;
    private Handler progressHandler = new Handler();
    private Runnable progressCheck;
    private boolean crossfadeTriggered = false;
    public static String ACTION_SONG_CHANGED = "com.alexa.alexa.ACTION_SONG_CHANGED";
    public static String ACTION_CROSSFADE_STARTED = "com.alexa.alexa.ACTION_CROSSFADE_STARTED";
    public static String ACTION_CROSSFADE_COMPLETED = "com.alexa.alexa.ACTION_CROSSFADE_COMPLETED";
    private static final String QUEUE_KEY = "songs_queue";
    private static final String CHANNEL_ID = "ALEXA_Audio_CHANNEL";
    private int repeatPointA = -1;
    private int repeatPointB = -1;
    private boolean isABRepeatEnabled = false;

    public SongItem getNextSong() {
        if (queueManager == null || queueManager.getQueue() == null || queueManager.getQueue().isEmpty()) {
            return null;
        }

        int currentIndex = queueManager.getCurrentIndex();
        if (currentIndex < 0 || currentIndex >= queueManager.getQueue().size() - 1) {
            if (repeatMode == RepeatMode.REPEAT_ALL) {
                return queueManager.getQueue().get(0);
            }
            return null;
        }

        return queueManager.getQueue().get(currentIndex + 1);
    }

    public MediaPlayer getMediaPlayer() {
        return mPlayer;
    }

    public RepeatMode getRepeatMode() {
        return repeatMode;
    }

    public enum RepeatMode {
        NONE,
        REPEAT_ONE,
        REPEAT_ALL
		}

    public void setMediaPlayer(MediaPlayer player) {
        if (mPlayer != null) {
            mPlayer.release();
        }
        mPlayer = player;

        if (mPlayer != null) {
            mPlayer.setOnCompletionListener(this);
            mPlayer.setOnPreparedListener(this);
            mPlayer.setOnErrorListener(this);
        }
    }

    
	public void updateCurrentSong(SongItem song, int index) {
        currentSong = song;
        currentSongIndex = index;
        songset = true;
        prefs.saveLastPath(song.path);
        showNotification();
        APEvents.getInstance().postPlayStateEvent_start();
        APEvents.getInstance().postSongChangeEvent(currentSong);
    }
	public void setRepeatMode(RepeatMode mode) {
        this.repeatMode = mode;
    }
    

    
    @Override
    public void onCreate() {
        super.onCreate();

        instance = this;
        ctx = getApplicationContext();
        prefs = new SPrefs(this);
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        gson = new Gson();
        queueManager = QueueManager.getInstance();
        restartCurrentOnPrev = prefs.getRestartSongOnPrev();
        initMPlayer();
        songQueue = loadQueueFromPreferences();
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakelock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, TAG);
        createNotificationChannel();
        setupPhoneCallListener();

        crossfadeDuration = sharedPreferences.getInt(KEY_CROSSFADE_DURATION, DEFAULT_CROSSFADE_DURATION);

        App.get().registerAudiosService(this);

        startProgressCheck();
    }

    private void initMPlayerr() {
        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setOnCompletionListener(this);
        mPlayer.setOnPreparedListener(this);
        mPlayer.setOnErrorListener(this);
    }
	private void initMPlayer(){
        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		//mPlayer.setOnPreparedListener(this);
      //  mPlayer.setOnErrorListener(this);
        mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
                @Override
                public void onCompletion(MediaPlayer p1){
                    playNext();
                }
            });
    }
    private void startProgressCheck() {
        progressCheck = new Runnable() {
            public void run() {
                if (mPlayer != null && mPlayer.isPlaying() && !isCrossfading) {
                    int currentPos = mPlayer.getCurrentPosition();
                    int duration = mPlayer.getDuration();
                    if (isABRepeatEnabled && repeatPointB != -1 && currentPos >= repeatPointB) {
                        mPlayer.seekTo(repeatPointA);
                        progressHandler.postDelayed(this, 100);
                    } else if (!isABRepeatEnabled && crossfadeDuration > 0 && duration > 0 && 
							   currentPos >= duration - crossfadeDuration && !crossfadeTriggered) {
                        crossfadeTriggered = true;
                        startCrossfadeToNext();
                    } else {
                        crossfadeTriggered = false;
                        progressHandler.postDelayed(this, 100);
                    }
                } else {
                    progressHandler.postDelayed(this, 100);
                }
            }
        };
        progressHandler.post(progressCheck);
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        if (repeatMode == RepeatMode.REPEAT_ONE) {
            playSong(songQueue.get(currentSongIndex));
        } else if (!isCrossfading) {
            startCrossfadeToNext();
        }
    }

    public void toggleRepeat() {
        switch (repeatMode) {
            case NONE:
                repeatMode = RepeatMode.REPEAT_ALL;
                break;
            case REPEAT_ALL:
                repeatMode = RepeatMode.REPEAT_ONE;
                break;
            default:
                repeatMode = RepeatMode.NONE;
                break;
        }
    }

    public void toggleShuffle() {
        isShuffleEnabled = !isShuffleEnabled;
        if (isShuffleEnabled) {
            Collections.shuffle(songQueue);
        }
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        mp.start();
        showNotification();
        notifySongChanged();
        progressHandler.post(progressCheck);
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        return false;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public class LocalBinder extends Binder {
        public AudioService getService() {
            return AudioService.this;
        }
    }

    private void startCrossfadeToNext() {
        if (songQueue.isEmpty() || crossfadeDuration <= 0 || isCrossfading) {
            playNext();
            return;
        }

        final int nextIndex = getNextSongIndex();
        if (nextIndex == -1) {
            stopPlayback();
            return;
        }

        final SongItem nextSong = songQueue.get(nextIndex);
        if (nextSong == null) {
            stopPlayback();
            return;
        }

        try {
            nextPlayer = new MediaPlayer();
            nextPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            nextPlayer.setDataSource(nextSong.path);
            nextPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
					public void onPrepared(MediaPlayer mp) {
						nextPlayer.start();
						nextPlayer.setVolume(0.0f, 0.0f);
						isCrossfading = true;
						notifyCrossfadeStarted();
						performCrossfade(nextSong, nextIndex);
					}
				});
            nextPlayer.setOnErrorListener(this);
            nextPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
            playNext();
        }
    }

    private void performCrossfade(final SongItem nextSong, final int nextIndex) {
        final int steps = 50;
        final long interval = crossfadeDuration / steps;
        final float volumeStep = 1.0f / steps;

        crossfadeHandler.removeCallbacksAndMessages(null);
        crossfadeRunnable = new Runnable() {
            private int currentStep = 0;

            public void run() {
                if (!isCrossfading || mPlayer == null || nextPlayer == null) {
                    completeCrossfade(nextSong, nextIndex);
                    return;
                }

                float outgoingVolume = 1.0f - (volumeStep * currentStep);
                float incomingVolume = volumeStep * currentStep;

                if (outgoingVolume < 0.0f) outgoingVolume = 0.0f;
                if (incomingVolume > 1.0f) incomingVolume = 1.0f;

                mPlayer.setVolume(outgoingVolume, outgoingVolume);
                nextPlayer.setVolume(incomingVolume, incomingVolume);

                currentStep++;
                if (currentStep <= steps) {
                    crossfadeHandler.postDelayed(this, interval);
                } else {
                    completeCrossfade(nextSong, nextIndex);
                }
            }
        };
        crossfadeHandler.post(crossfadeRunnable);
    }

    private void completeCrossfade(SongItem nextSong, int nextIndex) {
        isCrossfading = false;
        crossfadeHandler.removeCallbacksAndMessages(null);

        if (mPlayer != null) {
            mPlayer.stop();
            mPlayer.release();
        }

        mPlayer = nextPlayer;
        nextPlayer = null;
        mPlayer.setOnCompletionListener(this);
        mPlayer.setOnPreparedListener(this);
        mPlayer.setOnErrorListener(this);

        currentSong = nextSong;
        currentSongIndex = nextIndex;
        songset = true;
        prefs.saveLastPath(currentSong.path);
        showNotification();
        notifySongChanged();
        notifyCrossfadeCompleted();
        APEvents.getInstance().postPlayStateEvent_start();
        APEvents.getInstance().postSongChangeEvent(currentSong);
    }

    private void notifyCrossfadeStarted() {
        Intent intent = new Intent(ACTION_CROSSFADE_STARTED);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void notifyCrossfadeCompleted() {
        Intent intent = new Intent(ACTION_CROSSFADE_COMPLETED);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private int getNextSongIndex() {
        if (isShuffleEnabled) {
            return new Random().nextInt(songQueue.size());
        } else {
            if (currentSongIndex < songQueue.size() - 1) {
                return currentSongIndex + 1;
            } else if (repeatMode == RepeatMode.REPEAT_ALL) {
                return 0;
            } else {
                return -1;
            }
        }
    }

    public void setCrossfadeDuration(int durationMs) {
        if (durationMs >= 0) {
            crossfadeDuration = durationMs;
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt(KEY_CROSSFADE_DURATION, durationMs);
            editor.apply();
        }
    }

    public int getCrossfadeDuration() {
        return crossfadeDuration;
    }

    public void playQueue(List<SongItem> queue, int startIndex) {
        if (queue == null || queue.isEmpty()) {
            return;
        }

        this.songQueue.clear();
        this.songQueue.addAll(queue);

        if (startIndex < 0 || startIndex >= songQueue.size()) {
            startIndex = 0;
        }

        this.currentSongIndex = startIndex;
        this.currentSong = songQueue.get(currentSongIndex);

        stop();
        prepareAndPlay(currentSong);
        notifyQueueChanged();
        notifySongChanged();
    }

    private void prepareAndPlay(SongItem song) {
        if (song == null) {
            return;
        }

        try {
            if (mPlayer != null) {
                mPlayer.reset();
            } else {
                mPlayer = new MediaPlayer();
                mPlayer.setOnCompletionListener(this);
            }

            mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mPlayer.setDataSource(song.path);
            mPlayer.prepare();
            mPlayer.start();

            songset = true;
            currentSong = song;

            showNotification();
            notifySongChanged();
            progressHandler.post(progressCheck);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void notifyQueueChanged() {
        Intent intent = new Intent("com.alexa.alexa.ACTION_QUEUE_CHANGED");
        intent.putParcelableArrayListExtra("queue", new ArrayList<>(songQueue));
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void notifySongChanged() {
        Intent intent = new Intent(ACTION_SONG_CHANGED);
        intent.putExtra("song", currentSong);
        intent.putExtra("position", currentSongIndex);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    public void clearABRepeat() {
        repeatPointA = -1;
        repeatPointB = -1;
        isABRepeatEnabled = false;
    }

    public void setRepeatPointA() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            repeatPointA = mPlayer.getCurrentPosition();
            isABRepeatEnabled = false;
        }
    }

    public void setRepeatPointB() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            repeatPointB = mPlayer.getCurrentPosition();
            if (repeatPointA != -1 && repeatPointB > repeatPointA) {
                isABRepeatEnabled = true;
            }
        }
    }

    private void setupPhoneCallListener() {
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        telephonyManager.listen(new PhoneStateListener() {
				public void onCallStateChanged(int state, String incomingNumber) {
					if (state == TelephonyManager.CALL_STATE_RINGING || state == TelephonyManager.CALL_STATE_OFFHOOK) {
						pause();
					}
				}
			}, PhoneStateListener.LISTEN_CALL_STATE);
    }

    public void addToQueue(Object item) {
        boolean shouldStartPlayback = songQueue.isEmpty() && !isPlaying();

        if (item instanceof SongItem) {
            SongItem song = (SongItem) item;
            if (!songQueue.contains(song)) {
                songQueue.add(song);
                saveQueueToPreferences();
                if (shouldStartPlayback) {
                    currentSongIndex = 0;
                    playSong(songQueue.get(currentSongIndex));
                }
            }
        } else if (item instanceof List<?>) {
            List<SongItem> songs = (List<SongItem>) item;
            boolean newSongsAdded = false;
            for (SongItem song : songs) {
                if (!songQueue.contains(song)) {
                    songQueue.add(song);
                    newSongsAdded = true;
                }
            }
            saveQueueToPreferences();
            if (shouldStartPlayback && newSongsAdded) {
                currentSongIndex = 0;
                playSong(songQueue.get(currentSongIndex));
            }
        } else if (item instanceof Playlist) {
            Playlist playlist = (Playlist) item;
            List<SongItem> playlistSongs = playlist.getSongs();
            boolean newSongsAdded = false;
            for (SongItem song : playlistSongs) {
                if (!songQueue.contains(song)) {
                    songQueue.add(song);
                    newSongsAdded = true;
                }
            }
            saveQueueToPreferences();
            if (shouldStartPlayback && newSongsAdded) {
                currentSongIndex = 0;
                playSong(songQueue.get(currentSongIndex));
            }
        } else {
            throw new IllegalArgumentException("Unsupported parameter type for addToQueue");
        }
    }

    private void saveQueueToPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String json = gson.toJson(songQueue);
        editor.putString(QUEUE_KEY, json);
        editor.apply();
    }

    public void addToPlaylist(Object item, Playlist targetPlaylist) {
        if (targetPlaylist == null) {
            throw new IllegalArgumentException("Target playlist cannot be null");
        }

        boolean updated = false;

        if (item instanceof SongItem) {
            SongItem song = (SongItem) item;
            if (!targetPlaylist.getSongs().contains(song)) {
                targetPlaylist.getSongs().add(song);
                updated = true;
            }
        } else if (item instanceof List<?>) {
            List<SongItem> songs = (List<SongItem>) item;
            for (SongItem song : songs) {
                if (!targetPlaylist.getSongs().contains(song)) {
                    targetPlaylist.getSongs().add(song);
                    updated = true;
                }
            }
        } else if (item instanceof Playlist) {
            Playlist sourcePlaylist = (Playlist) item;
            for (SongItem song : sourcePlaylist.getSongs()) {
                if (!targetPlaylist.getSongs().contains(song)) {
                    targetPlaylist.getSongs().add(song);
                    updated = true;
                }
            }
        } else {
            throw new IllegalArgumentException("Unsupported parameter type for addToPlaylist");
        }

        if (updated) {
            App.get().getMainActivity().refreshPlaylistsTab();
            Toast.makeText(ctx, "Songs added to playlist '" + targetPlaylist.getName() + "'", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(ctx, "No new songs added. Playlist already contains these songs.", Toast.LENGTH_SHORT).show();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
				CHANNEL_ID,
				"Alexa Audio Service Channel",
				NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    public void playFromIntent(final Context context, String intentAction) {
        initMPlayer();

        Intent intent = ((Activity) context).getIntent();
        if (intent == null || intent.getData() == null) {
            Toast.makeText(context, "No file to play", Toast.LENGTH_SHORT).show();
            return;
        }

        final Uri songUri = intent.getData();
        final AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        final AudioManager.OnAudioFocusChangeListener focusChangeListener = new AudioManager.OnAudioFocusChangeListener() {
            public void onAudioFocusChange(int focusChange) {
                if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                    pause();
                }
            }
        };

        int result = audioManager.requestAudioFocus(focusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        if (result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            Toast.makeText(context, "Unable to gain audio focus", Toast.LENGTH_SHORT).show();
            return;
        }

        if (mPlayer.isPlaying()) {
            mPlayer.stop();
        }

        mPlayer.reset();

        ContentResolver contentResolver = context.getContentResolver();
        AssetFileDescriptor assetFileDescriptor = null;

        try {
            assetFileDescriptor = contentResolver.openAssetFileDescriptor(songUri, "r");
            if (assetFileDescriptor != null) {
                mPlayer.setDataSource(assetFileDescriptor.getFileDescriptor());
                mPlayer.prepare();
                mPlayer.start();
                showNotification();

                currentSong = new SongItem();
                currentSong.path = songUri.toString();

                APEvents.getInstance().postSongChangeEvent(currentSong);
            } else {
                Toast.makeText(context, "Unable to access the file", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Unable to play the selected file", Toast.LENGTH_SHORT).show();
        } finally {
            if (assetFileDescriptor != null) {
                try {
                    assetFileDescriptor.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void clearQueue() {
        songQueue.clear();
        saveQueueToPreferences();
    }

    public void onQueueRearranged(List<SongItem> newQueue) {
        songQueue.clear();
        songQueue.addAll(newQueue);
        int idx = songQueue.indexOf(currentSong);
        if (idx != -1) {
            if (idx != currentSongIndex) {
                currentSongIndex = idx;
                mPlayer.stop();
                mPlayer.reset();
                playSong(currentSong);
            }
        } else {
            mPlayer.stop();
            mPlayer.reset();
        }
    }

    private ArrayList<SongItem> loadQueueFromPreferences() {
        String json = sharedPreferences.getString(QUEUE_KEY, null);
        if (json != null) {
            Type type = new TypeToken<ArrayList<SongItem>>() {}.getType();
            return gson.fromJson(json, type);
        }
        return new ArrayList<>();
    }

    public void playSong(SongItem si) {
        if (si == null || mPlayer == null) {
            return;
        }

        if (mPlayer.isPlaying() && crossfadeDuration > 0) {
            startCrossfadeToSong(si);
        } else {
            mPlayer.stop();
            mPlayer.reset();
            currentSong = si;
            prefs.saveLastPath(si.path);

            try {
                mPlayer.setDataSource(si.path);
                songset = true;
                mPlayer.prepare();
                int lastSeekPosition = prefs.getLastSeekPosition(si.path);
                if (lastSeekPosition > 0) {
                    mPlayer.seekTo(lastSeekPosition);
                }
                resume();
                APEvents.getInstance().postSongChangeEvent(currentSong);
                APEvents.getInstance().postPlayStateEvent_start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void startCrossfadeToSong(final SongItem nextSong) {
        try {
            nextPlayer = new MediaPlayer();
            nextPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            nextPlayer.setDataSource(nextSong.path);
            nextPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
					public void onPrepared(MediaPlayer mp) {
						nextPlayer.start();
						nextPlayer.setVolume(0.0f, 0.0f);
						isCrossfading = true;
						notifyCrossfadeStarted();
						performCrossfade(nextSong, songQueue.indexOf(nextSong));
					}
				});
            nextPlayer.setOnErrorListener(this);
            nextPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
            playSong(nextSong);
        }
    }

    public void setSong(SongItem si) {
        currentSong = si;
        try {
            mPlayer.setDataSource(si.path);
            mPlayer.prepare();
            songset = true;
            APEvents.getInstance().postSongChangeEvent(currentSong);
        } catch (IllegalArgumentException e) {
        } catch (IllegalStateException e) {
        } catch (IOException e) {
        } catch (SecurityException e) {
        }
    }

    public void playPause() {
        if (currentSong != null) {
            if (isPlaying()) {
                pause();
            } else {
                if (songset) {
                    resume();
                } else {
                    playSong(currentSong);
                }
            }
        } else {
            if (!songQueue.isEmpty()) {
                currentSong = songQueue.get(0);
                if (currentSong != null) {
                    playSong(currentSong);
                }
            }
        }
    }

    public void resume() {
        try {
            mPlayer.start();
            APEvents.getInstance().postPlayStateEvent_start();
            showNotification();
            registerRecievers();
            progressHandler.post(progressCheck);
        } catch (Exception e) {
            toast(e.getMessage());
        }
    }

    public void pause() {
        if (mPlayer.isPlaying()) {
            int position = mPlayer.getCurrentPosition();
            prefs.saveLastSeekPosition(currentSong.path, position);
            mPlayer.pause();
        }
        stopNotification();
        releaseWakeLock();
        APEvents.getInstance().postPlayStateEvent_pause();
    }

    public void stop() {
        if (mPlayer.isPlaying()) {
            int position = mPlayer.getCurrentPosition();
            prefs.saveLastSeekPosition(currentSong.path, position);
            mPlayer.stop();
        }
        mPlayer.reset();
        stopNotification();
        unregisterRecievers();
        APEvents.getInstance().postPlayStateEvent_stop();
    }

    public void playNext() {
        startCrossfadeToNext();
    }

    public void playPrev() {
        if (songQueue.isEmpty()) {
            return;
        }

        int idx = songQueue.indexOf(currentSong);
        idx--;
        if (idx < 0) {
            idx = 0;
        }

        boolean restart = false;
        if (restartCurrentOnPrev) {
            int ct = mPlayer.getCurrentPosition();
            if (ct > 6000) {
                restart = true;
            }
        }

        if (restart) {
            mPlayer.seekTo(0);
        } else {
            mPlayer.stop();
            mPlayer.reset();
            currentSong = songQueue.get(idx);
            prefs.saveLastSeekPosition(currentSong.path, 0);
            playSong(currentSong);
        }
    }

    private void stopPlayback() {
        if (mPlayer.isPlaying()) {
            mPlayer.stop();
        }
        currentSongIndex = -1;
        songset = false;
        stopNotification();
    }

    public static AudioService getInstance() {
        return instance;
    }

    public void openEqualizerPanel(Activity activity) {
        if (EqualizerUtils.hasEqualizer(ctx)) {
            EqualizerUtils.openEqualizer(activity, mPlayer);
        } else {
            Toast.makeText(ctx, "No equalizer available on this device.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String cmd = intent.getAction();
            if (cmd != null) {
                switch (cmd) {
                    case Constants.CMD_START:
                        cmd_start();
                        break;
                    case Constants.CMD_END:
                        cmd_end();
                        break;
                    case Constants.CMD_PLAY:
                        resume();
                        break;
                    case Constants.CMD_PAUSE:
                        pause();
                        break;
                    case Constants.CMD_PLAY_NEXT:
                        playNext();
                        break;
                    case Constants.CMD_PLAY_PREV:
                        playPrev();
                        break;
                    case Constants.CMD_MEDIA_BUTTON:
                        handleMediabtn();
                        break;
                    case Constants.CMD_PLAY_FROM_INTENT:
                        cmd_start();
                        String songPath = intent.getStringExtra("song_path");
                        if (songPath != null && !songPath.isEmpty()) {
                            try {
                                playFromIntent(this, songPath);
                            } catch (Exception e) {
                                Log.e(TAG, "Error playing from intent: " + e.getMessage());
                            }
                        } else {
                            Log.e(TAG, "Invalid song path received in CMD_PLAY_FROM_INTENT");
                        }
                        break;
                    default:
                        Log.w(TAG, "Unknown command received: " + cmd);
                        break;
                }
            } else {
                Log.e(TAG, "Null command received in onStartCommand");
            }
        } else {
            Log.e(TAG, "Null intent received in onStartCommand");
        }

        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
        if (nextPlayer != null) {
            nextPlayer.release();
            nextPlayer = null;
        }
        if (wakelock != null && wakelock.isHeld()) {
            wakelock.release();
        }
        progressHandler.removeCallbacksAndMessages(null);
        instance = null;
    }

    public boolean isPlaying() {
        return mPlayer != null && mPlayer.isPlaying();
    }

    public int getQueueSize() {
        return songQueue.size();
    }

    public void requestPlaystateUpdate() {
        if (mPlayer != null) {
            if (songset && currentSong != null) {
                APEvents.getInstance().postSongChangeEvent(currentSong);
            }
            if (mPlayer.isPlaying()) {
                APEvents.getInstance().postPlayStateEvent_start();
            }
        }
    }

    public static void connect(Context ctx, ConnectionListener listener) {
        App.get().setConnl(listener);
        Intent si = new Intent(ctx, AudioService.class);
        si.setAction(Constants.CMD_START);
        ctx.startService(si);
    }

    public void onActivityDestroyed() {
        if (!isPlaying()) {
            cmd_end();
        }
    }

    public void getSongsList() {
        SongLibrary.getInstance().getAllSongs(this, getsonglistresult);
    }

    public void resetShuffle() {
        playSong(songQueue.get(currentSongIndex));
    }

    public void shuffleAll() {
        if (songlist == null || songlist.isEmpty()) {
            return;
        }
        songQueue.clear();
        queueManager.setQueue(songlist);
        songQueue.addAll(songlist);
        Collections.shuffle(songQueue);
        currentSongIndex = 0;
        playSong(songQueue.get(currentSongIndex));
    }

    public void shuffleQueue() {
        if (songQueue == null || songQueue.isEmpty()) {
            return;
        }
        Collections.shuffle(songQueue);
        currentSongIndex = 0;
        playSong(songQueue.get(currentSongIndex));
    }

    public void playAll() {
        if (songlist == null || songlist.isEmpty()) {
            return;
        }
        songQueue.clear();
        queueManager.setQueue(songlist);
        songQueue.addAll(songlist);
        currentSongIndex = 0;
        playSong(songQueue.get(currentSongIndex));
    }

    public SongItem getCurrentSong() {
        if (currentSongIndex >= 0 && currentSongIndex < songQueue.size()) {
            return songQueue.get(currentSongIndex);
        }
        return currentSong;
    }

    public int getCurrentPosition() {
        return mPlayer != null ? mPlayer.getCurrentPosition() : 0;
    }

    public int getDuration() {
        return mPlayer != null ? mPlayer.getDuration() : 0;
    }

    public void seekTo(int pos) {
        if (mPlayer != null) {
            mPlayer.seekTo(pos);
        }
    }

    private SongLibrary.ResultCallback getsonglistresult = new SongLibrary.ResultCallback() {
        public void onResult(final Object result) {
            handle.post(new Runnable() {
					public void run() {
						List<SongItem> sl = (List<SongItem>) result;
						_ongetsongslist(sl);
					}
				});
        }
    };

    private void _ongetsongslist(List<SongItem> sl) {
        boolean currentSongUpdated = false;
        boolean listChanged = false;

        if (songlist != null) {
            if (sl.containsAll(songlist) && songlist.containsAll(sl)) {
            } else {
                songlist = sl;
                listChanged = true;
            }
        } else {
            songlist = sl;
        }

        if (currentSong != null) {
            for (SongItem si : songlist) {
                if (si.path.equalsIgnoreCase(currentSong.path)) {
                    currentSong = si;
                    currentSongUpdated = true;
                    break;
                }
            }
        } else {
            String p = prefs.getLastPath();
            if (Utils.exists(p)) {
                for (SongItem si : songlist) {
                    if (si.path.equalsIgnoreCase(p)) {
                        currentSong = si;
                        break;
                    }
                }
                if (currentSong == null && !songlist.isEmpty()) {
                    currentSong = songlist.get(0);
                }
            } else {
                if (!songlist.isEmpty()) {
                    currentSong = songlist.get(0);
                }
            }
        }

        if (!songset) {
            if (currentSong != null) {
                setSong(currentSong);
            }
        }

        if (songlist != null) {
            APEvents.getInstance().postSongsListUpdated(songlist);
        }
        if (currentSong != null) {
            APEvents.getInstance().postSongChangeEvent(currentSong);
        }
    }

    private void cmd_start() {
        ConnectionListener l = App.get().getConnl();
        if (l != null) {
            l.onAudioServiceConnect(this);
        }
    }

    private void cmd_end() {
        stop();
        stopForeground(false);
        stopForeground(true);

        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
        if (nextPlayer != null) {
            nextPlayer.release();
            nextPlayer = null;
        }

        unregisterRecievers();
        stopSelf();
        XApp.exit();
    }

    private void requestAudioFocus() {
        int af = am.requestAudioFocus(audioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        if (af != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            toast("Failed to get audio focus!");
        }
    }

    private void dropAudioFocus() {
        am.abandonAudioFocus(audioFocusListener);
    }

    boolean playingBeforePause = false;
    AudioManager.OnAudioFocusChangeListener audioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
        public void onAudioFocusChange(int state) {
            switch (state) {
                case AudioManager.AUDIOFOCUS_GAIN:
                case AudioManager.AUDIOFOCUS_GAIN_TRANSIENT:
                    break;
                case AudioManager.AUDIOFOCUS_LOSS:
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    playingBeforePause = isPlaying();
                    pause();
                    unregisterRecievers();
                    dropAudioFocus();
                    break;
            }
        }
    };

    private void registerRecievers() {
        if (recieversRegistered) {
            return;
        }
        aquireWakeLock();
        requestAudioFocus();
        registerMediaButton();
        recieversRegistered = true;
    }

    private void unregisterRecievers() {
        unRegisterMediaButton();
        dropAudioFocus();
        releaseWakeLock();
        recieversRegistered = false;
    }

    private void registerMediaButton() {
        try {
            if (mediaButtonComponent == null) {
                mediaButtonComponent = new ComponentName(this, ButtonReciever.class.getName());
            }
            am.registerMediaButtonEventReceiver(mediaButtonComponent);
        } catch (Exception e) {
        }
    }

    private void unRegisterMediaButton() {
        try {
            am.unregisterMediaButtonEventReceiver(mediaButtonComponent);
        } catch (Exception e) {
        }
    }

    Runnable btnSingle = new Runnable() {
        public void run() {
            playPause();
            btnSinglepress = false;
        }
    };

    boolean btnSinglepress = false;

    private void handleMediabtn() {
        if (btnSinglepress) {
            handle.removeCallbacks(btnSingle);
            btnSinglepress = false;
            playNext();
        } else {
            btnSinglepress = true;
            handle.postDelayed(btnSingle, 280);
        }
    }

    private void aquireWakeLock() {
        try {
            if (wakelock != null) {
                wakelock.acquire();
            }
        } catch (Exception e) {
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakelock != null && wakelock.isHeld()) {
                wakelock.release();
            }
        } catch (Exception e) {
        }
    }

    public void updateNotif() {
    }

    private void showNotification() {
        startForeground(NID, Notific.get(this, currentSong, true));
    }

    private void stopNotification() {
        startForeground(NID, Notific.get(this, currentSong, false));
    }

    private void toast(String msg) {
        Utils.toast(ctx, msg);
    }

    public interface ConnectionListener {
        public void onAudioServiceConnect(AudioService service);
    }
}/*
	package com.alexa.alexa.service;

	 import android.app.Activity;
	 import android.app.Notification;
	 import android.app.NotificationChannel;
	 import android.app.NotificationManager;
	 import android.app.PendingIntent;
	 import android.app.Service;
	 import android.content.ComponentName;
	 import android.content.ContentResolver;
	 import android.content.Context;
	 import android.content.Intent;
	 import android.content.SharedPreferences;
	 import android.content.res.AssetFileDescriptor;
	 import android.media.AudioAttributes;
	 import android.media.AudioManager;
	 import android.media.MediaPlayer;
	 import android.net.Uri;
	 import android.os.Binder;
	 import android.os.Build;
	 import android.os.Handler;
	 import android.os.IBinder;
	 import android.os.PowerManager;
	 import android.telephony.PhoneStateListener;
	 import android.telephony.TelephonyManager;
	 import android.util.Log;
	 import android.widget.Toast;
	 import androidx.core.app.NotificationCompat;
	 import com.alexa.alexa.APEvents;
	 import com.alexa.alexa.App;
	 import com.alexa.alexa.Constants;
	 import com.alexa.alexa.XApp;
	 import com.alexa.alexa.activity.MainActivity;
	 import com.alexa.alexa.library.SongLibrary;
	 import com.alexa.alexa.manager.QueueManager;
	 import com.alexa.alexa.models.Playlist;
	 import com.alexa.alexa.models.SongItem;
	 import com.alexa.alexa.recievers.ButtonReciever;
	 import com.alexa.alexa.utils.EqualizerUtils;
	 import com.alexa.alexa.utils.Notific;
	 import com.alexa.alexa.utils.SPrefs;
	 import com.alexa.alexa.utils.Utils;
	 import com.google.gson.Gson;
	 import com.google.gson.reflect.TypeToken;
	 import java.io.IOException;
	 import java.lang.reflect.Type;
	 import java.util.ArrayList;
	 import java.util.Collections;
	 import java.util.List;
	 import java.util.Random;
	 import androidx.localbroadcastmanager.content.LocalBroadcastManager;
	 import com.alexa.alexa.manager.CrossfadeManager;
	 import com.alexa.alexa.models.CrossfadeConfig;

	 public class AudioService extends Service implements MediaPlayer.OnCompletionListener,
	 MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener
	 {




	 private List<SongItem> songQueue;
	 public static final String PREF_NAME = "AudioPreferences";
	 private SharedPreferences sharedPreferences;
	 private Gson gson;
	 private static String TAG = "AudioService";
	 private ComponentName mediaButtonComponent;
	 private final int NID = 5374;
	 private int currentSongIndex;
	 private Context ctx;
	 private MediaPlayer mPlayer;
	 private MediaPlayer nextPlayer;
	 private AudioManager am;
	 private PowerManager.WakeLock wakelock;
	 private SPrefs prefs;
	 private final IBinder binder = new LocalBinder();
	 private SongItem currentSong;
	 private Handler handle = new Handler();
	 private String currentSongPath;
	 private boolean restartCurrentOnPrev = false;
	 private boolean songset = false;
	 private boolean recieversRegistered = false;
	 private List<SongItem> songlist = new ArrayList<>();
	 private static AudioService instance;
	 private boolean isShuffleEnabled = false;
	 private RepeatMode repeatMode = RepeatMode.NONE;
	 private Activity act;
	 private QueueManager queueManager;
	 private static final String KEY_CROSSFADE_DURATION = "crossfade_duration";
	 private static final int DEFAULT_CROSSFADE_DURATION = 20000;
	 private int crossfadeDuration;
	 private boolean isCrossfading = false;
	 private Handler crossfadeHandler = new Handler();
	 private Runnable crossfadeRunnable;
	 private Handler progressHandler = new Handler();
	 private Runnable progressCheck;
	 private boolean crossfadeTriggered = false;
	 public static String ACTION_SONG_CHANGED = "com.alexa.alexa.ACTION_SONG_CHANGED";
	 public static String ACTION_CROSSFADE_STARTED = "com.alexa.alexa.ACTION_CROSSFADE_STARTED";
	 public static String ACTION_CROSSFADE_COMPLETED = "com.alexa.alexa.ACTION_CROSSFADE_COMPLETED";
	 private static final String QUEUE_KEY = "songs_queue";
	 private static final String CHANNEL_ID = "ALEXA_Audio_CHANNEL";
	 private int repeatPointA = -1;
	 private int repeatPointB = -1;
	 private boolean isABRepeatEnabled = false;
	 // Add these fields to AudioService
	 private CrossfadeManager crossfadeManager;
	 private boolean crossfadePending = false;

	 // In onCreate()

	 private Handler handler;
	 private Runnable progressChecker;
	 private List<SongItem> queue;
	 private int currentIndex = 0;

	 /*@Override
	 public void onCreate() {
	 super.onCreate();
	 handler = new Handler();
	 initMediaPlayer();
	 startProgressChecker();
	 }*

	private void initMediaPlayer() {
		mPlayer = new MediaPlayer();
		mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		mPlayer.setOnPreparedListener(this);
		mPlayer.setOnCompletionListener(this);
		mPlayer.setOnErrorListener(this);
	}

	public void playQueue(List<SongItem> queue, int startIndex) {
		this.queue = queue;
		this.currentIndex = startIndex;
		prepareAndPlay(queue.get(startIndex));
	}

	private void prepareAndPlay(SongItem song) {
		try {
			mPlayer.reset();
			mPlayer.setDataSource(song.path);
			mPlayer.prepare();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void onPrepared(MediaPlayer mp) {
		mp.start();
	}

	public void onCompletion(MediaPlayer mp) {
		if (!isCrossfading) {
			startCrossfadeToNext();
		}
	}

	public boolean onError(MediaPlayer mp, int what, int extra) {
		return false;
	}

	private void startProgressChecker() {
		progressChecker = new Runnable() {
			public void run() {
				if (mPlayer != null && mPlayer.isPlaying()) {
					int currentPos = mPlayer.getCurrentPosition();
					int duration = mPlayer.getDuration();
					if (!isCrossfading && currentPos >= duration - 30000 && nextPlayer == null) {
						prepareNextPlayer();
					}
					if (!isCrossfading && currentPos >= duration - crossfadeDuration && !crossfadeTriggered) {
						crossfadeTriggered = true;
						startCrossfadeToNext();
					}
					handler.postDelayed(this, 1000);
				}
			}
		};
		handler.post(progressChecker);
	}

	private void prepareNextPlayer() {
		int nextIndex = currentIndex + 1;
		if (nextIndex >= queue.size()) {
			return;
		}

		SongItem nextSong = queue.get(nextIndex);
		nextPlayer = new MediaPlayer();
		nextPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		try {
			nextPlayer.setDataSource(nextSong.path);
			nextPlayer.prepareAsync();
			nextPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
					public void onPrepared(MediaPlayer mp) {
						Log.d("AudioService", "Next player prepared");
					}
				});
			nextPlayer.setOnErrorListener(this);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void startCrossfadeToNext() {
		int nextIndex = currentIndex + 1;
		if (nextIndex >= queue.size()) {
			return;
		}
		final SongItem nextSong = queue.get(nextIndex);

		if (nextPlayer == null) {
			prepareNextPlayer();
		}

		if (nextPlayer != null) {
			try {
				nextPlayer.start();
				nextPlayer.setVolume(0f, 0f);
				isCrossfading = true;
				notifyCrossfadeStarted();
				runCrossfadeSteps(nextSong, nextIndex);
			} catch (IllegalStateException e) {
				e.printStackTrace();
			}
		}
	}

	private void runCrossfadeSteps(final SongItem nextSong, final int nextIndex) {
		final int steps = 50;
		final long interval = crossfadeDuration / steps;
		final float volumeStep = 1.0f / steps;

		handler.postDelayed(new Runnable() {
				int currentStep = 0;

				public void run() {
					if (mPlayer == null || nextPlayer == null) {
						completeCrossfade(nextSong, nextIndex);
						return;
					}

					float outgoingVolume = 1.0f - (volumeStep * currentStep);
					float incomingVolume = volumeStep * currentStep;
					if (outgoingVolume < 0f) outgoingVolume = 0f;
					if (incomingVolume > 1f) incomingVolume = 1f;

					mPlayer.setVolume(outgoingVolume, outgoingVolume);
					nextPlayer.setVolume(incomingVolume, incomingVolume);

					currentStep++;
					if (currentStep <= steps) {
						handler.postDelayed(this, interval);
					} else {
						completeCrossfade(nextSong, nextIndex);
					}
				}
			}, interval);
	}

	private void completeCrossfade(SongItem nextSong, int nextIndex) {
		isCrossfading = false;
		crossfadeTriggered = false;

		if (mPlayer != null) {
			mPlayer.stop();
			mPlayer.release();
		}

		mPlayer = nextPlayer;
		nextPlayer = null;
		currentIndex = nextIndex;

		mPlayer.setOnCompletionListener(this);
		mPlayer.setOnPreparedListener(this);
		mPlayer.setOnErrorListener(this);

		notifyCrossfadeCompleted();
	}

	private void notifyCrossfadeStarted() {
		Intent intent = new Intent(Constants.ACTION_CROSSFADE_STARTED);
		LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
	}

	private void notifyCrossfadeCompleted() {
		Intent intent = new Intent(Constants.ACTION_CROSSFADE_COMPLETED);
		LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
	}

	public void playPausee() {
		if (mPlayer != null) {
			if (mPlayer.isPlaying()) {
				mPlayer.pause();
			} else {
				mPlayer.start();
			}
		}
	}
	public void playPause() {
        if (currentSong != null) {
            if (isPlaying()) {
                pause();
            } else {
                if (songset) {
                    resume();
                } else {
                    playSong(currentSong);
                }
            }
        } else {
            if (!songQueue.isEmpty()) {
                currentSong = songQueue.get(0);
                if (currentSong != null) {
                    playSong(currentSong);
                }
            }
        }
    }
	public void playNext() {
		if (!isCrossfading) {
			startCrossfadeToNext();
		}
	}

	public void playPrev() {
		if (currentIndex > 0) {
			currentIndex--;
			if (mPlayer != null) {
				mPlayer.stop();
				mPlayer.reset();
			}
			prepareAndPlay(queue.get(currentIndex));
		} else {
			if (mPlayer != null) {
				mPlayer.seekTo(0);
			}
		}
	}

	public int getCurrentPosition() {
		if (mPlayer != null) {
			return mPlayer.getCurrentPosition();
		}
		return 0;
	}

	public int getDuration() {
		if (mPlayer != null) {
			return mPlayer.getDuration();
		}
		return 0;
	}

	public void seekTo(int position) {
		if (mPlayer != null) {
			mPlayer.seekTo(position);
		}
	}

	public boolean isPlaying() {
		return mPlayer != null && mPlayer.isPlaying();
	}

	@Override
	public IBinder onBind(Intent intent) {
		return binder;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mPlayer != null) {
			mPlayer.release();
		}
		if (nextPlayer != null) {
			nextPlayer.release();
		}
		handler.removeCallbacksAndMessages(null);
	}



// Update the progress check
	private void startProgressCheck() {
		progressCheck = new Runnable() {
			@Override
			public void run() {
				if (mPlayer != null && mPlayer.isPlaying() && !crossfadeManager.isCrossfading()) {
					int currentPos = mPlayer.getCurrentPosition();
					int duration = mPlayer.getDuration();

					// Check for AB repeat
					if (isABRepeatEnabled && repeatPointB != -1 && currentPos >= repeatPointB) {
						mPlayer.seekTo(repeatPointA);
					}
					// Check for crossfade
					else if (crossfadeDuration > 0 && duration > 0 && 
							 currentPos >= duration - DEFAULT_CROSSFADE_DURATION && 
							 !crossfadePending) {
						crossfadePending = true;
						startCrossfadeToNext();
					}

					progressHandler.postDelayed(this, 100);
				} else {
					progressHandler.postDelayed(this, 100);
				}
			}
		};
		progressHandler.post(progressCheck);
	}

	/*private void startCrossfadeToNext() {
	 if (songQueue.isEmpty() || crossfadeDuration <= 0 || crossfadeManager.isCrossfading()) {
	 playNext();
	 return;
	 }

	 final int nextIndex = getNextSongIndex();
	 if (nextIndex == -1) {
	 stopPlayback();
	 return;
	 }

	 final SongItem nextSong = songQueue.get(nextIndex);
	 if (nextSong == null) {
	 stopPlayback();
	 return;
	 }

	 crossfadeManager.startCrossfade(mPlayer, nextSong);
	 }

	 // Update playNext() to handle crossfade
	 public void playNext() {
	 if (crossfadeManager.isCrossfading()) {
	 crossfadeManager.cleanup();
	 }

	 if (songQueue.isEmpty()) return;

	 int nextIndex = getNextSongIndex();
	 if (nextIndex == -1) {
	 stopPlayback();
	 return;
	 }

	 mPlayer.stop();
	 mPlayer.reset();
	 currentSong = songQueue.get(nextIndex);
	 currentSongIndex = nextIndex;
	 playSong(currentSong);
	 }

	 // Update playPause() to handle crossfade
	 public void playPause() {
	 if (crossfadeManager.isCrossfading()) {
	 crossfadeManager.cleanup();
	 }

	 if (currentSong != null) {
	 if (isPlaying()) {
	 pause();
	 } else {
	 if (songset) {
	 resume();
	 } else {
	 playSong(currentSong);
	 }
	 }
	 } else if (!songlist.isEmpty()) {
	 currentSong = songlist.get(0);
	 playSong(currentSong);
	 }
	 }*
    public SongItem getNextSong() {
        if (queueManager == null || queueManager.getQueue() == null || queueManager.getQueue().isEmpty()) {
            return null;
        }

        int currentIndex = queueManager.getCurrentIndex();
        if (currentIndex < 0 || currentIndex >= queueManager.getQueue().size() - 1) {
            if (repeatMode == RepeatMode.REPEAT_ALL) {
                return queueManager.getQueue().get(0);
            }
            return null;
        }

        return queueManager.getQueue().get(currentIndex + 1);
    }

    public MediaPlayer getMediaPlayer() {
        return mPlayer;
    }

    public RepeatMode getRepeatMode() {
        return repeatMode;
    }
	public void setRepeatMode(RepeatMode mode) {
        this.repeatMode = mode;
    }
    public enum RepeatMode {
        NONE,
        REPEAT_ONE,
        REPEAT_ALL
		}

    public void setMediaPlayer(MediaPlayer player) {
        if (mPlayer != null) {
            mPlayer.release();
        }
        mPlayer = player;

        if (mPlayer != null) {
            mPlayer.setOnCompletionListener(this);
            mPlayer.setOnPreparedListener(this);
            mPlayer.setOnErrorListener(this);
        }
    }
	public void updateCurrentSong(SongItem song, int index) {
        currentSong = song;
        currentSongIndex = index;
        songset = true;
        prefs.saveLastPath(song.path);
        showNotification();
        APEvents.getInstance().postPlayStateEvent_start();
        APEvents.getInstance().postSongChangeEvent(currentSong);
    }
    @Override
    public void onCreate() {
        super.onCreate();
		handler = new Handler();
        instance = this;
        ctx = getApplicationContext();
        prefs = new SPrefs(this);
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        gson = new Gson();
        queueManager = QueueManager.getInstance();
        restartCurrentOnPrev = prefs.getRestartSongOnPrev();
		initMPlayer();
		//initMediaPlayer();
        songQueue = loadQueueFromPreferences();
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakelock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, TAG);
        createNotificationChannel();
        setupPhoneCallListener();
		crossfadeManager = new CrossfadeManager(this, new CrossfadeConfig(this));
        crossfadeDuration = sharedPreferences.getInt(KEY_CROSSFADE_DURATION, DEFAULT_CROSSFADE_DURATION);

        App.get().registerAudiosService(this);

        //startProgressCheck();
		startProgressChecker();
    }

    private void initMPlayer() {
        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setOnCompletionListener(this);
        mPlayer.setOnPreparedListener(this);
        mPlayer.setOnErrorListener(this);
    }

	/* private void startProgressCheck() {
	 progressCheck = new Runnable() {
	 public void run() {
	 if (mPlayer != null && mPlayer.isPlaying() && !isCrossfading) {
	 int currentPos = mPlayer.getCurrentPosition();
	 int duration = mPlayer.getDuration();
	 if (isABRepeatEnabled && repeatPointB != -1 && currentPos >= repeatPointB) {
	 mPlayer.seekTo(repeatPointA);
	 progressHandler.postDelayed(this, 100);
	 } else if (!isABRepeatEnabled && crossfadeDuration > 0 && duration > 0 && 
	 currentPos >= duration - crossfadeDuration && !crossfadeTriggered) {
	 crossfadeTriggered = true;
	 startCrossfadeToNext();
	 } else {
	 crossfadeTriggered = false;
	 progressHandler.postDelayed(this, 100);
	 }
	 } else {
	 progressHandler.postDelayed(this, 100);
	 }
	 }
	 };
	 progressHandler.post(progressCheck);
	 }
	 *
	 @Override
	 public void onCompletion(MediaPlayer mp) {
	 if (repeatMode == RepeatMode.REPEAT_ONE) {
	 playSong(songQueue.get(currentSongIndex));
	 } else if (!isCrossfading) {
	 startCrossfadeToNext();
	 }
	 }
	 *
    public void toggleRepeat() {
        switch (repeatMode) {
            case NONE:
                repeatMode = RepeatMode.REPEAT_ALL;
                break;
            case REPEAT_ALL:
                repeatMode = RepeatMode.REPEAT_ONE;
                break;
            default:
                repeatMode = RepeatMode.NONE;
                break;
        }
    }

    public void toggleShuffle() {
        isShuffleEnabled = !isShuffleEnabled;
        if (isShuffleEnabled) {
            Collections.shuffle(songQueue);
        }
    }

	/* @Override
	 public void onPrepared(MediaPlayer mp) {
	 mp.start();
	 showNotification();
	 notifySongChanged();
	 progressHandler.post(progressCheck);
	 }

	 @Override
	 public boolean onError(MediaPlayer mp, int what, int extra) {
	 return false;
	 }

	 @Override
	 public IBinder onBind(Intent intent) {
	 return binder;
	 }*

    public class LocalBinder extends Binder {
        public AudioService getService() {
            return AudioService.this;
        }
    }

    /*private void startCrossfadeToNext() {
	 if (songQueue.isEmpty() || crossfadeDuration <= 0 || isCrossfading) {
	 playNext();
	 return;
	 }

	 final int nextIndex = getNextSongIndex();
	 if (nextIndex == -1) {
	 stopPlayback();
	 return;
	 }

	 final SongItem nextSong = songQueue.get(nextIndex);
	 if (nextSong == null) {
	 stopPlayback();
	 return;
	 }

	 try {
	 nextPlayer = new MediaPlayer();
	 nextPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
	 nextPlayer.setDataSource(nextSong.path);
	 nextPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
	 public void onPrepared(MediaPlayer mp) {
	 nextPlayer.start();
	 nextPlayer.setVolume(0.0f, 0.0f);
	 isCrossfading = true;
	 notifyCrossfadeStarted();
	 performCrossfade(nextSong, nextIndex);
	 }
	 });
	 nextPlayer.setOnErrorListener(this);
	 nextPlayer.prepareAsync();
	 } catch (IOException e) {
	 e.printStackTrace();
	 playNext();
	 }
	 }*

    private void performCrossfade(final SongItem nextSong, final int nextIndex) {
        final int steps = 50;
        final long interval = crossfadeDuration / steps;
        final float volumeStep = 1.0f / steps;

        crossfadeHandler.removeCallbacksAndMessages(null);
        crossfadeRunnable = new Runnable() {
            private int currentStep = 0;

            public void run() {
                if (!isCrossfading || mPlayer == null || nextPlayer == null) {
                    completeCrossfade(nextSong, nextIndex);
                    return;
                }

                float outgoingVolume = 1.0f - (volumeStep * currentStep);
                float incomingVolume = volumeStep * currentStep;

                if (outgoingVolume < 0.0f) outgoingVolume = 0.0f;
                if (incomingVolume > 1.0f) incomingVolume = 1.0f;

                mPlayer.setVolume(outgoingVolume, outgoingVolume);
                nextPlayer.setVolume(incomingVolume, incomingVolume);

                currentStep++;
                if (currentStep <= steps) {
                    crossfadeHandler.postDelayed(this, interval);
                } else {
                    completeCrossfade(nextSong, nextIndex);
                }
            }
        };
        crossfadeHandler.post(crossfadeRunnable);
    }

	/*  private void completeCrossfade(SongItem nextSong, int nextIndex) {
	 isCrossfading = false;
	 crossfadeHandler.removeCallbacksAndMessages(null);

	 if (mPlayer != null) {
	 mPlayer.stop();
	 mPlayer.release();
	 }

	 mPlayer = nextPlayer;
	 nextPlayer = null;
	 mPlayer.setOnCompletionListener(this);
	 mPlayer.setOnPreparedListener(this);
	 mPlayer.setOnErrorListener(this);

	 currentSong = nextSong;
	 currentSongIndex = nextIndex;
	 songset = true;
	 prefs.saveLastPath(currentSong.path);
	 showNotification();
	 notifySongChanged();
	 notifyCrossfadeCompleted();
	 APEvents.getInstance().postPlayStateEvent_start();
	 APEvents.getInstance().postSongChangeEvent(currentSong);
	 }

	 private void notifyCrossfadeStarted() {
	 Intent intent = new Intent(ACTION_CROSSFADE_STARTED);
	 LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
	 }

	 private void notifyCrossfadeCompleted() {
	 Intent intent = new Intent(ACTION_CROSSFADE_COMPLETED);
	 LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
	 }
	 *
    private int getNextSongIndex() {
        if (isShuffleEnabled) {
            return new Random().nextInt(songQueue.size());
        } else {
            if (currentSongIndex < songQueue.size() - 1) {
                return currentSongIndex + 1;
            } else if (repeatMode == RepeatMode.REPEAT_ALL) {
                return 0;
            } else {
                return -1;
            }
        }
    }

    public void setCrossfadeDuration(int durationMs) {
        if (durationMs >= 0) {
            crossfadeDuration = durationMs;
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt(KEY_CROSSFADE_DURATION, durationMs);
            editor.apply();
        }
    }

    public int getCrossfadeDuration() {
        return crossfadeDuration;
    }

	/* public void playQueue(List<SongItem> queue, int startIndex) {
	 if (queue == null || queue.isEmpty()) {
	 return;
	 }

	 this.songQueue.clear();
	 this.songQueue.addAll(queue);

	 if (startIndex < 0 || startIndex >= songQueue.size()) {
	 startIndex = 0;
	 }

	 this.currentSongIndex = startIndex;
	 this.currentSong = songQueue.get(currentSongIndex);

	 stop();
	 prepareAndPlay(currentSong);
	 notifyQueueChanged();
	 notifySongChanged();
	 }

	 private void prepareAndPlay(SongItem song) {
	 if (song == null) {
	 return;
	 }

	 try {
	 if (mPlayer != null) {
	 mPlayer.reset();
	 } else {
	 mPlayer = new MediaPlayer();
	 mPlayer.setOnCompletionListener(this);
	 }

	 mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
	 mPlayer.setDataSource(song.path);
	 mPlayer.prepare();
	 mPlayer.start();

	 songset = true;
	 currentSong = song;

	 showNotification();
	 notifySongChanged();
	 progressHandler.post(progressCheck);
	 } catch (IOException e) {
	 e.printStackTrace();
	 }
	 }
	 *
    private void notifyQueueChanged() {
        Intent intent = new Intent("com.alexa.alexa.ACTION_QUEUE_CHANGED");
        intent.putParcelableArrayListExtra("queue", new ArrayList<>(songQueue));
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void notifySongChanged() {
        Intent intent = new Intent(ACTION_SONG_CHANGED);
        intent.putExtra("song", currentSong);
        intent.putExtra("position", currentSongIndex);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    public void clearABRepeat() {
        repeatPointA = -1;
        repeatPointB = -1;
        isABRepeatEnabled = false;
    }

    public void setRepeatPointA() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            repeatPointA = mPlayer.getCurrentPosition();
            isABRepeatEnabled = false;
        }
    }

    public void setRepeatPointB() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            repeatPointB = mPlayer.getCurrentPosition();
            if (repeatPointA != -1 && repeatPointB > repeatPointA) {
                isABRepeatEnabled = true;
            }
        }
    }

    private void setupPhoneCallListener() {
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        telephonyManager.listen(new PhoneStateListener() {
				public void onCallStateChanged(int state, String incomingNumber) {
					if (state == TelephonyManager.CALL_STATE_RINGING || state == TelephonyManager.CALL_STATE_OFFHOOK) {
						pause();
					}
				}
			}, PhoneStateListener.LISTEN_CALL_STATE);
    }

    public void addToQueue(Object item) {
        boolean shouldStartPlayback = songQueue.isEmpty() && !isPlaying();

        if (item instanceof SongItem) {
            SongItem song = (SongItem) item;
            if (!songQueue.contains(song)) {
                songQueue.add(song);
                saveQueueToPreferences();
                if (shouldStartPlayback) {
                    currentSongIndex = 0;
                    playSong(songQueue.get(currentSongIndex));
                }
            }
        } else if (item instanceof List<?>) {
            List<SongItem> songs = (List<SongItem>) item;
            boolean newSongsAdded = false;
            for (SongItem song : songs) {
                if (!songQueue.contains(song)) {
                    songQueue.add(song);
                    newSongsAdded = true;
                }
            }
            saveQueueToPreferences();
            if (shouldStartPlayback && newSongsAdded) {
                currentSongIndex = 0;
                playSong(songQueue.get(currentSongIndex));
            }
        } else if (item instanceof Playlist) {
            Playlist playlist = (Playlist) item;
            List<SongItem> playlistSongs = playlist.getSongs();
            boolean newSongsAdded = false;
            for (SongItem song : playlistSongs) {
                if (!songQueue.contains(song)) {
                    songQueue.add(song);
                    newSongsAdded = true;
                }
            }
            saveQueueToPreferences();
            if (shouldStartPlayback && newSongsAdded) {
                currentSongIndex = 0;
                playSong(songQueue.get(currentSongIndex));
            }
        } else {
            throw new IllegalArgumentException("Unsupported parameter type for addToQueue");
        }
    }

    private void saveQueueToPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String json = gson.toJson(songQueue);
        editor.putString(QUEUE_KEY, json);
        editor.apply();
    }

    public void addToPlaylist(Object item, Playlist targetPlaylist) {
        if (targetPlaylist == null) {
            throw new IllegalArgumentException("Target playlist cannot be null");
        }

        boolean updated = false;

        if (item instanceof SongItem) {
            SongItem song = (SongItem) item;
            if (!targetPlaylist.getSongs().contains(song)) {
                targetPlaylist.getSongs().add(song);
                updated = true;
            }
        } else if (item instanceof List<?>) {
            List<SongItem> songs = (List<SongItem>) item;
            for (SongItem song : songs) {
                if (!targetPlaylist.getSongs().contains(song)) {
                    targetPlaylist.getSongs().add(song);
                    updated = true;
                }
            }
        } else if (item instanceof Playlist) {
            Playlist sourcePlaylist = (Playlist) item;
            for (SongItem song : sourcePlaylist.getSongs()) {
                if (!targetPlaylist.getSongs().contains(song)) {
                    targetPlaylist.getSongs().add(song);
                    updated = true;
                }
            }
        } else {
            throw new IllegalArgumentException("Unsupported parameter type for addToPlaylist");
        }

        if (updated) {
            App.get().getMainActivity().refreshPlaylistsTab();
            Toast.makeText(ctx, "Songs added to playlist '" + targetPlaylist.getName() + "'", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(ctx, "No new songs added. Playlist already contains these songs.", Toast.LENGTH_SHORT).show();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
				CHANNEL_ID,
				"Alexa Audio Service Channel",
				NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    public void playFromIntent(final Context context, String intentAction) {
        initMPlayer();

        Intent intent = ((Activity) context).getIntent();
        if (intent == null || intent.getData() == null) {
            Toast.makeText(context, "No file to play", Toast.LENGTH_SHORT).show();
            return;
        }

        final Uri songUri = intent.getData();
        final AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        final AudioManager.OnAudioFocusChangeListener focusChangeListener = new AudioManager.OnAudioFocusChangeListener() {
            public void onAudioFocusChange(int focusChange) {
                if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                    pause();
                }
            }
        };

        int result = audioManager.requestAudioFocus(focusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        if (result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            Toast.makeText(context, "Unable to gain audio focus", Toast.LENGTH_SHORT).show();
            return;
        }

        if (mPlayer.isPlaying()) {
            mPlayer.stop();
        }

        mPlayer.reset();

        ContentResolver contentResolver = context.getContentResolver();
        AssetFileDescriptor assetFileDescriptor = null;

        try {
            assetFileDescriptor = contentResolver.openAssetFileDescriptor(songUri, "r");
            if (assetFileDescriptor != null) {
                mPlayer.setDataSource(assetFileDescriptor.getFileDescriptor());
                mPlayer.prepare();
                mPlayer.start();
                showNotification();

                currentSong = new SongItem();
                currentSong.path = songUri.toString();

                APEvents.getInstance().postSongChangeEvent(currentSong);
            } else {
                Toast.makeText(context, "Unable to access the file", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Unable to play the selected file", Toast.LENGTH_SHORT).show();
        } finally {
            if (assetFileDescriptor != null) {
                try {
                    assetFileDescriptor.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void clearQueue() {
        songQueue.clear();
        saveQueueToPreferences();
    }

    public void onQueueRearranged(List<SongItem> newQueue) {
        songQueue.clear();
        songQueue.addAll(newQueue);
        int idx = songQueue.indexOf(currentSong);
        if (idx != -1) {
            if (idx != currentSongIndex) {
                currentSongIndex = idx;
                mPlayer.stop();
                mPlayer.reset();
                playSong(currentSong);
            }
        } else {
            mPlayer.stop();
            mPlayer.reset();
        }
    }

    private ArrayList<SongItem> loadQueueFromPreferences() {
        String json = sharedPreferences.getString(QUEUE_KEY, null);
        if (json != null) {
            Type type = new TypeToken<ArrayList<SongItem>>() {}.getType();
            return gson.fromJson(json, type);
        }
        return new ArrayList<>();
    }

    public void playSong(SongItem si) {
        if (si == null || mPlayer == null) {
            return;
        }

        if (mPlayer.isPlaying() && crossfadeDuration > 0) {
            startCrossfadeToSong(si);
        } else {
            mPlayer.stop();
            mPlayer.reset();
            currentSong = si;
            prefs.saveLastPath(si.path);

            try {
                mPlayer.setDataSource(si.path);
                songset = true;
				showNotification();
                mPlayer.prepare();
                int lastSeekPosition = prefs.getLastSeekPosition(si.path);
                if (lastSeekPosition > 0) {
                    mPlayer.seekTo(lastSeekPosition);
                }
                resume();
                APEvents.getInstance().postSongChangeEvent(currentSong);
                APEvents.getInstance().postPlayStateEvent_start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void startCrossfadeToSong(final SongItem nextSong) {
        try {
            nextPlayer = new MediaPlayer();
            nextPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            nextPlayer.setDataSource(nextSong.path);
            nextPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
					public void onPrepared(MediaPlayer mp) {
						nextPlayer.start();
						nextPlayer.setVolume(0.0f, 0.0f);
						isCrossfading = true;
						notifyCrossfadeStarted();
						performCrossfade(nextSong, songQueue.indexOf(nextSong));
					}
				});
            nextPlayer.setOnErrorListener(this);
            nextPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
            playSong(nextSong);
        }
    }

    public void setSong(SongItem si) {
        currentSong = si;
        try {
            mPlayer.setDataSource(si.path);
            mPlayer.prepare();
            songset = true;
            APEvents.getInstance().postSongChangeEvent(currentSong);
        } catch (IllegalArgumentException e) {
        } catch (IllegalStateException e) {
        } catch (IOException e) {
        } catch (SecurityException e) {
        }
    }
	/*
	 public void playPause() {
	 if (currentSong != null) {
	 if (isPlaying()) {
	 pause();
	 } else {
	 if (songset) {
	 resume();
	 } else {
	 playSong(currentSong);
	 }
	 }
	 } else {
	 if (!songlist.isEmpty()) {
	 currentSong = songlist.get(0);
	 if (currentSong != null) {
	 playSong(currentSong);
	 }
	 }
	 }
	 }
	 *
    public void resume() {
        try {
            mPlayer.start();
            APEvents.getInstance().postPlayStateEvent_start();
            showNotification();
            registerRecievers();
            progressHandler.post(progressCheck);
        } catch (Exception e) {
            toast(e.getMessage());
        }
    }

    public void pause() {
        if (mPlayer.isPlaying()) {
            int position = mPlayer.getCurrentPosition();
            prefs.saveLastSeekPosition(currentSong.path, position);
            mPlayer.pause();
        }
        stopNotification();
        releaseWakeLock();
        APEvents.getInstance().postPlayStateEvent_pause();
    }

    public void stop() {
        if (mPlayer.isPlaying()) {
            int position = mPlayer.getCurrentPosition();
            prefs.saveLastSeekPosition(currentSong.path, position);
            mPlayer.stop();
        }
        mPlayer.reset();
        stopNotification();
        unregisterRecievers();
        APEvents.getInstance().postPlayStateEvent_stop();
    }

    /*public void playNext() {
	 startCrossfadeToNext();
	 }
	 *
	 public void playPrev() {
	 if (songQueue.isEmpty()) {
	 return;
	 }

	 int idx = songQueue.indexOf(currentSong);
	 idx--;
	 if (idx < 0) {
	 idx = 0;
	 }

	 boolean restart = false;
	 if (restartCurrentOnPrev) {
	 int ct = mPlayer.getCurrentPosition();
	 if (ct > 6000) {
	 restart = true;
	 }
	 }

	 if (restart) {
	 mPlayer.seekTo(0);
	 } else {
	 mPlayer.stop();
	 mPlayer.reset();
	 currentSong = songQueue.get(idx);
	 prefs.saveLastSeekPosition(currentSong.path, 0);
	 playSong(currentSong);
	 }
	 }*

    private void stopPlayback() {
        if (mPlayer.isPlaying()) {
            mPlayer.stop();
        }
        currentSongIndex = -1;
        songset = false;
        stopNotification();
    }

    public static AudioService getInstance() {
        return instance;
    }

    public void openEqualizerPanel(Activity activity) {
        if (EqualizerUtils.hasEqualizer(ctx)) {
            EqualizerUtils.openEqualizer(activity, mPlayer);
        } else {
            Toast.makeText(ctx, "No equalizer available on this device.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String cmd = intent.getAction();
            if (cmd != null) {
                switch (cmd) {
                    case Constants.CMD_START:
                        cmd_start();
                        break;
                    case Constants.CMD_END:
                        cmd_end();
                        break;
                    case Constants.CMD_PLAY:
                        resume();
                        break;
                    case Constants.CMD_PAUSE:
                        pause();
                        break;
                    case Constants.CMD_PLAY_NEXT:
                        playNext();
                        break;
                    case Constants.CMD_PLAY_PREV:
                        playPrev();
                        break;
                    case Constants.CMD_MEDIA_BUTTON:
                        handleMediabtn();
                        break;
                    case Constants.CMD_PLAY_FROM_INTENT:
                        cmd_start();
                        String songPath = intent.getStringExtra("song_path");
                        if (songPath != null && !songPath.isEmpty()) {
                            try {
                                playFromIntent(this, songPath);
                            } catch (Exception e) {
                                Log.e(TAG, "Error playing from intent: " + e.getMessage());
                            }
                        } else {
                            Log.e(TAG, "Invalid song path received in CMD_PLAY_FROM_INTENT");
                        }
                        break;
                    default:
                        Log.w(TAG, "Unknown command received: " + cmd);
                        break;
                }
            } else {
                Log.e(TAG, "Null command received in onStartCommand");
            }
        } else {
            Log.e(TAG, "Null intent received in onStartCommand");
        }

        return START_NOT_STICKY;
    }
	/*
	 @Override
	 public void onDestroy() {
	 super.onDestroy();
	 if (mPlayer != null) {
	 mPlayer.release();
	 mPlayer = null;
	 }
	 if (nextPlayer != null) {
	 nextPlayer.release();
	 nextPlayer = null;
	 }
	 if (wakelock != null && wakelock.isHeld()) {
	 wakelock.release();
	 }
	 progressHandler.removeCallbacksAndMessages(null);
	 instance = null;
	 }

	 public boolean isPlaying() {
	 return mPlayer != null && mPlayer.isPlaying();
	 }*

    public int getQueueSize() {
        return songQueue.size();
    }

    public void requestPlaystateUpdate() {
        if (mPlayer != null) {
            if (songset && currentSong != null) {
                APEvents.getInstance().postSongChangeEvent(currentSong);
            }
            if (mPlayer.isPlaying()) {
                APEvents.getInstance().postPlayStateEvent_start();
            }
        }
    }

    public static void connect(Context ctx, ConnectionListener listener) {
        App.get().setConnl(listener);
        Intent si = new Intent(ctx, AudioService.class);
        si.setAction(Constants.CMD_START);
        ctx.startService(si);
    }

    public void onActivityDestroyed() {
        if (!isPlaying()) {
            cmd_end();
        }
    }

    public void getSongsList() {
        SongLibrary.getInstance().getAllSongs(this, getsonglistresult);
    }

    public void resetShuffle() {
        playSong(songQueue.get(currentSongIndex));
    }

    public void shuffleAll() {
        if (songlist == null || songlist.isEmpty()) {
            return;
        }
        songQueue.clear();
        queueManager.setQueue(songlist);
        songQueue.addAll(songlist);
        Collections.shuffle(songQueue);
        currentSongIndex = 0;
        playSong(songQueue.get(currentSongIndex));
    }

    public void shuffleQueue() {
        if (songQueue == null || songQueue.isEmpty()) {
            return;
        }
        Collections.shuffle(songQueue);
        currentSongIndex = 0;
        playSong(songQueue.get(currentSongIndex));
    }

    public void playAll() {
        if (songlist == null || songlist.isEmpty()) {
            return;
        }
        songQueue.clear();
        queueManager.setQueue(songlist);
        songQueue.addAll(songlist);
        currentSongIndex = 0;
        playSong(songQueue.get(currentSongIndex));
    }

    public SongItem getCurrentSong() {
        if (currentSongIndex >= 0 && currentSongIndex < songQueue.size()) {
            return songQueue.get(currentSongIndex);
        }
        return currentSong;
    }

	/* public int getCurrentPosition() {
	 return mPlayer != null ? mPlayer.getCurrentPosition() : 0;
	 }

	 public int getDuration() {
	 return mPlayer != null ? mPlayer.getDuration() : 0;
	 }

	 public void seekTo(int pos) {
	 if (mPlayer != null) {
	 mPlayer.seekTo(pos);
	 }
	 }*

    private SongLibrary.ResultCallback getsonglistresult = new SongLibrary.ResultCallback() {
        public void onResult(final Object result) {
            handle.post(new Runnable() {
					public void run() {
						List<SongItem> sl = (List<SongItem>) result;
						_ongetsongslist(sl);
					}
				});
        }
    };

    private void _ongetsongslist(List<SongItem> sl) {
        boolean currentSongUpdated = false;
        boolean listChanged = false;

        if (songlist != null) {
            if (sl.containsAll(songlist) && songlist.containsAll(sl)) {
            } else {
                songlist = sl;
                listChanged = true;
            }
        } else {
            songlist = sl;
        }

        if (currentSong != null) {
            for (SongItem si : songlist) {
                if (si.path.equalsIgnoreCase(currentSong.path)) {
                    currentSong = si;
                    currentSongUpdated = true;
                    break;
                }
            }
        } else {
            String p = prefs.getLastPath();
            if (Utils.exists(p)) {
                for (SongItem si : songlist) {
                    if (si.path.equalsIgnoreCase(p)) {
                        currentSong = si;
                        break;
                    }
                }
                if (currentSong == null && !songlist.isEmpty()) {
                    currentSong = songlist.get(0);
                }
            } else {
                if (!songlist.isEmpty()) {
                    currentSong = songlist.get(0);
                }
            }
        }

        if (!songset) {
            if (currentSong != null) {
                setSong(currentSong);
            }
        }

        if (songlist != null) {
            APEvents.getInstance().postSongsListUpdated(songlist);
        }
        if (currentSong != null) {
            APEvents.getInstance().postSongChangeEvent(currentSong);
        }
    }

    private void cmd_start() {
        ConnectionListener l = App.get().getConnl();
        if (l != null) {
            l.onAudioServiceConnect(this);
        }
    }

    private void cmd_end() {
        stop();
        stopForeground(false);
        stopForeground(true);

        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
        if (nextPlayer != null) {
            nextPlayer.release();
            nextPlayer = null;
        }

        unregisterRecievers();
        stopSelf();
        XApp.exit();
    }

    private void requestAudioFocus() {
        int af = am.requestAudioFocus(audioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        if (af != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            toast("Failed to get audio focus!");
        }
    }

    private void dropAudioFocus() {
        am.abandonAudioFocus(audioFocusListener);
    }

    boolean playingBeforePause = false;
    AudioManager.OnAudioFocusChangeListener audioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
        public void onAudioFocusChange(int state) {
            switch (state) {
                case AudioManager.AUDIOFOCUS_GAIN:
                case AudioManager.AUDIOFOCUS_GAIN_TRANSIENT:
                    break;
                case AudioManager.AUDIOFOCUS_LOSS:
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    playingBeforePause = isPlaying();
                    pause();
                    unregisterRecievers();
                    dropAudioFocus();
                    break;
            }
        }
    };

    private void registerRecievers() {
        if (recieversRegistered) {
            return;
        }
        aquireWakeLock();
        requestAudioFocus();
        registerMediaButton();
        recieversRegistered = true;
    }

    private void unregisterRecievers() {
        unRegisterMediaButton();
        dropAudioFocus();
        releaseWakeLock();
        recieversRegistered = false;
    }

    private void registerMediaButton() {
        try {
            if (mediaButtonComponent == null) {
                mediaButtonComponent = new ComponentName(this, ButtonReciever.class.getName());
            }
            am.registerMediaButtonEventReceiver(mediaButtonComponent);
        } catch (Exception e) {
        }
    }

    private void unRegisterMediaButton() {
        try {
            am.unregisterMediaButtonEventReceiver(mediaButtonComponent);
        } catch (Exception e) {
        }
    }

    Runnable btnSingle = new Runnable() {
        public void run() {
            playPause();
            btnSinglepress = false;
        }
    };

    boolean btnSinglepress = false;

    private void handleMediabtn() {
        if (btnSinglepress) {
            handle.removeCallbacks(btnSingle);
            btnSinglepress = false;
            playNext();
        } else {
            btnSinglepress = true;
            handle.postDelayed(btnSingle, 280);
        }
    }

    private void aquireWakeLock() {
        try {
            if (wakelock != null) {
                wakelock.acquire();
            }
        } catch (Exception e) {
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakelock != null && wakelock.isHeld()) {
                wakelock.release();
            }
        } catch (Exception e) {
        }
    }

    public void updateNotif() {
    }

    private void showNotification() {
        startForeground(NID, Notific.get(this, currentSong, true));
    }

    private void stopNotification() {
        startForeground(NID, Notific.get(this, currentSong, false));
    }

    private void toast(String msg) {
        Utils.toast(ctx, msg);
    }

    public interface ConnectionListener {
        public void onAudioServiceConnect(AudioService service);
    }
}
*/
