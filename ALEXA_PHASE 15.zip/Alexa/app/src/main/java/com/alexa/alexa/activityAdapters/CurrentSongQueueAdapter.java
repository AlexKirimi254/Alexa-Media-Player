package com.alexa.alexa.activityAdapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;
import java.util.ArrayList;

public class CurrentSongQueueAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<SongItem> songQueue;
    private LayoutInflater inflater;

    public CurrentSongQueueAdapter(Context context, ArrayList<SongItem> songQueue) {
        this.context = context;
        this.songQueue = songQueue;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return songQueue.size();
    }

    @Override
    public Object getItem(int position) {
        return songQueue.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.songlist_item, parent, false);
        }

        // Get the current song
        SongItem song = songQueue.get(position);

        // Set the song title and artist in the TextViews
        TextView title = convertView.findViewById(R.id.songlist_itemTitle);
        TextView artist = convertView.findViewById(R.id.songlist_itemArtist);

        title.setText(song.getTitle());
        artist.setText(song.getArtist());

        return convertView;
    }
}
