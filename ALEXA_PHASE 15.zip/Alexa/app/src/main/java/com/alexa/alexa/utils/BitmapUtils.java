package com.alexa.alexa.utils;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.media.MediaMetadataRetriever;
import android.util.Log;
import java.util.HashMap;
import java.util.Map;
public class BitmapUtils
{
    private static final String TAG = "BitmapUtils";
    private static BitmapUtils deft;

    private static class C{ //cache
        Bitmap bmp;
        int color;
        int id;
    }

    private Map<Integer, C> cache;

    private BitmapUtils(){
        cache = new HashMap<>();
    }

    private static BitmapUtils get(){
        BitmapUtils inst = deft;
        if(inst==null){
            synchronized(BitmapUtils.class){
                inst = BitmapUtils.deft;
                if(inst==null){
                    inst = BitmapUtils.deft = new BitmapUtils();
                }
            }
        }
        return inst;
    }

    public static Bitmap tint(Resources res, int resid, int color){
        return get().itint(res, resid, color);
    }
    private Bitmap itint(Resources res, final int id, final int color){
        C t = cache.get(id);
        if(t==null){
            t = new C();
        }else {
            //if(t.bmp!=null){
            //App.get().toast("using cache -- "+id+" -- "+cache.size());
            return t.bmp;
            // }
        }
        //App.get().toast("skip cache --"+id+" -- "+cache.size());

        Bitmap src =BitmapFactory.decodeResource(res, id);
        Bitmap dest = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(dest);
        Paint mpaint = new Paint();
        mpaint.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_ATOP));
        c.drawBitmap(src,0,0,mpaint);
        //dest.recycle();
        //src.recycle();
        t.bmp = dest;
        t.color = color;
        t.id = id;
        cache.put(id, t);

        return dest;
    }
    
    
    public static Bitmap getSongThumbnailFromFile(String songPath) {
        Bitmap thumbnail = null;
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();

        try {
            // Set the data source to the song file
            mmr.setDataSource(songPath);
            byte[] data = mmr.getEmbeddedPicture(); // Get embedded album art

            if (data != null) {
                thumbnail = BitmapFactory.decodeByteArray(data, 0, data.length);
            } else {
                // If no embedded picture, you may want to load a default image
                Log.d(TAG, "No embedded picture found for: " + songPath);
                // Optionally load a default bitmap
                // thumbnail = BitmapFactory.decodeResource(context.getResources(), R.drawable.default_album_art);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error retrieving thumbnail for: " + songPath, e);
        } finally {
            mmr.release(); // Release the MediaMetadataRetriever
        }

        return thumbnail;
    }
    
    
}

/*
public class BitmapUtils {

    private static final String TAG = "BitmapUtils";

    // Method to retrieve a thumbnail from a song file
    public static Bitmap getSongThumbnailFromFile(String songPath) {
        Bitmap thumbnail = null;
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();

        try {
            // Set the data source to the song file
            mmr.setDataSource(songPath);
            byte[] data = mmr.getEmbeddedPicture(); // Get embedded album art

            if (data != null) {
                thumbnail = BitmapFactory.decodeByteArray(data, 0, data.length);
            } else {
                // If no embedded picture, you may want to load a default image
                Log.d(TAG, "No embedded picture found for: " + songPath);
                // Optionally load a default bitmap
                // thumbnail = BitmapFactory.decodeResource(context.getResources(), R.drawable.default_album_art);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error retrieving thumbnail for: " + songPath, e);
        } finally {
            mmr.release(); // Release the MediaMetadataRetriever
        }

        return thumbnail;
    }

    // Method to decode a bitmap from a file with scaling
    public static Bitmap decodeSampledBitmapFromFile(String filePath, int reqWidth, int reqHeight) {
        // First decode with inJustDecodeBounds=true to check dimensions
        final Options options = new Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;

        return BitmapFactory.decodeFile(filePath, options);
    }

    // Helper method to calculate inSampleSize
    public static int calculateInSampleSize(Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
    
            public static Bitmap tintBitmap(Bitmap src, int color) {
            if (src == null) return null;

            // Create a mutable bitmap to work on
            Bitmap tintedBitmap = Bitmap.createBitmap(src.getWidth(), src.getHeight(), src.getConfig());
            Canvas canvas = new Canvas(tintedBitmap);
            Paint paint = new Paint();

            // Set up a color filter for tinting
            ColorFilter filter = new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_ATOP);
            paint.setColorFilter(filter);
            canvas.drawBitmap(src, 0, 0, paint);

            return tintedBitmap;
        }
    public static Bitmap tint(Resources res, int id, int color) {
        // Decode the resource into a Bitmap
        Bitmap originalBitmap = BitmapFactory.decodeResource(res, id);
        // If the original bitmap is null, return null
        if (originalBitmap == null) {
            return null;
        }
        // Tint the bitmap using the BitmapUtils
        return BitmapUtils.tintBitmap(originalBitmap, color);
    }
            

        /**
         * Fetches the artist's thumbnail from the file system or embedded metadata.
         *
         * @param artistName The name of the artist. This method can be adapted to use file paths if necessary.
         * @return A Bitmap representing the artist's thumbnail, or null if not found.
         *
        public static Bitmap getArtistThumbnailFromFile(String artistName) {
            // Placeholder for where you might retrieve the artist's file path
            String artistFilePath = getFilePathForArtist(artistName);

            if (artistFilePath == null) {
                Log.d(TAG, "File path not found for artist: " + artistName);
                return null; // No file path found for the artist
            }

            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            Bitmap thumbnail = null;

            try {
                // Set the data source to the artist file
                mmr.setDataSource(artistFilePath);
                byte[] artBytes = mmr.getEmbeddedPicture(); // Get embedded album art

                if (artBytes != null) {
                    // Decode the byte array to a Bitmap if album art is found
                    thumbnail = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.length);
                } else {
                    // If no embedded picture, log and return null (or a default image if preferred)
                    Log.d(TAG, "No embedded picture found for artist: " + artistName);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error retrieving thumbnail for artist: " + artistName, e);
            } finally {
                mmr.release(); // Release the MediaMetadataRetriever
            }

            return thumbnail;
        }

        /**
         * Placeholder method to fetch the artist's file path.
         * Replace this method with actual logic to retrieve the file path for the artist.
         *
         * @param artistName The name of the artist.
         * @return The file path where the artist's file can be found, or null if not found.
         *
        private static String getFilePathForArtist(String artistName) {
            // Here, you would implement logic to find the artist's media file.
            // This could involve querying a database, using a media store, or any other method.

            // For now, this is a placeholder that returns null.
            return null;
        }
            /**
         * Retrieves the album thumbnail from the specified album file path.
         *
         * @param albumPath The path of the album file.
         * @return A Bitmap representing the album thumbnail, or null if not found.
         
        public static Bitmap getAlbumThumbnailFromFile(String albumPath) {
            Bitmap thumbnail = null;
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();

            try {
                // Set the data source to the album file
                mmr.setDataSource(albumPath);
                byte[] data = mmr.getEmbeddedPicture(); // Get embedded album art

                if (data != null) {
                    thumbnail = BitmapFactory.decodeByteArray(data, 0, data.length);
                } else {
                    Log.d(TAG, "No embedded picture found for: " + albumPath);
                    // Optionally load a default bitmap
                    // thumbnail = BitmapFactory.decodeResource(context.getResources(), R.drawable.default_album_art);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error retrieving thumbnail for: " + albumPath, e);
            } finally {
                mmr.release(); // Release the MediaMetadataRetriever
            }

            return thumbnail;
        }
    
}*/
