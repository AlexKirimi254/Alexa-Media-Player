package com.alexa.alexa.menu;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.PlaylistAdapter;
import com.alexa.alexa.manager.PlaylistManager;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;

import java.util.ArrayList;
import java.util.List;
import com.alexa.alexa.models.AlbumItem;

public class AddToPlaylistDialog {

    public interface OnPlaylistAddListener {
        void onPlaylistAddSuccess();
    }

    private final Context context;
    private final PlaylistManager playlistManager;
    private final List<SongItem> songs;
    private final OnPlaylistAddListener listener;
    private AlertDialog dialog;

    // Primary constructor
    public AddToPlaylistDialog(Context context, List<SongItem> songs, OnPlaylistAddListener listener) {
        this.context = context;
        this.playlistManager = PlaylistManager.getInstance();
        this.songs = songs;
        this.listener = listener;
    }

    // Overloaded constructor for a single SongItem (without listener)
    public AddToPlaylistDialog(Context context, SongItem song) {
        this(context, createListFromSong(song), null);
    }

    // Overloaded constructor for a single SongItem (with listener)
    public AddToPlaylistDialog(Context context, SongItem song, OnPlaylistAddListener listener) {
        this(context, createListFromSong(song), listener);
    }

    private static List<SongItem> createListFromSong(SongItem song) {
        List<SongItem> list = new ArrayList<SongItem>();
        list.add(song);
        return list;
    }

    public void show() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Add to Playlist");

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_add_to_playlist, null);
        builder.setView(view);

        final RecyclerView playlistsRecyclerView = view.findViewById(R.id.recycler_view_playlists);
        Button cancelButton = view.findViewById(R.id.button_cancel_add_to_playlist);
        Button createNewPlaylistButton = view.findViewById(R.id.button_create_new_playlist);

        final List<Playlist> playlists = playlistManager.getPlaylists();

        if (context instanceof MainActivity) {
            playlistsRecyclerView.setLayoutManager(new LinearLayoutManager(context));
            PlaylistAdapter adapter = new PlaylistAdapter((MainActivity) context, playlists, new PlaylistAdapter.OnItemClickListener() {
					@Override
					public void onItemClick(Playlist playlist) {
						handleAddToPlaylist(playlist);
					}
				});
            playlistsRecyclerView.setAdapter(adapter);
        } else {
            Log.e("AddToPlaylistDialog", "Context is not an instance of MainActivity.");
            return;
        }

        dialog = builder.create();

        cancelButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (dialog != null && dialog.isShowing()) {
						dialog.dismiss();
					}
				}
			});

        createNewPlaylistButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showCreateNewPlaylistDialog();
				}
			});

        dialog.show();
    }

    private void handleAddToPlaylist(Playlist playlist) {
        boolean allAdded = true;
        for (SongItem song : songs) {
            if (!playlistManager.addSongToPlaylist(playlist.getName(), song)) {
                allAdded = false;
            }
        }

        if (allAdded) {
            Toast.makeText(context, "Added to '" + playlist.getName() + "'.", Toast.LENGTH_SHORT).show();
            if (listener != null) {
                listener.onPlaylistAddSuccess();
            }
            refreshPlaylistsTab();
        } else {
            Toast.makeText(context, "Some songs failed to add to '" + playlist.getName() + "'.", Toast.LENGTH_SHORT).show();
        }

        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }
	private void addAlbumSongsToPlaylist(AlbumItem album) {
		List<SongItem> songsInAlbum = album.getSongList();
		if (songsInAlbum == null || songsInAlbum.isEmpty()) {
			Toast.makeText(context, "This album has no songs.", Toast.LENGTH_SHORT).show();
			return;
		}

		AddToPlaylistDialog dialog = new AddToPlaylistDialog(context, songsInAlbum, new AddToPlaylistDialog.OnPlaylistAddListener() {
				@Override
				public void onPlaylistAddSuccess() {
					Toast.makeText(context, "Songs added to playlist successfully.", Toast.LENGTH_SHORT).show();
				}
			});
		dialog.show();
	}
    private void refreshPlaylistsTab() {
        if (context instanceof MainActivity) {
            ((MainActivity) context).runOnUiThread(new Runnable() {
					@Override
					public void run() {
						((MainActivity) context).refreshPlaylistsTab();
					}
				});
        }
    }

    private void showCreateNewPlaylistDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Create New Playlist");

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_create_playlist, null);
        builder.setView(view);

        final EditText playlistNameInput = view.findViewById(R.id.edittext_playlist_name);
        Button createButton = view.findViewById(R.id.button_create_playlist);
        Button cancelButton = view.findViewById(R.id.button_cancel_create_playlist);

        final AlertDialog createDialog = builder.create();

        createButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String playlistName = playlistNameInput.getText().toString().trim();
					if (!playlistName.isEmpty()) {
						Playlist newPlaylist = playlistManager.createPlaylist(playlistName);
						if (newPlaylist != null) {
							handleAddToPlaylist(newPlaylist);
						} else {
							Toast.makeText(context, "Failed to create playlist. It may already exist.", Toast.LENGTH_SHORT).show();
						}
						createDialog.dismiss();
					} else {
						Toast.makeText(context, "Playlist name cannot be empty.", Toast.LENGTH_SHORT).show();
					}
				}
			});

        cancelButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					createDialog.dismiss();
				}
			});

        createDialog.show();
    }
}
