package com.alexa.alexa.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Build;
import android.widget.RemoteViews;

import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.activity.PlayerActivity;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.ThemeManager;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.widget.RemoteViews;
import com.alexa.alexa.Constants;

public class Notific {
    // Private constructor to prevent instantiation
    private Notific() {}

    // Notification channel ID for Android O and above
    private static final String CHANNEL_ID = "com.alexa.alexa.channel.AUDIO_PLAYBACK";

    /**
     * Builds and returns a Notification for the audio player.
     *
     * @param ctx       The application context.
     * @param song      The current SongItem being played.
     * @param isPlaying Boolean indicating if a song is currently playing.
     * @return A configured Notification object.
     */
    public static Notification get(Context ctx, SongItem song, boolean isPlaying) {
        Notification.Builder builder;

        // For Android O and above, create a notification channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel(ctx);
            builder = new Notification.Builder(ctx, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(ctx);
            builder.setPriority(Notification.PRIORITY_MAX);
        }

        builder.setSmallIcon(R.drawable.ic_launcher)
			.setVisibility(Notification.VISIBILITY_PUBLIC)
			.setContent(getRemoteViews(ctx, song, isPlaying))
			.setContentIntent(getContentIntent(ctx))
			.setOngoing(isPlaying); // Make notification ongoing if playing

        return builder.build();
    }

    /**
     * Creates a notification channel for Android O and above.
     *
     * @param ctx The application context.
     */
    public static void createNotificationChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Audio Playback";
            String description = "Notifications for audio playback controls";
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    /**
     * Configures the RemoteViews for the notification layout.
     *
     * @param ctx       The application context.
     * @param song      The current SongItem being played.
     * @param isPlaying Boolean indicating if a song is currently playing.
     * @return A configured RemoteViews object.
     */
    private static RemoteViews getRemoteViews(Context ctx, SongItem song, boolean isPlaying) {
        RemoteViews remoteViews = new RemoteViews(ctx.getPackageName(), R.layout.notification);

        // Set up action buttons with appropriate PendingIntents
        remoteViews.setOnClickPendingIntent(R.id.ant_btn_prev, getActionIntent(ctx, Constants.CMD_PLAY_PREV));
        remoteViews.setOnClickPendingIntent(R.id.ant_btn_next, getActionIntent(ctx, Constants.CMD_PLAY_NEXT));
        remoteViews.setOnClickPendingIntent(R.id.ant_btn_exit, getActionIntent(ctx, Constants.CMD_END));

        // Configure Play/Pause button based on current playback state
        if (isPlaying) {
            remoteViews.setImageViewResource(R.id.ant_btn_playpause_icon, R.drawable.pause);
            remoteViews.setOnClickPendingIntent(R.id.ant_btn_playpause, getActionIntent(ctx, Constants.CMD_PAUSE));
        } else {
            remoteViews.setImageViewResource(R.id.ant_btn_playpause_icon, R.drawable.ic_play);
            remoteViews.setOnClickPendingIntent(R.id.ant_btn_playpause, getActionIntent(ctx, Constants.CMD_PLAY));
        }

        // Set song title and artist with truncation if necessary
        remoteViews.setTextViewText(R.id.ant_title, truncateText(song.getTitle(), 20));
        if (song.getArtist() != null && !song.getArtist().equalsIgnoreCase("<unknown>")) {
            remoteViews.setTextViewText(R.id.ant_artist, "  -  " + truncateText(song.getArtist(), 20));
        } else {
            remoteViews.setTextViewText(R.id.ant_artist, "");
        }

        // Set song icon or default image
        Bitmap songIcon = BitmapUtils.getSongThumbnailFromFile(song.getPath()); // Assuming getPath() returns the song file path
        if (songIcon != null) {
            remoteViews.setImageViewBitmap(R.id.ant_icon, songIcon);
        } else {
            remoteViews.setImageViewResource(R.id.ant_icon, R.drawable.cover_f);
        }

        return remoteViews;
    }

    /**
     * Truncates a string to the specified limit, adding ellipsis if necessary.
     *
     * @param text  The original string.
     * @param limit The maximum allowed length.
     * @return The truncated string.
     */
    private static String truncateText(String text, int limit) {
        if (text.length() > limit) {
            text = text.substring(0, (limit - 3)) + "...";
        }
        return text;
    }

    /**
     * Creates a PendingIntent for a specific action command.
     *
     * @param ctx    The application context.
     * @param action The action command string.
     * @return A configured PendingIntent.
     */
    private static PendingIntent getActionIntent(Context ctx, String action) {
        Intent intent = new Intent(ctx, AudioService.class);
        intent.setAction(action);

        // Use a unique request code for service actions
        return PendingIntent.getService(
			ctx,
			(int) System.currentTimeMillis(), // Use a unique request code
			intent,
			PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    /**
     * Creates a PendingIntent to launch the PlayerActivity when the notification is tapped.
     *
     * @param ctx The application context.
     * @return A configured PendingIntent.
     */
    private static PendingIntent getContentIntent(Context ctx) {
        Intent intent = new Intent(ctx, PlayerActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        // Use a unique request code for activity launch
        return PendingIntent.getActivity(
			ctx,
			(int) System.currentTimeMillis(), // Use a unique request code
			intent,
			PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    /**
     * Utility method to tint a bitmap with a specific color.
     * (Assuming BitmapUtils.tint is implemented elsewhere)
     *
     * @param res   The Resources object.
     * @param id    The drawable resource ID.
     * @param color The color to tint with.
     * @return The tinted Bitmap.
     */
    static Bitmap tint(Resources res, int id, int color) {
        return BitmapUtils.tint(res, id, color);
    }
}


