package com.alexa.alexa.activity;



import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activityAdapters.SongListAdapter;
import com.alexa.alexa.adapters.QueueAdapter;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.manager.QueueManager.QueueListener;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.utils.FastBlur;
import com.alexa.alexa.view.TintedImageView;
import java.util.ArrayList;
import java.util.List;

public class QueueActivity extends BaseActivity implements QueueListener,
AudioService.ConnectionListener,
APEvents.PlaybackStateListener,
APEvents.SongListUpdateListener {

    private RecyclerView queueRecyclerView;
    private QueueAdapter queueAdapter;
    private ImageView clearQueueButton;
    private List<SongItem> songList = new ArrayList<>();

    // UI Components
    private TextView artistNameTextView;
    private TextView songCountTextView;
    private TextView albumCountTextView;
    private ListView songListView;
    private SongListAdapter songAdapter;


    private TextView currentTitle, currentArtist;
    private TextView trackTimeCurrent, trackTimeDuration;
    private LinearLayout art2Background;
    private ImageView currentArt;
    private AudioService aupod;
    private TintedImageView playpauseIcon;
    private SeekBar seeker;
    private Runnable seekerTick;
    private boolean seektouch;
    private Handler handle;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_queue);

        init();
       /* clearQueueButton.setOnClickListener(v -> {
            QueueManager.getInstance().clearQueue();
        });*/
    }

    @Override
    public void onQueueUpdated(List<SongItem> updatedQueue) {
        queueAdapter.updateQueue(updatedQueue);
    }

    

    @Override
    protected void onDestroy() {
        super.onDestroy();
        QueueManager.getInstance().removeQueueListener(this);
    }
    
    private void init(){
        handle = new Handler();
        currentTitle = findView(R.id.auplayer_tv_title);
        currentArtist = findView(R.id.auplayer_tv_artist);
        art2Background = findView(R.id.aupalyer_iv_art2_background);
        currentArt = findView(R.id.auplayer_iv_art);
        playpauseIcon = findView(R.id.auplayer_btn_playpause);
        //
        // Initialize views
        artistNameTextView = findViewById(R.id.artist_name);
        songCountTextView = findViewById(R.id.song_count);
        albumCountTextView = findViewById(R.id.album_count);
       /* songListView = findViewById(R.id.list_view_list1);    

        //*
        // Get artist details from Intent
        String artistName = getIntent().getStringExtra("artist_name");
        int songCount = getIntent().getIntExtra("song_count", 0);
        int albumCount = getIntent().getIntExtra("album_count", 0);

        // Set artist name, song count, and album count in TextViews
        artistNameTextView.setText(artistName);
        songCountTextView.setText("Songs: " + songCount);
        albumCountTextView.setText("Albums: " + albumCount);

        // Retrieve the list of SongItem objects
        songList = getIntent().getParcelableArrayListExtra("song_list");

        // Initialize the adapter and set it to the ListView
        songAdapter = new SongListAdapter(this, songList);
        songListView.setAdapter(songAdapter);

     */   // Set up ListView item click listener
        

        queueRecyclerView = findViewById(R.id.queue_recycler_view);
        clearQueueButton = findViewById(R.id.clear_queue_button);

        queueRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<SongItem> queue = QueueManager.getInstance().getQueue();
        queueAdapter = new QueueAdapter(this, queue);
        queueRecyclerView.setAdapter(queueAdapter);

        QueueManager.getInstance().addQueueListener(this);
        clearQueueButton.setOnClickListener(new View.OnClickListener() {

                private SongItem song;
                @Override
                public void onClick(View v) {
                    
                    QueueManager.getInstance().removeSongFromQueue(song);   
                    //QueueManager.getInstance().removeSongFromQueue(song);
                //    AudioService.getInstance().playSong(song);
                  // QueueManager.getInstance().initQueue();//. .notifyDataSetChanged();
                    // Toast.makeText(context, "Removed from queue", Toast.LENGTH_SHORT).show();
                }
            });
        queueAdapter.setOnItemClickListener(new QueueAdapter.OnItemClickListener() {



                @Override
                public void onItemClick(SongItem songItem) {
                    /*  if (isMultiSelectEnabled) {
                     queueAdapter.toggleSelection(songItem);
                     } else {*/

                    //  App.get().getMainActivity().getAudioService().clearQueue();
                    //  QueueManager.getInstance().clearQueue();
                    AudioService.getInstance().playSong(songItem);
                    //  QueueManager.getInstance().addSongToQueue(songItem);
                }


                /*   @Override
                 public void onItemLongClick(SongItem songItem, boolean enableMultiSelect) {
                 isMultiSelectEnabled = enableMultiSelect;
                 adapter.enableMultiSelect(true);
                 adapter.toggleSelection(songItem);
                 showBottomSheet();
                 */
			});
        seeker = findView(R.id.aupalyer_seeker);
        seeker.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                @Override
                public void onProgressChanged(SeekBar p1, int pos, boolean touch)
                {
                    if(aupod!=null && seektouch){
                        aupod.seekTo(pos);
                        trackTimeCurrent.setText(formatTime(pos));
                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar p1)
                {
                    stopSeeker();
                    seektouch = true;
                }

                @Override
                public void onStopTrackingTouch(SeekBar p1)
                {
                    seektouch = false;
                    if(aupod!=null && aupod.isPlaying()){
                        startSeeker();
                    }
                }
            });

        seekerTick = new Runnable(){
            @Override
            public void run(){
                if(aupod!=null){
                    int pos = aupod.getCurrentPosition();
                    seeker.setProgress(pos);
                    trackTimeCurrent.setText(formatTime(pos));
                    handle.postDelayed(seekerTick,1000);
                }
            }
        };
        //*/

        trackTimeCurrent = findView(R.id.auplayer_currentpos);
        trackTimeDuration = findView(R.id.auplayer_duration);

        //
        setClickable(R.id.auplayer_btn_playpause);
        setClickable(R.id.auplayer_btn_prev);
        setClickable(R.id.auplayer_btn_next);
        setClickable(R.id.auplayer_btn_options);
        setClickable(R.id.auplayer_btn_back);
    } 


    /**
     * Example of playing a song from the AudioService via App class.
     */
    private void playSong(SongItem song) {
        AudioService audioService = App.get().getAudioService();
        if (audioService != null) {
            audioService.playSong(song); // Call the play song method
        } else {
            Toast.makeText(this, "Audio Service not connected", Toast.LENGTH_SHORT).show();
        }
    }


    private void unsubscribe() {
        APEvents.getInstance().removePlaybackEventListener(this);
        APEvents.getInstance().removeSongsListUpdateListener(this);
    }


    @Override
    public void onSongsListUpdated(List<SongItem> list) {
        // Update the local song list and refresh the adapter
     //   songList.clear();
      //  songList.addAll(list);
        queueAdapter.notifyDataSetChanged();
    }

    private void updateInfo(){
        final SongItem si = aupod.getCurrentSong();
        if(aupod==null || si==null){
            return;
        }

        currentTitle.setText(si.title);
        currentArtist.setText(si.artist);

        //hideView(R.id.auplayer_iv_art_b);
        if(si.getThumbnail()!=null){
            currentArt.setImageBitmap(si.getThumbnail());
            setLargeArt(si.getThumbnail());
        }else{
            App.runInBackground(new Runnable(){
                    public void run(){
                        final Bitmap bmp = BitmapUtils.tint(ctx.getResources(), R.drawable.cover_f, ThemeManager.getTheme().icon);
                        if(bmp!=null){
                            handle.post(new Runnable(){
                                    public void run(){
                                        currentArt.setImageBitmap(bmp);
                                    }
                                });
                        }
                    }
                });
            //showView(R.id.auplayer_iv_art_b);
            //setLargeArt( BitmapFactory.decodeResource(ctx.getResources(), R.drawable.fallback_cover));
        }

        if(aupod!=null){
            if(aupod.isPlaying()){
                playpauseIcon.setBackgroundResource(R.drawable.ic_pause);
            }else{
                playpauseIcon.setBackgroundResource(R.drawable.ic_play);
            }
        }

        playpauseIcon.reset();

        //playpauseIcon.setTint(tm.);

        int pos = aupod.getCurrentPosition();
        trackTimeDuration.setText(formatTime((int)si.duration));
        trackTimeCurrent.setText(formatTime(pos));

        seeker.setMax((int)si.duration);
        seeker.setProgress(pos);

        //
    }

    private void setLargeArt(final Bitmap bmp){
        //art2Background.setBackgroundDrawable(new BitmapDrawable(bmp));
        App.runInBackground(new Runnable(){
                public void run(){
                    final Bitmap img = FastBlur.fastblur(bmp,0.2f,3);
                    if(img!=null){
                        App.runInUiThread(new Runnable(){
                                public void run(){
                                    art2Background.setBackgroundDrawable(new BitmapDrawable(img));
                                }
                            });
                    }
                }
            });
    }


    private void startSeeker(){
        stopSeeker();
        handle.postDelayed(seekerTick,0);
    }

    private void stopSeeker(){
        handle.removeCallbacks(seekerTick);
        handle.removeCallbacks(seekerTick);
    }

    private String formatTime(int time){
        //String t = "";
        int hrs = (int) (time/ (1000*60*60)) % 60;
        int min = (int) ( time/ (1000*60)) % 60;
        int sec = (int) (time /1000) % 60;
        if(hrs==0){
            return d(min)+":"+d(sec);
        }

        return d(hrs)+":"+d(min)+":"+d(sec);
    }

    private String d(int t){
        if(t<10){
            return "0"+t;
        }
        return ""+t;
    }

    @Override
    public void onClick(View v){
        int id = v.getId();
        switch(id){
            case R.id.auplayer_btn_playpause:
                if(aupod!=null){
                    aupod.playPause();
                }
                break;
            case R.id.auplayer_btn_next:
                if(aupod!=null){
                    aupod.playNext();
                }
                break;
            case R.id.auplayer_btn_prev:
                if(aupod!=null){
                    aupod.playPrev();
                }
                break;
            case R.id.auplayer_btn_back:
                finish();
                break;
            case R.id.auplayer_btn_options:
                //new CurrentSongOptions(this, aupod.getCurrentSong()).show();

                //  startActivity(PlaylistDetailsActivity.class);


                break;
        }
    }
    @Override
    public void onAudioServiceConnect(AudioService service){
        aupod = service;
        updateInfo();
        aupod.requestPlaystateUpdate();
    }

    @Override
    public void onPlaybackStart() {
        handle.postDelayed(new Runnable() {
                public void run() {
                    playpauseIcon.setBackgroundResource(R.drawable.ic_pause);
                    playpauseIcon.reset();
                }
            }, 10);

        startSeeker();
    }

    @Override
    public void onPlaybackPause() {
        handle.postDelayed(new Runnable() {
                public void run() {
                    playpauseIcon.setBackgroundResource(R.drawable.ic_play);
                    playpauseIcon.reset();
                }
            }, 10);
        stopSeeker();
    }

    @Override
    public void onPlaybackStop() {
        handle.postDelayed(new Runnable() {
                public void run() {
                    playpauseIcon.setBackgroundResource(R.drawable.ic_play);
                    playpauseIcon.reset();
                }
            }, 10);

        stopSeeker();
    }



    ThemeManager.Theme theme;

    // todo: this takes too long
    @Override
    protected void onApplyTheme(ThemeManager.Theme theme)
    {
        super.onApplyTheme(theme);
        this.theme = theme;
        //
        themer.dispatchMessage(new Message());
    }

    Handler themer = new Handler(){
        @Override
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);
            //
            setTextViewsColor(theme.text,
                              trackTimeCurrent,
                              trackTimeDuration,
                              currentArtist,
                              currentTitle);
            //
            currentTitle.setBackgroundColor(theme.background);
            currentArtist.setBackgroundColor(theme.background);
            //
            setTintablesTint(theme.icon,
                             R.id.au1,
                             R.id.au2,
                             R.id.au3,
                             R.id.au4,
                             R.id.auplayer_btn_playpause);
            //
            seeker.getProgressDrawable().setColorFilter(theme.icon, PorterDuff.Mode.SRC_ATOP);
            seeker.getThumb().setColorFilter(theme.icon, PorterDuff.Mode.SRC_ATOP);
        }
    };

    @Override
    protected void onPause(){
        stopSeeker();
        APEvents.getInstance().removePlaybackEventListener(this);
        super.onPause();
    }


    @Override
    protected void onResume(){
        super.onResume();
        APEvents.getInstance().addPlaybackEventListener(this);
        AudioService.connect(this, this);
        //
    }
    @Override
    public void onSongChanged(final SongItem song) {
        currentTitle.setTextColor(R.color.color2);
        currentArtist.setTextColor(R.color.abc_primary_text_material_dark);
        if (song.getThumbnail() != null) {
            currentArt.setBackgroundDrawable(new BitmapDrawable(song.getThumbnail()));
        } else {
            currentArt.setImageBitmap(BitmapUtils.tint(getResources(), R.drawable.cover_f, ThemeManager.getTheme().icon));
        }
        updateInfo();
    }
    
}
