package com.alexa.alexa.models;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.alexa.alexa.utils.BitmapUtils;
import java.util.List;


/**
 * Represents an Artist with relevant details, including methods to count songs and albums.
 */
public class ArtistItem implements Parcelable {
    private int id;
    public String name;
    private List<SongItem> songList;  // List of songs for the artist
    private List<AlbumItem> albumList;
    private int albumCount;
    public int songcount;  // List of albums for the artist

    // Constructor with all details
    public ArtistItem(int id, String name, int songcount, int albumCount) {
        this.id = id;
        this.name = name;
        this.songcount = songcount;
        this.albumCount = albumCount;
    }

    // Default Constructor
    public ArtistItem() {
    }

    // Getter and Setter methods
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    public int getSongcount() {
        return songcount;
    }
    public void setSongcount(int songcount) {
        this.songcount = songcount;
    }
    public int getAlbumCount() {
        return albumCount;
    }
    public void setAlbumCount(int albumCount) {
        this.albumCount = albumCount;
    }
    
    public List<SongItem> getSongList() {
        return songList;
    }

    public List<AlbumItem> getAlbumList() {
        return albumList;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setSongList(List<SongItem> songList) {
        this.songList = songList;
    }

    public void setAlbumList(List<AlbumItem> albumList) {
        this.albumList = albumList;
    }

    // Method to count the number of songs for this artist
    

    // Method to count the number of albums for this artist
    public int getAlbumsCount() {
        return albumList != null ? albumList.size() : 0;
    }

    // Parcelable implementation

    protected ArtistItem(Parcel in) {
        id = in.readInt();
        name = in.readString();
        songList = in.createTypedArrayList(SongItem.CREATOR);  // Reading the song list
        albumList = in.createTypedArrayList(AlbumItem.CREATOR);  // Reading the album list
    }

    public static final Creator<ArtistItem> CREATOR = new Creator<ArtistItem>() {
        @Override
        public ArtistItem createFromParcel(Parcel in) {
            return new ArtistItem(in);
        }

        @Override
        public ArtistItem[] newArray(int size) {
            return new ArtistItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(id);
        parcel.writeString(name);
        parcel.writeTypedList(songList);  // Writing the song list
        parcel.writeTypedList(albumList);  // Writing the album list
    }
    public Bitmap getThumbnail() {
        try {
            // Implement logic to fetch the thumbnail based on the artist's ID or name
            // Here, I'm assuming you have a utility method that can fetch the thumbnail from a source
            // Example: return BitmapUtils.getArtistThumbnailFromId(this.id);
            return BitmapUtils.getSongThumbnailFromFile(name); // Replace with actual method
        } catch (Exception e) {
            Log.e("ArtistItem", "Error retrieving thumbnail for artist: " + name, e);
            return null; // Return null if there is an error
        }
    }
    
}
