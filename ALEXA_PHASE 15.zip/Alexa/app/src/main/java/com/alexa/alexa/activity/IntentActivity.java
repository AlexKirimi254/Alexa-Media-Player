package com.alexa.alexa.activity;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.service.AudioService;

public class IntentActivity extends BaseActivity{
	
    @Override
    public void onCreate(Bundle savedInstanceState){
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.iplayer);
      //  Intent i = getIntent();
      //  String path = clean(i.getDataString());
        //
        //AudioService.getInstance().playFromIntent(getApplicationContext(), path);
		
		//handleIntent(getIntent());
        //finish();
    }

    private String clean(String str){
        String cstr = str.replace("%20"," ");
        return cstr;
    }
    //
	
	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		handleIntent(intent);
	}

	private void handleIntent(Intent intent) {
		if (intent == null) {
			App.get().toast("No intent received.");
			return;
		}
		String path = clean(intent.getDataString());
		//Intent i = getIntent();
		
		String action = intent.getAction();
		Uri data = intent.getData();

		if (Intent.ACTION_VIEW.equals(action) && data != null) {
			// Handle opening an audio file from external sources
			playAudioFromUri(data, action);
		} else if ("com.alexa.alexa.CMD_PLAY_FROM_INTENT".equals(action) && data != null) {
			// Handle custom play intent
			playAudioFromUri(data, action);
		} else if (Intent.ACTION_SEND.equals(action)) {
			// Handle shared audio
			Bundle extras = intent.getExtras();
			if (extras != null) {
				Uri audioUri = extras.getParcelable(Intent.EXTRA_STREAM);
				if (audioUri != null) {
					playAudioFromUri(audioUri, action);
				} else {
					App.get().toast("No audio file attached.");
				}
			}
		} else {
			App.get().toast("Unsupported action: " + action);
		}
	}

	private void playAudioFromUri(final Uri audioUri, final String action) {
		if (audioUri != null) {
			App.runInBackground(new Runnable() {
					@Override
					public void run() {
						try {
							// Get AudioService from App singleton
							final AudioService audioService = App.get().getAudioService();
							if (audioService == null) {
								App.runInUiThread(new Runnable() {

										private AudioService aupod;
										@Override
										public void run() {
											aupod=audioService;
											App.get().toast("Audio service not initialized.");
										}
									});
								return;
							}

							// Use playFromIntent to handle the audio playback
							App.get().getAudioService().playFromIntent(IntentActivity.this, action);
							//App.get().getAudioService().playFromIntent(getApplicationContext(), action);
							App.runInUiThread(new Runnable() {
									@Override
									public void run() {
										App.get().toast("Playing: " + audioUri.toString());
									}
								});
						} catch (final Exception e) {
							App.runInUiThread(new Runnable() {
									@Override
									public void run() {
										App.get().toast("Error playing audio: " + e.getMessage());
									}
								});
							e.printStackTrace();
						}
					}
				});
		} else {
			App.get().toast("Invalid audio URI.");
		}
	}
	
	
}
