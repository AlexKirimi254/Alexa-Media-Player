package com.alexa.alexa.utils;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.MediaPlayer;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.PresetReverb;
import android.media.audiofx.Virtualizer;
import android.widget.Toast;
import com.alexa.alexa.R;

public class EqualizerUtils {

    private static BassBoost bassBoost;
    private static Virtualizer virtualizer;
    private static PresetReverb presetReverb;
    private static Equalizer equalizer;

    // Method to check if equalizer effects are available
    public static boolean hasEqualizer(final Context context) {
        final Intent effects = new Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL);
        final PackageManager pm = context.getPackageManager();
        final ResolveInfo ri = pm.resolveActivity(effects, 0);
        return ri != null;
    }

    // Open Audio Effect session for controlling effects
    public static void openAudioEffectSession(final Context context, final int sessionId) {
        final Intent intent = new Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION);
        intent.putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId);
        intent.putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.getPackageName());
        intent.putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC);
        context.sendBroadcast(intent);
    }

    // Close Audio Effect session and release effects
    public static void closeAudioEffectSession(final Context context, final int sessionId) {
        final Intent audioEffectsIntent = new Intent(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION);
        audioEffectsIntent.putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId);
        audioEffectsIntent.putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.getPackageName());
        context.sendBroadcast(audioEffectsIntent);
        releaseAudioEffects();
    }

    // Open equalizer and initialize audio effects
    public static void openEqualizer(final Activity activity, final MediaPlayer mediaPlayer) {
        final int sessionId = mediaPlayer.getAudioSessionId();
        if (sessionId == AudioEffect.ERROR_BAD_VALUE) {
            notifyNoSessionId(activity);
        } else {
            try {
                final Intent effects = new Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL);
                effects.putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId);
                effects.putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC);
                activity.startActivityForResult(effects, 0);

                // Initialize equalizer with frequency bands and other effects
                initializeAudioEffects(sessionId);

            } catch (final ActivityNotFoundException notFound) {
                notFound.printStackTrace();
            }
        }
    }

    // Initialize Equalizer, BassBoost, Virtualizer, and PresetReverb
    private static void initializeAudioEffects(int sessionId) {
        // Initialize BassBoost
        bassBoost = new BassBoost(0, sessionId);
        bassBoost.setStrength((short) 500); // Default strength
        bassBoost.setEnabled(true);

        // Initialize Virtualizer
        virtualizer = new Virtualizer(0, sessionId);
        virtualizer.setStrength((short) 500); // Default strength
        virtualizer.setEnabled(true);

        // Initialize PresetReverb
        presetReverb = new PresetReverb(0, sessionId);
        presetReverb.setPreset(PresetReverb.PRESET_LARGEHALL);
        presetReverb.setEnabled(true);

        // Initialize Equalizer
        equalizer = new Equalizer(0, sessionId);
        equalizer.setEnabled(true);
    }

    // Adjust gain level for a specific frequency band (in Hertz)
    public static void setEqualizerBandLevel(int bandIndex, short level) {
        if (equalizer != null && bandIndex >= 0 && bandIndex < equalizer.getNumberOfBands()) {
            equalizer.setBandLevel((short) bandIndex, level);
        }
    }

    // Get center frequencies of equalizer bands (in Hertz)
    public static int[] getCenterFrequencies() {
        if (equalizer != null) {
            int numBands = equalizer.getNumberOfBands();
            int[] centerFrequencies = new int[numBands];
            for (int i = 0; i < numBands; i++) {
                centerFrequencies[i] = equalizer.getCenterFreq((short) i) / 1000; // Convert from milliHertz to Hertz
            }
            return centerFrequencies;
        }
        return new int[0];
    }

    // Get the minimum and maximum gain levels (in dB) for equalizer bands
    public static short getMinBandLevel() {
        if (equalizer != null) {
            return equalizer.getBandLevelRange()[0];
        }
        return 0;
    }

    public static short getMaxBandLevel() {
        if (equalizer != null) {
            return equalizer.getBandLevelRange()[1];
        }
        return 0;
    }

    // Release audio effects to prevent memory leaks
    private static void releaseAudioEffects() {
        if (bassBoost != null) {
            bassBoost.release();
            bassBoost = null;
        }
        if (virtualizer != null) {
            virtualizer.release();
            virtualizer = null;
        }
        if (presetReverb != null) {
            presetReverb.release();
            presetReverb = null;
        }
        if (equalizer != null) {
            equalizer.release();
            equalizer = null;
        }
    }

    public static void notifyNoSessionId(final Context context) {
        Toast.makeText(context, context.getString(R.string.bad_id), Toast.LENGTH_SHORT).show();
    }
}
