package com.alexa.alexa.menu;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.view.Window;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.TagEditorActivity;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import java.io.ByteArrayOutputStream;
import com.alexa.alexa.activity.PlayerActivity;

public class CurrentSongOptions
{
    PlayerActivity act;
    SongItem si;
    
    Dialog dlg;
    
    public CurrentSongOptions(PlayerActivity ctx, SongItem song){
        this.act = ctx;
        this.si = song;
        //
        dlg = new Dialog(ctx);
        dlg.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dlg.setContentView(R.layout.dlg_auplayer_options);
    }
    
    public void show(){
        dlg.show();
    }
    
    public void dismiss(){
        dlg.dismiss();
    }
	
	//@Override
    public void onClick(View v) {
        if (v.getTag() != null) {
            String tag = v.getTag().toString();
            if (tag != null) {
                tag = tag.split(" ")[0];
            }
            switch (tag) {
                case "playnext":
                    App.get().getMainActivity().getSongsQueueTab().onSongChanged(si);
					QueueManager.getInstance().addSongToQueue(si);
					// ctx.launchCurrentQueueActivity(); // Launch the CurrentQueue activity after adding to the queue
                    break;
                case "resetshuffle":
                    //AudioService.getInstance().resetShuffle(); // Uncomment this line if playAll method is implemented
                    break;
                case "shuffle":
                    AudioService.getInstance().shuffleAll();
                    break;
                case "addtoplaylist":
                    new AddToPlaylistDialog(act,si).show(); // Show the Add to Playlist dialog
                    break;
                case "editfiletags":
					Intent intent = new Intent(act, TagEditorActivity.class);
					intent.putExtra("title", si.getTitle());
					intent.putExtra("artist", si.getArtist());
					intent.putExtra("album", si.getAlbum());
					intent.putExtra("genre", si.getGenre());
					intent.putExtra("year", si.getYear());
					intent.putExtra("path", si.getPath());

					// Add the thumbnail to the intent as a byte array
					if (si.getThumbnail() != null) {
						Bitmap thumbnail = si.getThumbnail(); // Assuming getThumbnail returns a Bitmap
						ByteArrayOutputStream stream = new ByteArrayOutputStream();
						thumbnail.compress(Bitmap.CompressFormat.PNG, 100, stream);
						byte[] thumbnailBytes = stream.toByteArray();
						intent.putExtra("thumbnail", thumbnailBytes);
					}

					act.startActivity(intent);
					break;


                case "deletesong":
                    new ConfirmDeleteDialog(App.get().getMainActivity(), si).show();
                    break;
                default:
                    break;
            }
        }
        dismiss();
    }
	
}
