package com.alexa.alexa.activity;



import android.Manifest;
import android.annotation.NonNull;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.SearchPanel;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.PlayerAdapter;
import com.alexa.alexa.adapters.SongsQueueAdapter;
import com.alexa.alexa.manager.PlaylistManager;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.menu.MainActOptions;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.tabs.AlbumsTab;
import com.alexa.alexa.tabs.ArtistTab;
import com.alexa.alexa.tabs.FoldersTab;
import com.alexa.alexa.tabs.PlaylistsTab;
import com.alexa.alexa.tabs.SongsListTab;
import com.alexa.alexa.tabs.SongsQueueTab;
import com.alexa.alexa.tabs.VideosTab;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.utils.EqualizerUtils;
import com.alexa.alexa.view.RoundedLinearLayout;
import com.alexa.alexa.view.TintedImageView;
import com.alexa.alexa.view.tabview.TabView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class MainActivity extends BaseActivity implements 
AudioService.ConnectionListener,
APEvents.PlaybackStateListener,
APEvents.SongListUpdateListener,
SearchPanel.OnSearchResultItemClickListener,
View.OnClickListener {

    private QueueManager queueManager;
    private ArrayList<SongItem> songsQueue;
    private SongsQueueAdapter queueAdapter;
    private AudioService aupod;
    private ImageView currentImage;
    private TextView currentSongTitle, currentSongArtist;
    private TintedImageView btnPlayPause;
    private GestureDetector gestureDetector;
	private RoundedLinearLayout roundedLinearLayout;
	private TabView tabView;
    private SongsListTab songsTab;
    private ArtistTab artistTab;
    private AlbumsTab albumsTab;
    private PlaylistsTab playlistTab;
	//private VideosTab vtab;
    private SongsQueueTab sqTab;
    private SearchPanel searchPanel;
    private List<SongItem> songsList;
    private Handler handler = new Handler();
    private PlaylistManager playlistManager;
	private PlayerAdapter playerAdapter;
	FoldersTab foldersTab;
    private static final String PREFS_NAME = "AppPrefs";
    private static final String KEY_ACCENT_COLOR = "accent_color";
    private static final String PREF_NAME = "SongQueuePrefs";
    private static final String QUEUE_KEY = "songs_queue";
    private static final long TIMEOUT_MS = 5000; // Timeout for resetting the queue

    private SharedPreferences sharedPreferences;
    private Gson gson;
    private boolean responseReceived;

	private Activity activity;

    private MediaPlayer mPlayer;

// Add these constants to your MainActivity class
	private static final String CHATBOT_PREFS = "ChatbotPrefs";
	private static final String KEY_CHAT_HISTORY = "chat_history";
	private static final String KEY_THEME_PREFERENCE = "theme_preference";

// Add these instance variables to your MainActivity class
	private LinearLayout chatContainer;
	private ScrollView chatScrollView;
	private EditText chatInput;
	private boolean isChatOpen = false;
	private List<String> chatHistory = new ArrayList<>();

	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Set MainActivity in the application class (App.get().setMainActivity(this) should be called once)
        App.get().setMainActivity((MainActivity) this);
		//	APEvents.getInstance().addPlaybackEventListener(this);
		// Handle the incoming intent


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		//handleIntent(getIntent());
        // Initialize views and objects
        btnPlayPause = findViewById(R.id.activity_main_iv_playpause);
        queueManager = QueueManager.getInstance();
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        gson = new Gson();

        // Initialize the queue only once (no need to call it again if the queue is already initialized)
        if (queueManager.isQueueEmpty()) {  // Assuming you have a method to check if the queue is empty
            queueManager.initQueue();
        }

        // Restore the queue
        List<SongItem> restoredQueue = loadSongsQueue();
        if (!restoredQueue.isEmpty()) {
            // Only add songs to the queue if the queue was empty and needs restoration
            for (SongItem song : restoredQueue) {
                queueManager.addSongToQueue(song);
            }
            handleQueueRestoration();  // Restore the queue (this could involve showing a dialog or other UI updates)
        }

        // Initialize the SongsQueueTab (this happens only once)
        sqTab = new SongsQueueTab(this);

        // Add QueueListener to queueManager to handle updates
        queueManager.addQueueListener(new QueueManager.QueueListener() {
                @Override
                public void onQueueUpdated(List<SongItem> updatedQueue) {
                    if (sqTab != null) {
                        sqTab.onQueueUpdated(updatedQueue);
                    }
                }

                @Override
                public void onSongChanged(SongItem currentSong) {
                    if (sqTab != null) {
                        sqTab.onSongChanged(currentSong);
                    }
                }
            });

        // Restore queue on app startup (this method should handle checking if the queue should be restored)
        restoreQueue();

        // Check for permissions and request if needed
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                                              new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 123);
        }

        // Initialize PlaylistManager
        PlaylistManager.initialize(this.getApplicationContext());

        // Bind to the AudioService (this should only be done once)
        Intent serviceIntent = new Intent(this, AudioService.class);
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);

		SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        boolean onboardingComplete = prefs.getBoolean("OnboardingComplete", false);

		if (!onboardingComplete) {
            startActivity(new Intent(this, OnboardingActivity.class));
            finish();
            return;
        }
        // Perform any other initialization logic
        init();

// Add this to your onCreate() method after other initializations
		initChatbot();
		//aupod = new AudioService();
		handleIntent(getIntent());


		// Initialize TabView tabs
	}

	private boolean checkIsPlayer() {

        boolean isPlayer = aupod.isPlaying();
        if (!isPlayer) {
            EqualizerUtils.notifyNoSessionId(this);
        }
        return isPlayer;
    }

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		handleIntent(intent);
	}

	private void handleIntent(Intent intent) {
		if (intent == null) return;

		String action = intent.getAction();
		Uri data = intent.getData();

		if (Intent.ACTION_VIEW.equals(action) && data != null) {
			// Wait for AudioService to be connected before playing
			if (aupod == null) {
				// Store the intent to process after service connects
				pendingAudioUri = data;
				pendingAction = action;
			} else {
				playAudioFromUri(data, action);
			}
		}
		// Other intent handling remains the same...
	}

	private Uri pendingAudioUri;
	private String pendingAction;

	@Override
	public void onAudioServiceConnect(AudioService service) {
		aupod = service;
		// Process any pending audio URI now that service is connected
		if (pendingAudioUri != null) {
			playAudioFromUri(pendingAudioUri, pendingAction);
			pendingAudioUri = null;
			pendingAction = null;
		}
		// Rest of your connection handling...
		aupod.getSongsList();
        aupod.requestPlaystateUpdate();
        if (aupod.isPlaying()) {
            onPlaybackStart();
        }

	}

	private void playAudioFromUri(final Uri audioUri, final String action) {
		if (audioUri != null) {
			App.runInBackground(new Runnable() {
					@Override
					public void run() {
						try {
							// Get AudioService from App singleton
							final AudioService audioService = App.get().getAudioService();
							if (audioService == null) {
								App.runInUiThread(new Runnable() {
										@Override
										public void run() {
											aupod=audioService;
											App.get().toast("Audio service not initialized.");
										}
									});
								return;
							}

							// Use playFromIntent to handle the audio playback
							audioService.playFromIntent(MainActivity.this, action);

							App.runInUiThread(new Runnable() {
									@Override
									public void run() {
										App.get().toast("Playing: " + audioUri.toString());
									}
								});
						} catch (final Exception e) {
							App.runInUiThread(new Runnable() {
									@Override
									public void run() {
										App.get().toast("Error playing audio: " + e.getMessage());
									}
								});
							e.printStackTrace();
						}
					}
				});
		} else {
			App.get().toast("Invalid audio URI.");
		}
	}

	// Restore queue from preferences or database
    private void restoreQueue() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String queueJson = prefs.getString("saved_queue", null);
        int currentSongIndex = prefs.getInt("current_song_index", -1);

        if (queueJson != null) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<SongItem>>() {}.getType();
            List<SongItem> restoredQueue = gson.fromJson(queueJson, type);

            if (restoredQueue != null) {
                queueManager.setQueue(restoredQueue);
                songsQueue = new ArrayList<>(restoredQueue);
                if (currentSongIndex >= 0 && currentSongIndex < restoredQueue.size()) {
                    SongItem currentSong = restoredQueue.get(currentSongIndex);
                    queueManager.setCurrentSong(currentSong);
                    onSongChanged(currentSong); // Update UI with current song
                }
            }
        }
    }
	public void playVideoo(String videoPath) {
		Intent intent = new Intent(this, VideoPlayerActivity.class);
		intent.putExtra("videoPath", videoPath);
		startActivity(intent);
	}
	private void handleQueueRestoration() {
        List<SongItem> restoredQueue = loadSongsQueue();

        if (!restoredQueue.isEmpty()) {
            // If the queue has saved songs, ask the user whether to restore it or not
            Toast.makeText(this, "Would you like to resume the previous queue?", Toast.LENGTH_SHORT).show();
            showQueueRestoreDialog(restoredQueue);
        }
    }

    public void toast() {
        Toast.makeText(this, " Playback Error", Toast.LENGTH_SHORT).show();
    }
    private void showQueueRestoreDialog(final List<SongItem> restoredQueue) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Would you like to resume the previous queue?");

        // Positive button to restore the queue
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Mark the response as received
                    responseReceived = true;

                    // Restore the queue to its previous state
                    queueManager.setQueue(new ArrayList<>(restoredQueue));  // Restore the queue
                    songsQueue = new ArrayList<>(restoredQueue);  // Set the current songs queue
                    int currentSongIndex = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .getInt("current_song_index", -1);

                    // Restore the last played song
                    if (currentSongIndex >= 0 && currentSongIndex < restoredQueue.size()) {
                        SongItem currentSong = restoredQueue.get(currentSongIndex);
                        queueManager.setCurrentSong(currentSong);
                        onSongChanged(currentSong);  // Update UI with the current song
                    }

                    Toast.makeText(MainActivity.this, "Previous queue restored.", Toast.LENGTH_SHORT).show();
                }
            });

        // Negative button to clear the queue
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    responseReceived = true;
                    queueManager.clearQueue();  // Clear the queue
                    Toast.makeText(MainActivity.this, "Queue has been reset.", Toast.LENGTH_SHORT).show();
                    saveQueue();  // Save the empty queue
                }
            });

        // Show the dialog
        builder.show();

        // Reset the queue if no response after the timeout
        new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!responseReceived) {
                        queueManager.clearQueue();
                        Toast.makeText(MainActivity.this, "Queue has been reset due to no response.", Toast.LENGTH_SHORT).show();
                        saveQueue();  // Save the empty queue
                    }
                }
            }, TIMEOUT_MS);
    }

    private void saveSongsQueue() {
        List<SongItem> currentQueue = queueManager.getQueue();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String json = gson.toJson(currentQueue);
        editor.putString(QUEUE_KEY, json);
        editor.apply();
    }

    private List<SongItem> loadSongsQueue() {
        String json = sharedPreferences.getString(QUEUE_KEY, null);
        if (json != null) {
            Type type = new TypeToken<List<SongItem>>() {}.getType();
            return gson.fromJson(json, type);
        }
        return new ArrayList<>();
    }

	public void openGitPage(@NonNull final View v) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.github_url))));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, getString(R.string.no_browser), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
	public void openEqualizerPanel(Activity activity) {
        if (EqualizerUtils.hasEqualizer(ctx)) {
            EqualizerUtils.openEqualizer(activity, mPlayer);
        } else {
            Toast.makeText(ctx, "No equalizer available on this device.", Toast.LENGTH_SHORT).show();
        }
    }
// Save queue on app shutdown or pause
    @Override
    protected void onPause() {
        super.onPause();
        saveQueue();
    }

    private void saveQueue() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        List<SongItem> currentQueue = queueManager.getQueue();
        SongItem currentSong = queueManager.getCurrentSong();
        int currentSongIndex = currentQueue.indexOf(currentSong);

        Gson gson = new Gson();
        String queueJson = gson.toJson(currentQueue);

        editor.putString("saved_queue", queueJson);
        editor.putInt("current_song_index", currentSongIndex);
        editor.apply();
    }

// Other existing methods remain unchanged...

    private void init() {
        setupUI();
        setupTabs();
        playlistManager = PlaylistManager.getInstance();
        songsQueue = new ArrayList<>();
    }

    private void setupUI() {
        currentSongTitle = findViewById(R.id.activity_main_tv_title);
        currentSongArtist = findViewById(R.id.activity_main_tv_artist);
        currentImage = findViewById(R.id.activity_main_iv_currentimage);



        btnPlayPause.setBackgroundResource(R.drawable.ic_play);
    }


	private void setupTabs() {
		tabView = findViewById(R.id.activity_main_tabview1);
		songsTab = new SongsListTab(this);
		artistTab = new ArtistTab(this);
		albumsTab = new AlbumsTab(this);
		playlistTab = new PlaylistsTab(this);
		searchPanel = new SearchPanel(this, this);
		//vtab = new VideosTab(this);
		sqTab = new SongsQueueTab(this);

		// New FoldersTab
		foldersTab = new FoldersTab(this);

		tabView.addTab("QUEUE", sqTab);
		//tabView.addTab("VIDEOS", vtab);
		tabView.addTab("SONGS", songsTab); 
		tabView.addTab("ARTIST", artistTab);
		tabView.addTab("ALBUMS", albumsTab);
		tabView.addTab("PLAYLIST", playlistTab);
		tabView.addTab("FOLDERS", foldersTab); // Add the FoldersTab

		tabView.showTab(1); // Show FOLDERS tab by default
	}
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            AudioService.LocalBinder binder = (AudioService.LocalBinder) service;
            aupod = binder.getService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            aupod = null;
        }
    };


    public AudioService getAudioService() {
        return aupod;
    }

	@Override
    public void onResume() {
        super.onResume();
        APEvents.getInstance().addPlaybackEventListener(this);
        APEvents.getInstance().addSongsListUpdateListener(this);
        AudioService.connect(this, this);
        applyAccentColor();
		restoreQueue();
    }

    private void applyAccentColor() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int accentColor = prefs.getInt(KEY_ACCENT_COLOR, R.color.white);
        getWindow().getDecorView().setBackgroundColor(accentColor);
    }

    public void refreshPlaylistsTab() {
        if (playlistTab != null) {
            playlistTab.refreshData();
        } else {
            Log.e("MainActivity", "PlaylistsTab is not initialized");
        }
    }

    public void playVideo(String videoPath) {
        if (videoPath != null && !videoPath.isEmpty()) {
            Uri videoUri = Uri.parse(videoPath);
            Intent intent = new Intent(Intent.ACTION_VIEW, videoUri);
            intent.setDataAndType(videoUri, "video/*");
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid video path", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_main_btn_showsettings:
                new MainActOptions(this).show();
                break;
            case R.id.activity_main_btn_search:
                searchPanel.show(songsList);
                break;
			case R.id.activity_main_btn_shuffle:

                if (EqualizerUtils.hasEqualizer(ctx)) {
					if (checkIsPlayer()) {
						aupod.openEqualizerPanel(this);
					}
				} else {
					Toast.makeText(this, getString(R.string.no_eq), Toast.LENGTH_SHORT).show();
				}
				//   openGitPage(v);
                break;	

            case R.id.activity_main_btn_all:
                //	if (!onboardingComplete) {
				startActivity(VideoFilePickerActivity.class);
				//finish();
				//return;
				//	}
				break; 
            case R.id.activity_main_btn_prev:
                if (aupod != null) {
                    aupod.playPrev();
                }
                break;
            case R.id.activity_main_btn_playpause:
                if (aupod != null) {
                    aupod.playPause();
                }
                break;
            case R.id.activity_main_btn_next:
                if (aupod != null) {
                    aupod.playNext();
                }
                break;
        }
    }

    public void showFullPlayer(View v) {
        startActivity(PlayerActivity.class);
    }


	public VideosTab getVideosTab() {
		if (songsTab == null) {
			Log.w("MainActivity", "VideoListTab is not initialized yet.");
		}
		//return vtab;
		return null;
	}
	public SongsListTab getSongsListTab() {
		if (songsTab == null) {
			Log.w("MainActivity", "SongsListTab is not initialized yet.");
		}
		return songsTab;
	}
	public ArtistTab getArtistsTab() {
		if (artistTab == null) {
			Log.w("MainActivity", "ArtistsTab is not initialized yet.");
		}
		return artistTab;
	}

	public AlbumsTab getAlbumsTab() {
		if (albumsTab == null) {
			Log.w("MainActivity", "AlbumsTab is not initialized yet.");
		}
		return albumsTab;
	}

	public SongsQueueTab getSongsQueueTab() {
		if (sqTab == null) {
			Log.w("MainActivity", "SongsQueueTab is not initialized yet.");
		}
		return sqTab;
	}
	public PlaylistsTab getPlayListTab() {
		if (playlistTab == null) {
			Log.w("MainActivity", "PlayListTab is not initialized yet.");
		}
		return playlistTab;
	}
    @Override
    public void onSongsListUpdated(List<SongItem> list) {
        artistTab.loadArtists();
        albumsTab.update(list);
        songsList = list;
    }

    @Override
    public void onPlaybackStart() {
        handler.postDelayed(new Runnable() {
                public void run() {
                    btnPlayPause.setBackgroundResource(R.drawable.ic_pause);
                }
            }, 10);
    }

    @Override
    public void onPlaybackPause() {
        handler.postDelayed(new Runnable() {
                public void run() {
                    btnPlayPause.setBackgroundResource(R.drawable.ic_play);
                }
            }, 10);
    }

    @Override
    public void onPlaybackStop() {
        handler.postDelayed(new Runnable() {
                public void run() {
                    btnPlayPause.setBackgroundResource(R.drawable.ic_play);
                }
            }, 10);
    }

    @Override
    public void onSongChanged(final SongItem si){
        currentSongTitle.setText(si.title);
        currentSongArtist.setText(si.artist);
        if(si.getThumbnail()!=null){
            currentImage.setBackgroundDrawable(new BitmapDrawable(si.getThumbnail()));
        }else{
            currentImage.setImageBitmap(BitmapUtils.tint(ctx.getResources(), R.drawable.cover_f, ThemeManager.getTheme().icon));
        }
        //
        //songsTab.setCurrent(si);
    }

    @Override
    public void onSearchResultItemClick(SongItem song) {
        if (aupod != null) {
            aupod.clearQueue();
			QueueManager.getInstance().clearQueue();
			aupod.playSong(song);
			QueueManager.getInstance().addSongToQueue(song);

        }
    }
// Add these imports at the top of your MainActivity.java
	// Add this method to initialize the chatbot UI
	private void initChatbot() {
		// Inflate the chatbot layout
		View chatbotView = LayoutInflater.from(this).inflate(R.layout.chatbot_layout, null);

		// Find views
		chatContainer = chatbotView.findViewById(R.id.chat_container);
		chatScrollView = chatbotView.findViewById(R.id.chat_scrollview);
		chatInput = chatbotView.findViewById(R.id.chat_input);

		// Set up send button
		ImageView sendButton = chatbotView.findViewById(R.id.chat_send);
		sendButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					sendMessage();
				}
			});

		// Set up toggle button
		ImageView toggleChat = findViewById(R.id.toggle_chat);
		toggleChat.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					toggleChatVisibility();
				}
			});

		// Add the chatbot view to your main layout
		ViewGroup rootView = findViewById(android.R.id.content);
		rootView.addView(chatbotView);

		// Load chat history
		loadChatHistory();

		// Add welcome message
		addBotMessage("Hi! I'm your music assistant. How can I help you today?");
	}

// Add this method to toggle chat visibility
	private void toggleChatVisibility() {
		if (isChatOpen) {
			chatContainer.setVisibility(View.GONE);
			// Hide keyboard
			InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(chatInput.getWindowToken(), 0);
		} else {
			chatContainer.setVisibility(View.VISIBLE);
			chatInput.requestFocus();
			// Show keyboard
			InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.showSoftInput(chatInput, InputMethodManager.SHOW_IMPLICIT);
		}
		isChatOpen = !isChatOpen;
	}

// Add this method to handle sending messages
	private void sendMessage() {
		String message = chatInput.getText().toString().trim();
		if (!TextUtils.isEmpty(message)) {
			addUserMessage(message);
			chatInput.setText("");
			processUserMessage(message);
		}
	}

// Add this method to add user messages to the chat
	private void addUserMessage(String message) {
		View messageView = LayoutInflater.from(this).inflate(R.layout.chat_message_user, null);
		TextView messageText = messageView.findViewById(R.id.message_text);
		messageText.setText(message);
		chatContainer.addView(messageView);
		chatHistory.add("User: " + message);
		scrollToBottom();
	}

// Add this method to add bot messages to the chat
	private void addBotMessage(String message) {
		View messageView = LayoutInflater.from(this).inflate(R.layout.chat_message_bot, null);
		TextView messageText = messageView.findViewById(R.id.message_text);
		messageText.setText(message);
		chatContainer.addView(messageView);
		chatHistory.add("Bot: " + message);
		scrollToBottom();
	}

// Add this method to scroll chat to bottom
	private void scrollToBottom() {
		chatScrollView.post(new Runnable() {
				@Override
				public void run() {
					chatScrollView.fullScroll(ScrollView.FOCUS_DOWN);
				}
			});
	}

// Add this method to process user messages
	private void processUserMessage(String message) {
		String lowerMessage = message.toLowerCase();

		// Playback controls
		if (lowerMessage.contains("play") || lowerMessage.contains("start")) {
			handlePlayCommand(lowerMessage);
		} 
		else if (lowerMessage.contains("pause") || lowerMessage.contains("stop")) {
			if (aupod != null) {
				aupod.pause();
				addBotMessage("Playback paused.");
			}
		}
		else if (lowerMessage.contains("next") || lowerMessage.contains("skip")) {
			if (aupod != null) {
				aupod.playNext();
				addBotMessage("Skipping to next song.");
			}
		}
		else if (lowerMessage.contains("previous") || lowerMessage.contains("back")) {
			if (aupod != null) {
				aupod.playPrev();
				addBotMessage("Going back to previous song.");
			}
		}
		// Theme changes
		else if (lowerMessage.contains("theme") || lowerMessage.contains("color")) {
			//handleThemeCommand(lowerMessage);
		}
		// Equalizer settings
		else if (lowerMessage.contains("equalizer") || lowerMessage.contains("sound")) {
			if (EqualizerUtils.hasEqualizer(ctx)) {
				if (checkIsPlayer()) {
					aupod.openEqualizerPanel(this);
					addBotMessage("Opening equalizer settings.");
				}
			} else {
				addBotMessage("No equalizer available on this device.");
			}
		}
		// Help command
		else if (lowerMessage.contains("help") || lowerMessage.contains("what can you do")) {
			showHelp();
		}
		else {
			addBotMessage("I'm not sure I understand. Try saying 'play music', 'change theme', or 'help' for more options.");
		}

		// Save chat history after each message
		saveChatHistory();
	}

// Add this method to handle play commands
	private void handlePlayCommand(String message) {
		if (aupod == null) {
			addBotMessage("Music player is not ready yet. Please try again shortly.");
			return;
		}

		if (message.contains("love") || message.contains("romantic")) {
			playLoveSong();
		} 
		else if (message.contains("random") || message.contains("shuffle")) {
			aupod.shuffleAll();
			addBotMessage("Playing random song.");
		}
		else {
			aupod.playPause();
			addBotMessage("Playback started.");
		}
	}

// Add this method to play a love song
	private void playLoveSong() {
		if (songsList == null || songsList.isEmpty()) {
			addBotMessage("No songs available to play.");
			return;
		}

		// Find songs with "love" in title or artist (simple implementation)
		List<SongItem> loveSongs = new ArrayList<>();
		for (SongItem song : songsList) {
			if (song.title.toLowerCase().contains("love") || 
				song.artist.toLowerCase().contains("love") ||
				song.album.toLowerCase().contains("love")) {
				loveSongs.add(song);
			}
		}

		if (!loveSongs.isEmpty()) {
			// Play a random love song
			int randomIndex = (int) (Math.random() * loveSongs.size());
			SongItem loveSong = loveSongs.get(randomIndex);
			aupod.playSong(loveSong);
			addBotMessage("Playing a love song: " + loveSong.title + " by " + loveSong.artist);
		} else {
			addBotMessage("I couldn't find any love songs. Playing a random song instead.");
			aupod.shuffleAll();
		}
	}

// Add this method to handle theme commands
	/*private void handleThemeCommand(String message) {
		SharedPreferences prefs = getSharedPreferences(CHATBOT_PREFS, MODE_PRIVATE);
		SharedPreferences.Editor editor = prefs.edit();

		if (message.contains("dark") || message.contains("black") || message.contains("night")) {
			ThemeManager.setTheme(ThemeManager.Theme.DARK);
			editor.putString(KEY_THEME_PREFERENCE, "dark");
			addBotMessage("Changed to dark theme.");
		}
		else if (message.contains("light") || message.contains("white") || message.contains("day")) {
			ThemeManager.setTheme(ThemeManager.Theme.LIGHT);
			editor.putString(KEY_THEME_PREFERENCE, "light");
			addBotMessage("Changed to light theme.");
		}
		else if (message.contains("blue")) {
			ThemeManager.setTheme(ThemeManager.Theme.BLUE);
			editor.putString(KEY_THEME_PREFERENCE, "blue");
			addBotMessage("Changed to blue theme.");
		}
		else {
			addBotMessage("Available themes: dark, light, blue. Try saying 'change to dark theme'.");
			return;
		}

		editor.apply();
		applyAccentColor();
		recreate(); // Refresh activity to apply theme
	}
*/
// Add this method to show help
	private void showHelp() {
		String helpText = "I can help you with:\n" +
			"- Play music (try 'play a love song')\n" +
			"- Control playback (pause, next, previous)\n" +
			"- Change themes (dark, light, blue)\n" +
			"- Adjust sound (equalizer)\n" +
			"- And more! Just ask.";

		addBotMessage(helpText);
	}

// Add these methods to handle chat history persistence
	private void saveChatHistory() {
		SharedPreferences prefs = getSharedPreferences(CHATBOT_PREFS, MODE_PRIVATE);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString(KEY_CHAT_HISTORY, TextUtils.join("\n", chatHistory));
		editor.apply();
	}

	private void loadChatHistory() {
		SharedPreferences prefs = getSharedPreferences(CHATBOT_PREFS, MODE_PRIVATE);
		String history = prefs.getString(KEY_CHAT_HISTORY, "");
		if (!TextUtils.isEmpty(history)) {
			String[] messages = history.split("\n");
			chatHistory.clear();
			Collections.addAll(chatHistory, messages);

			// Recreate chat UI from history
			for (String message : chatHistory) {
				if (message.startsWith("User: ")) {
					addUserMessage(message.substring(6));
				} else if (message.startsWith("Bot: ")) {
					addBotMessage(message.substring(5));
				}
			}
		}
	}


}


