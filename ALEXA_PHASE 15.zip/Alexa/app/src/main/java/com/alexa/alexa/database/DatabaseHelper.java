package com.alexa.alexa.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database constants
    private static final String DATABASE_NAME = "musicLibrary.db";
    private static final int DATABASE_VERSION = 1;

    // Table and column names
    private static final String TABLE_SONGS = "songs";
    private static final String COLUMN_PATH = "path";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_ARTIST = "artist";
    private static final String COLUMN_ALBUM = "album";
    private static final String COLUMN_GENRE = "genre";
    private static final String COLUMN_YEAR = "year";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the songs table
        String createTable = "CREATE TABLE " + TABLE_SONGS + " (" +
			COLUMN_PATH + " TEXT PRIMARY KEY, " +
			COLUMN_TITLE + " TEXT, " +
			COLUMN_ARTIST + " TEXT, " +
			COLUMN_ALBUM + " TEXT, " +
			COLUMN_GENRE + " TEXT, " +
			COLUMN_YEAR + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the existing table and recreate it
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SONGS);
        onCreate(db);
    }

    // Method to update song metadata
    public boolean updateSongMetadata(String path, String title, String artist, String album, String genre, String year) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_ARTIST, artist);
        values.put(COLUMN_ALBUM, album);
        values.put(COLUMN_GENRE, genre);
        values.put(COLUMN_YEAR, year);

        // Update the row in the table where the path matches
        int rowsAffected = db.update(TABLE_SONGS, values, COLUMN_PATH + " = ?", new String[]{path});

        db.close();

        // Return true if the update was successful
        return rowsAffected > 0;
    }

    // Optional method to add new songs (in case needed)
    public long insertSong(String path, String title, String artist, String album, String genre, String year) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PATH, path);
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_ARTIST, artist);
        values.put(COLUMN_ALBUM, album);
        values.put(COLUMN_GENRE, genre);
        values.put(COLUMN_YEAR, year);

        long result = db.insert(TABLE_SONGS, null, values);
        db.close();

        return result;
    }
}
