package com.alexa.alexa.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.alexa.alexa.service.AudioService;

public class SPrefs {
    public Context ctx;
    SharedPreferences pref;
    SharedPreferences.Editor edit;

    // Keys
    private enum K {
        LAST_PLAYING_SONG_PATH,
        LAST_PLAYING_SONG_TIME_POSITION,
        APP_THEME,
        BG_COLOR,
        TEXT_COLOR_P,
        TEXT_COLOR_S,
        REPEAT_MODE,
        SHUFFLE_STATE,
        RESTART_SONG_ON_PREV
        }

    public SPrefs(Context ctx) {
        this.ctx = ctx;
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        edit = pref.edit();
    }

    // Remember the last song to play
    public String getLastPath() {
        return getString(K.LAST_PLAYING_SONG_PATH, "");
    }

    public void saveLastPath(String path) {
        saveString(K.LAST_PLAYING_SONG_PATH, path);
    }

    // Remember track position of the last song
    public void setLastPosition(int pos) {
        saveInt(K.LAST_PLAYING_SONG_TIME_POSITION, pos);
    }

    public int getLastPosition() {
        return getInt(K.LAST_PLAYING_SONG_TIME_POSITION, 0);
    }

    // Background color
    public int getBackgroundColor() {
        return getInt(K.BG_COLOR, 0xFFFFFF); // Default to white
    }

    public void setBackgroundColor(int color) {
        saveInt(K.BG_COLOR, color);
    }

    // Primary text color
    public int getPrimaryTextColor() {
        return getInt(K.TEXT_COLOR_P, 0x000000); // Default to black
    }

    public void setPrimaryTextColor(int color) {
        saveInt(K.TEXT_COLOR_P, color);
    }

    // Secondary text color
    public int getSecondaryTextColor() {
        return getInt(K.TEXT_COLOR_S, 0x777777); // Default to gray
    }

    public void setSecondaryTextColor(int color) {
        saveInt(K.TEXT_COLOR_S, color);
    }

    // Repeat mode
    public AudioService.RepeatMode getRepeatMode() {
        int modeOrdinal = getInt(K.REPEAT_MODE, AudioService.RepeatMode.NONE.ordinal());
        return AudioService.RepeatMode.values()[modeOrdinal];
    }

    public void saveRepeatMode(AudioService.RepeatMode mode) {
        saveInt(K.REPEAT_MODE, mode.ordinal());
    }

    // Shuffle state
    public boolean isShuffleEnabled() {
        return getBool(K.SHUFFLE_STATE, false);
    }

    public void saveShuffleEnabled(boolean enabled) {
        saveBool(K.SHUFFLE_STATE, enabled);
    }

    // Restart song on previous button
    public boolean getRestartSongOnPrev() {
        return getBool(K.RESTART_SONG_ON_PREV, true);
    }

    public void setRestartSongOnPrev(boolean restart) {
        saveBool(K.RESTART_SONG_ON_PREV, restart);
    }

    // ||||| Helper methods ||||| \\

    // Enum K to String
    private String k2s(K key) {
        return key.toString();
    }

    // String
    private String getString(K key, String deft) {
        return pref.getString(k2s(key), deft);
    }

    private void saveString(K key, String value) {
        edit.putString(k2s(key), value).commit();
    }

    // Integer
    private int getInt(K key, int deft) {
        return pref.getInt(k2s(key), deft);
    }

    private void saveInt(K key, int value) {
        edit.putInt(k2s(key), value).commit();
    }

    // Boolean
    private boolean getBool(K key, boolean deft) {
        return pref.getBoolean(k2s(key), deft);
    }

    private void saveBool(K key, boolean value) {
        edit.putBoolean(k2s(key), value).commit();
    }
    
    public void saveLastSeekPosition(String songPath, int position) {
        SharedPreferences.Editor editor = pref.edit();
        editor.putInt("SEEK_" + songPath, position);
        editor.apply();
    }

    public int getLastSeekPosition(String songPath) {
        return pref.getInt("SEEK_" + songPath, 0);
    }
    
}
