package com.alexa.alexa.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.SearchPanel;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activityAdapters.AlbumsActivitySongsAdapter;
import com.alexa.alexa.menu.CurrentSongOptions;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.utils.FastBlur;
import com.alexa.alexa.view.TintedImageView;
import java.util.ArrayList;
import java.util.List;
import android.app.Activity;

public class AlbumDetailsActivity extends BaseActivity 
{

    private int color;

    
    private ArrayList<SongItem> songQueue = new ArrayList<>();
    private TextView currentTitle, currentArtist;
    private TextView trackTimeCurrent, trackTimeDuration;
    private LinearLayout art2Background;
    private ImageView currentArt;
    private AudioService audioService;
    private TintedImageView playpauseIcon;
    
    private Handler handle;
    ListView songListView;
    TextView albumTitleView;
    AlbumsActivitySongsAdapter songAdapter;
    List<SongItem> songList;
    String albumName;
    private TextView songCountTextView;
    private TextView albumCountTextView;
    private TextView artistCountTextView; // Add TextView for artist count
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_details);
    
        init();
    }

    private void playSong(SongItem song) {
        AudioService audioService = App.get().getAudioService();
        if (audioService != null) {
           // audioService.playSong(song);
        } else {
            Toast.makeText(this, "Audio Service not connected", Toast.LENGTH_SHORT).show();
        }
    }

    private void init() {
        handle = new Handler();

        // Initialize views
        currentTitle = findViewById(R.id.auplayer_tv_title);
        currentArtist = findViewById(R.id.auplayer_tv_artist);
        art2Background = findViewById(R.id.aupalyer_iv_art2_background);
        currentArt = findViewById(R.id.auplayer_iv_art);
        playpauseIcon = findViewById(R.id.auplayer_btn_playpause);

        // Initialize album details views
        albumTitleView = findViewById(R.id.album_title);
        songCountTextView = findViewById(R.id.song_count);
        albumCountTextView = findViewById(R.id.album_count);
        artistCountTextView = findViewById(R.id.artist_count); // Initialize artist count TextView
        songListView = findViewById(R.id.list_view_list1);

        // Get album details from the intent
        albumName = getIntent().getStringExtra("albumName");
        int songCount = getIntent().getIntExtra("song_count", 0);
        int albumCount = getIntent().getIntExtra("album_count", 0);
        int artistCount = getIntent().getIntExtra("artist_count", 0); // Get artist count from intent

        // Set album title, song count, album count, and artist count in TextViews
        albumTitleView.setText(albumName);
        songCountTextView.setText("Songs: " + songCount);
        albumCountTextView.setText("Albums: " + albumCount);
        artistCountTextView.setText("Artists: " + artistCount); // Set artist count

        // Get the song list from the intent and set the adapter
        songList = getIntent().getParcelableArrayListExtra("songList");
        songAdapter = new AlbumsActivitySongsAdapter(this, songList);
        songListView.setAdapter(songAdapter);
       
    
        songListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    SongItem selectedSong = songList.get(position);
                //    playSong(selectedSong);
				AudioService.getInstance().playSong(selectedSong);
					
                }
            });
        



        

        trackTimeCurrent = findView(R.id.auplayer_currentpos);
        trackTimeDuration = findView(R.id.auplayer_duration);

        //
        setClickable(R.id.auplayer_btn_playpause);
        setClickable(R.id.auplayer_btn_prev);
        setClickable(R.id.auplayer_btn_next);
        setClickable(R.id.auplayer_btn_options);
        setClickable(R.id.auplayer_btn_back);
    } 


    

	

    


	

    @Override
    public void onClick(View v){
        int id = v.getId();
        switch(id){
            case R.id.auplayer_btn_playpause:
                if(audioService != null){
                    audioService.playPause();
                }
                break;
            case R.id.auplayer_btn_next:
                if(audioService != null){
                    audioService.playNext();
                }
                break;
            case R.id.auplayer_btn_prev:
                if(audioService != null){
                    audioService.playPrev();
                }
                break;
            case R.id.auplayer_btn_back:
                finish();
                break;
           // case R.id.auplayer_btn_menu_songs:
                // Get the current song queue from the audio service
              //  startActivity(CurrentQueue.class);
             //   break;
            case R.id.auplayer_btn_options:
               // new CurrentSongOptions(this, audioService.getCurrentSong()).show();
                break;
        }
    }




    

    


    

    public void launchCurrentQueueActivity() {
        Intent intent = new Intent(this, PlaylistDetailsActivity.class);
        intent.putParcelableArrayListExtra("songQueue", songQueue);
        startActivity(intent);
    } 
    
	

}
