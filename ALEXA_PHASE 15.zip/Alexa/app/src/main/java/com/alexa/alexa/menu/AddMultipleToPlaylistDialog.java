package com.alexa.alexa.menu;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.PlaylistAdapter;
import com.alexa.alexa.manager.PlaylistManager;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;

import java.util.List;

public class AddMultipleToPlaylistDialog {

    private final Context context;
    private final PlaylistManager playlistManager;
    private final List<SongItem> songs;
    private AlertDialog dialog;

    public AddMultipleToPlaylistDialog(Context context, List<SongItem> songs) {
        this.context = context;
        this.playlistManager = PlaylistManager.getInstance();
        this.songs = songs;
    }

    public void show() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Add to Playlist");

        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dialog_add_to_playlist, null);
        builder.setView(view);

        final RecyclerView playlistsRecyclerView = view.findViewById(R.id.recycler_view_playlists);
        Button cancelButton = view.findViewById(R.id.button_cancel_add_to_playlist);
        Button createNewPlaylistButton = view.findViewById(R.id.button_create_new_playlist);

        playlistsRecyclerView.setLayoutManager(new LinearLayoutManager(context));
        List<Playlist> playlists = playlistManager.getPlaylists();

        PlaylistAdapter adapter = new PlaylistAdapter((MainActivity) context, playlists, new PlaylistAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(Playlist playlist) {
                    handleAddToPlaylist(playlist);
                }
            });

        playlistsRecyclerView.setAdapter(adapter);

        dialog = builder.create();

        cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

        createNewPlaylistButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showCreateNewPlaylistDialog();
                }
            });

        dialog.show();
    }

    private void handleAddToPlaylist(Playlist playlist) {
        int count = 0;
        for (SongItem song : songs) {
            if (playlistManager.addSongToPlaylist(playlist.getName(), song)) {
                count++;
            }
        }

        Toast.makeText(context, "Added " + count + " song(s) to '" + playlist.getName() + "'.", Toast.LENGTH_SHORT).show();
        if (context instanceof MainActivity) {
            ((MainActivity) context).refreshPlaylistsTab();
        }

        dialog.dismiss();
    }

    private void showCreateNewPlaylistDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Create New Playlist");

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_create_playlist, null);
        builder.setView(view);

        final EditText playlistNameInput = view.findViewById(R.id.edittext_playlist_name);
        Button createButton = view.findViewById(R.id.button_create_playlist);
        Button cancelButton = view.findViewById(R.id.button_cancel_create_playlist);

        final AlertDialog createDialog = builder.create();

        createButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String name = playlistNameInput.getText().toString().trim();
                    if (!name.isEmpty()) {
                        Playlist newPlaylist = playlistManager.createPlaylist(name);
                        if (newPlaylist != null) {
                            handleAddToPlaylist(newPlaylist);
                        } else {
                            Toast.makeText(context, "Failed to create playlist.", Toast.LENGTH_SHORT).show();
                        }
                        createDialog.dismiss();
                    } else {
                        Toast.makeText(context, "Playlist name cannot be empty.", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    createDialog.dismiss();
                }
            });

        createDialog.show();
    }
}
