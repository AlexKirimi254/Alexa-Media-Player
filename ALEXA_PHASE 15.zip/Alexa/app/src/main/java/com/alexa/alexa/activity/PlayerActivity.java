/*package com.alexa.alexa.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.SearchPanel;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.adapters.SongsQueueAdapter;
import com.alexa.alexa.manager.CrossfadeManager;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.menu.CurrentSongOptions;
import com.alexa.alexa.models.CrossfadeConfig;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.utils.FastBlur;
import com.alexa.alexa.view.TintedImageView;
import com.alexa.alexa.utils.EqualizerUtils;
import java.util.List;
import java.util.Locale;
import com.alexa.alexa.Constants;

public class PlayerActivity extends BaseActivity implements
AudioService.ConnectionListener,
APEvents.PlaybackStateListener,
APEvents.SongListUpdateListener,
SearchPanel.OnSearchResultItemClickListener,
QueueManager.QueueListener,
View.OnClickListener,
CompoundButton.OnCheckedChangeListener {

    private static final int NORMAL_INTERVAL = 1000;
    private static final int AB_REPEAT_INTERVAL = 100;
    private static final String PREFS_NAME = "player_prefs";
    private static final String PREF_REPEAT_MODE = "repeat_mode";

    private SongsQueueAdapter queueAdapter;
    private TextView currentTitle;
    private TextView currentArtist;
    private TextView trackTimeCurrent;
    private TextView trackTimeDuration;
    private TextView crossFadeStatus;
    private LinearLayout art2Background;
    private LinearLayout crossFadeSettingsPanel;
    private ImageView currentArt;
    private ImageView btnFwd;
    private ImageView btnBwd;
    private TintedImageView playPauseIcon;
    private SeekBar seeker;
    private SeekBar crossFadeDurationSeek;
    private TextView crossFadeDurationText;
    private ToggleButton crossFadeToggle;
    private Button crossFadePreviewButton;
    private AudioService audioService;
    private Handler mainHandler;
    private Runnable seekerTick;
    private boolean seekTouch;
    private SongItem currentSong;
    private int repeatStart = -1;
    private int repeatEnd = -1;
    private boolean isABRepeatEnabled = false;
    private ToggleButton toggleABRepeat;
    private BroadcastReceiver crossFadeReceiver;
    private CrossfadeConfig crossfadeConfig;
    private CrossfadeManager crossfadeManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auplayer);
        crossfadeConfig = new CrossfadeConfig(this);
        crossfadeManager = new CrossfadeManager(this, crossfadeConfig);
        init();
        initCrossFadeSettings();
        loadSettings();
        registerCrossFadeReceiver();
    }

    private void init() {
        mainHandler = new Handler();

        currentTitle = findViewById(R.id.auplayer_tv_title);
        currentArtist = findViewById(R.id.auplayer_tv_artist);
        art2Background = findViewById(R.id.aupalyer_iv_art2_background);
        currentArt = findViewById(R.id.auplayer_iv_art);
        playPauseIcon = findViewById(R.id.auplayer_btn_playpause);
        trackTimeCurrent = findViewById(R.id.auplayer_currentpos);
        trackTimeDuration = findViewById(R.id.auplayer_duration);
        btnFwd = findViewById(R.id.btn_skip_forward);
        btnBwd = findViewById(R.id.btn_skip_backward);
        crossFadeStatus = findViewById(R.id.crossfade_status);
        Button btnSetA = findViewById(R.id.btn_set_a);
        Button btnSetB = findViewById(R.id.btn_set_b);
        toggleABRepeat = findViewById(R.id.toggle_ab_repeat);

        seeker = findViewById(R.id.aupalyer_seeker);
        seeker.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					if (fromUser && audioService != null && seekTouch) {
						int targetProgress = progress;
						if (isABRepeatEnabled && repeatStart != -1 && repeatEnd != -1) {
							targetProgress = Math.max(repeatStart, Math.min(progress, repeatEnd));
							seekBar.setProgress(targetProgress);
						}
						audioService.seekTo(targetProgress);
						trackTimeCurrent.setText(formatTime(targetProgress));
					}
				}

				public void onStartTrackingTouch(SeekBar seekBar) {
					stopSeeker();
					seekTouch = true;
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
					seekTouch = false;
					if (audioService != null && audioService.isPlaying()) {
						startSeeker();
					}
				}
			});

        seekerTick = new Runnable() {
            public void run() {
                if (audioService != null) {
                    int pos = audioService.getCurrentPosition();
                    seeker.setProgress(pos);
                    trackTimeCurrent.setText(formatTime(pos));
                    int interval = isABRepeatEnabled ? AB_REPEAT_INTERVAL : NORMAL_INTERVAL;
                    mainHandler.postDelayed(this, interval);
                }
            }
        };

        setClickable(R.id.auplayer_btn_playpause);
        setClickable(R.id.auplayer_btn_prev);
        setClickable(R.id.auplayer_btn_next);
        setClickable(R.id.auplayer_btn_repeat);
        setClickable(R.id.auplayer_btn_options);
        setClickable(R.id.auplayer_btn_back);
        setClickable(R.id.auplayer_btn_shuffle);
        setClickable(R.id.btn_set_a);
        setClickable(R.id.btn_set_b);
        setClickable(R.id.crossfade_settings_button);
        setClickable(R.id.crossfade_preview_button);

        btnSetA.setOnClickListener(this);
        btnSetB.setOnClickListener(this);
        toggleABRepeat.setOnCheckedChangeListener(this);
    }

    private void initCrossFadeSettings() {
        crossFadeSettingsPanel = findViewById(R.id.crossfade_settings_panel);
        crossFadeToggle = findViewById(R.id.crossfade_toggle);
        crossFadeDurationSeek = findViewById(R.id.crossfade_duration_seek);
        crossFadeDurationText = findViewById(R.id.crossfade_duration_text);
        crossFadePreviewButton = findViewById(R.id.crossfade_preview_button);

        crossFadeToggle.setChecked(crossfadeConfig.isEnabled());
        crossFadeDurationSeek.setMax(crossfadeConfig.getMaxDuration() - crossfadeConfig.getMinDuration());
        crossFadeDurationSeek.setProgress(crossfadeConfig.getDuration() - crossfadeConfig.getMinDuration());
        crossFadeDurationText.setText(formatSeconds(crossfadeConfig.getDuration() / 1000));

        crossFadeToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					crossfadeConfig.setEnabled(isChecked);
					crossfadeConfig.saveConfig(PlayerActivity.this);
					updateCrossFadeStatus();
					crossFadeDurationSeek.setEnabled(isChecked);
					crossFadePreviewButton.setEnabled(isChecked);
				}
			});

        crossFadeDurationSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					int duration = progress + crossfadeConfig.getMinDuration();
					crossfadeConfig.setDuration(duration);
					crossFadeDurationText.setText(formatSeconds(duration / 1000));
					updateCrossFadeStatus();
					if (fromUser) {
						crossfadeConfig.saveConfig(PlayerActivity.this);
						if (audioService != null) {
							audioService.setCrossfadeDuration(duration);
						}
					}
				}

				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			});

        crossFadePreviewButton.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					if (audioService != null && crossfadeConfig.isEnabled()) {
						SongItem nextSong = audioService.getNextSong();
						if (nextSong != null) {
							crossfadeManager.previewCrossfade(audioService.getMediaPlayer(), nextSong);
							Toast.makeText(PlayerActivity.this, "Previewing crossfade", Toast.LENGTH_SHORT).show();
						} else {
							Toast.makeText(PlayerActivity.this, "No next song available", Toast.LENGTH_SHORT).show();
						}
					}
				}
			});

        crossFadeDurationSeek.setEnabled(crossfadeConfig.isEnabled());
        crossFadePreviewButton.setEnabled(crossfadeConfig.isEnabled());
        updateCrossFadeStatus();
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        if (audioService != null) {
            editor.putString(PREF_REPEAT_MODE, audioService.getRepeatMode().name());
        }
        editor.apply();
    }

    private void loadSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String repeatModeName = prefs.getString(PREF_REPEAT_MODE, AudioService.RepeatMode.NONE.name());
        try {
            AudioService.RepeatMode repeatMode = AudioService.RepeatMode.valueOf(repeatModeName);
            if (audioService != null) {
                audioService.setRepeatMode(repeatMode);
            }
        } catch (IllegalArgumentException e) {
            if (audioService != null) {
                audioService.setRepeatMode(AudioService.RepeatMode.NONE);
            }
        }
        updateCrossFadeStatus();
    }

    private void updateCrossFadeStatus() {
        String status = crossfadeConfig.isEnabled() ? "Crossfade (" + (crossfadeConfig.getDuration() / 1000) + "s)" : "Crossfade Off";
        crossFadeStatus.setText(status);
    }

    private void registerCrossFadeReceiver() {
        crossFadeReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (Constants.ACTION_CROSSFADE_STARTED.equals(action)) {
                    crossFadeStatus.setText("Crossfading...");
                } else if (Constants.ACTION_CROSSFADE_COMPLETED.equals(action)) {
                    updateCrossFadeStatus();
                }
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(Constants.ACTION_CROSSFADE_STARTED);
        filter.addAction(Constants.ACTION_CROSSFADE_COMPLETED);
        LocalBroadcastManager.getInstance(this).registerReceiver(crossFadeReceiver, filter);
    }

    private String formatSeconds(int seconds) {
        return String.format(Locale.getDefault(), "%ds", seconds);
    }

    private String formatTime(int time) {
        int hrs = time / (1000 * 60 * 60);
        int min = (time / (1000 * 60)) % 60;
        int sec = (time / 1000) % 60;
        return hrs > 0 ? String.format(Locale.getDefault(), "%02d:%02d:%02d", hrs, min, sec)
			: String.format(Locale.getDefault(), "%02d:%02d", min, sec);
    }

    private void updateInfo() {
        SongItem si = audioService != null ? audioService.getCurrentSong() : null;
        if (si == null) {
            return;
        }

        currentTitle.setText(si.title != null ? si.title : "");
        currentArtist.setText(si.artist != null ? si.artist : "");

        if (si.getThumbnail() != null) {
            currentArt.setImageBitmap(si.getThumbnail());
            setLargeArt(si.getThumbnail());
        } else {
            App.runInBackground(new Runnable() {
					public void run() {
						final Bitmap bmp = BitmapUtils.tint(getResources(), R.drawable.ic_menu_songs, ThemeManager.getTheme().icon);
						if (bmp != null) {
							mainHandler.post(new Runnable() {
									public void run() {
										currentArt.setImageBitmap(bmp);
									}
								});
						}
					}
				});
        }

        playPauseIcon.setBackgroundResource(audioService != null && audioService.isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);
        playPauseIcon.reset();

        int pos = audioService != null ? audioService.getCurrentPosition() : 0;
        int duration = audioService != null ? audioService.getDuration() : 0;
        trackTimeDuration.setText(formatTime(duration));
        trackTimeCurrent.setText(formatTime(pos));

        seeker.setMax(duration);
        seeker.setProgress(pos);
    }

    private void setLargeArt(final Bitmap bitmap) {
        App.runInBackground(new Runnable() {
				public void run() {
					final Bitmap blurred = FastBlur.fastblur(bitmap, 0.2f, 3);
					if (blurred != null) {
						App.runInUiThread(new Runnable() {
								public void run() {
									art2Background.setBackground(new BitmapDrawable(getResources(), blurred));
								}
							});
					}
				}
			});
    }

    private void startSeeker() {
        stopSeeker();
        mainHandler.post(seekerTick);
    }

    private void stopSeeker() {
        mainHandler.removeCallbacks(seekerTick);
    }

    private void skipForward() {
        if (audioService != null) {
            int currentPos = audioService.getCurrentPosition();
            int newPos = currentPos + 30000;
            int duration = audioService.getDuration();
            if (isABRepeatEnabled && repeatEnd != -1 && newPos > repeatEnd) {
                newPos = repeatEnd;
            }
            if (newPos > duration) {
                newPos = duration;
            }
            audioService.seekTo(newPos);
            trackTimeCurrent.setText(formatTime(newPos));
        }
    }

    private void skipBackward() {
        if (audioService != null) {
            int currentPos = audioService.getCurrentPosition();
            int newPos = currentPos - 30000;
            if (isABRepeatEnabled && repeatStart != -1 && newPos < repeatStart) {
                newPos = repeatStart;
            }
            if (newPos < 0) {
                newPos = 0;
            }
            audioService.seekTo(newPos);
            trackTimeCurrent.setText(formatTime(newPos));
        }
    }

    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.auplayer_btn_playpause:
                if (audioService != null) {
                    if (!audioService.isPlaying() && isABRepeatEnabled && repeatStart != -1 && repeatEnd != -1) {
                        int currentPos = audioService.getCurrentPosition();
                        if (currentPos < repeatStart || currentPos > repeatEnd) {
                            audioService.seekTo(repeatStart);
                        }
                    }
                    audioService.playPause();
                }
                break;
            case R.id.auplayer_btn_next:
                if (audioService != null) {
                    audioService.playNext();
                }
                break;
            case R.id.auplayer_btn_prev:
                if (audioService != null) {
                    audioService.playPrev();
                }
                break;
            case R.id.btn_skip_forward:
                skipForward();
                break;
            case R.id.btn_skip_backward:
                skipBackward();
                break;
            case R.id.auplayer_btn_back:
                finish();
                break;
            case R.id.auplayer_btn_shuffle:
                if (audioService != null) {
                    audioService.shuffleQueue();
                }
                break;
            case R.id.auplayer_btn_repeat:
                if (audioService != null) {
                    audioService.toggleRepeat();
                    saveSettings();
                    updateRepeatButtonUI();
                }
                break;
            case R.id.auplayer_btn_options:
                if (audioService != null && audioService.getCurrentSong() != null) {
                    new CurrentSongOptions(this, audioService.getCurrentSong()).show();
                }
                break;
            case R.id.crossfade_settings_button:
                boolean visible = crossFadeSettingsPanel.getVisibility() == View.VISIBLE;
                crossFadeSettingsPanel.setVisibility(visible ? View.GONE : View.VISIBLE);
                break;
            case R.id.btn_set_a:
                if (audioService != null) {
                    audioService.setRepeatPointA();
                    repeatStart = audioService.getCurrentPosition();
                    Toast.makeText(this, "A set to " + formatTime(repeatStart), Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.btn_set_b:
                if (audioService != null && repeatStart != -1) {
                    audioService.setRepeatPointB();
                    repeatEnd = audioService.getCurrentPosition();
                    if (repeatEnd <= repeatStart) {
                        Toast.makeText(this, "Point B must be after A", Toast.LENGTH_SHORT).show();
                        repeatEnd = -1;
                        audioService.clearABRepeat();
                    } else {
                        Toast.makeText(this, "B set to " + formatTime(repeatEnd), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Please set A first", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (buttonView.getId() == R.id.toggle_ab_repeat) {
            isABRepeatEnabled = isChecked;
            if (isChecked) {
                if (repeatStart == -1 || repeatEnd == -1 || repeatEnd <= repeatStart) {
                    Toast.makeText(this, "Please set valid A and B points", Toast.LENGTH_SHORT).show();
                    toggleABRepeat.setChecked(false);
                    isABRepeatEnabled = false;
                    if (audioService != null) {
                        audioService.clearABRepeat();
                    }
                    return;
                }
                if (audioService != null) {
                    int currentPos = audioService.getCurrentPosition();
                    if (currentPos < repeatStart || currentPos > repeatEnd) {
                        audioService.seekTo(repeatStart);
                    }
                }
            } else if (audioService != null) {
                audioService.clearABRepeat();
            }
            if (audioService != null && audioService.isPlaying()) {
                stopSeeker();
                startSeeker();
            }
            Toast.makeText(this, "A-B Repeat " + (isChecked ? "Enabled (" + formatTime(repeatStart) +
						   " - " + formatTime(repeatEnd) + ")" : "Disabled"), Toast.LENGTH_SHORT).show();
        }
    }

    private void updateRepeatButtonUI() {
        LinearLayout repeatLayout = findViewById(R.id.auplayer_btn_repeat);
        TintedImageView repeatImageView = repeatLayout.findViewById(R.id.au6);
        if (repeatImageView != null && audioService != null) {
            AudioService.RepeatMode currentRepeatMode = audioService.getRepeatMode();
            switch (currentRepeatMode) {
                case REPEAT_ALL:
                    repeatImageView.setImageResource(R.drawable.repeat_all);
                    repeatImageView.setTint(Color.GREEN);
                    break;
                case REPEAT_ONE:
                    repeatImageView.setImageResource(R.drawable.repeat_one);
                    repeatImageView.setTint(Color.YELLOW);
                    break;
                default:
                    repeatImageView.setImageResource(R.drawable.no_repeat);
                    repeatImageView.setTint(Color.RED);
                    break;
            }
        }
    }

    public void openEqualizerPanel(Activity activity) {
        if (EqualizerUtils.hasEqualizer(activity)) {
            EqualizerUtils.openEqualizer(activity, audioService.getMediaPlayer());
        } else {
            Toast.makeText(activity, "No equalizer available", Toast.LENGTH_SHORT).show();
        }
    }

    public void onAudioServiceConnect(AudioService service) {
        audioService = service;
        loadSettings();
        updateInfo();
        audioService.requestPlaystateUpdate();
        updateRepeatButtonUI();
    }

    public void onPlaybackStart() {
        playPauseIcon.setBackgroundResource(R.drawable.ic_pause);
        playPauseIcon.reset();
        startSeeker();
    }

    public void onPlaybackPause() {
        playPauseIcon.setBackgroundResource(R.drawable.ic_play);
        playPauseIcon.reset();
        stopSeeker();
    }

    public void onPlaybackStop() {
        updateInfo();
        playPauseIcon.setBackgroundResource(R.drawable.ic_play);
        playPauseIcon.reset();
        stopSeeker();
    }

    public void onSongChanged(SongItem newSong) {
        currentSong = newSong;
        updateInfo();
        if (queueAdapter != null) {
            queueAdapter.setCurrent(newSong);
        }
        repeatStart = -1;
        repeatEnd = -1;
        isABRepeatEnabled = false;
        toggleABRepeat.setChecked(false);
        if (audioService != null) {
            audioService.clearABRepeat();
        }
    }

    public void onSearchResultItemClick(SongItem song) {
        if (audioService != null) {
            audioService.playSong(song);
        }
    }

    public void onSongsListUpdated(List<SongItem> songs) {
        if (queueAdapter != null) {
            queueAdapter.notifyDataSetChanged();
        }
    }

    public void onQueueUpdated(List<SongItem> updatedQueue) {
        if (queueAdapter != null) {
            queueAdapter.update(updatedQueue);
        }
    }

    protected void onPause() {
        stopSeeker();
        APEvents.getInstance().removePlaybackEventListener(this);
        QueueManager.getInstance().removeQueueListener(this);
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        APEvents.getInstance().addPlaybackEventListener(this);
        AudioService.connect(this, this);
        QueueManager.getInstance().addQueueListener(this);
        if (audioService != null && audioService.isPlaying()) {
            startSeeker();
        }
    }

    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(crossFadeReceiver);
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
*/package com.alexa.alexa.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.SearchPanel;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.adapters.SongsQueueAdapter;
import com.alexa.alexa.manager.CrossfadeManager;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.menu.CurrentSongOptions;
import com.alexa.alexa.models.CrossfadeConfig;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.utils.FastBlur;
import com.alexa.alexa.view.TintedImageView;
import com.alexa.alexa.utils.EqualizerUtils;
import java.util.List;
import java.util.Locale;
import com.alexa.alexa.Constants;

public class PlayerActivity extends BaseActivity implements
AudioService.ConnectionListener,
APEvents.PlaybackStateListener,
APEvents.SongListUpdateListener,
SearchPanel.OnSearchResultItemClickListener,
QueueManager.QueueListener,
View.OnClickListener,
CompoundButton.OnCheckedChangeListener {

    private static final int NORMAL_INTERVAL = 1000;
    private static final int AB_REPEAT_INTERVAL = 100;
    private static final String PREFS_NAME = "player_prefs";
    private static final String PREF_REPEAT_MODE = "repeat_mode";

    private SongsQueueAdapter queueAdapter;
    private TextView currentTitle;
    private TextView currentArtist;
    private TextView trackTimeCurrent;
    private TextView trackTimeDuration;
    private TextView crossFadeStatus;
    private LinearLayout art2Background;
    private LinearLayout crossFadeSettingsPanel;
    private ImageView currentArt;
    private ImageView btnFwd;
    private ImageView btnBwd;
    private TintedImageView playPauseIcon;
    private SeekBar seeker;
    private SeekBar crossFadeDurationSeek;
    private TextView crossFadeDurationText;
    private ToggleButton crossFadeToggle;
    private Button crossFadePreviewButton;
    private AudioService audioService;
    private Handler mainHandler;
    private Runnable seekerTick;
    private boolean seekTouch;
    private SongItem currentSong;
    private int repeatStart = -1;
    private int repeatEnd = -1;
    private boolean isABRepeatEnabled = false;
    private ToggleButton toggleABRepeat;
    private BroadcastReceiver crossFadeReceiver;
    private CrossfadeConfig crossfadeConfig;
    private CrossfadeManager crossfadeManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auplayer);
        crossfadeConfig = new CrossfadeConfig(this);
        crossfadeManager = new CrossfadeManager(this, crossfadeConfig);
        init();
        initCrossFadeSettings();
        loadSettings();
        registerCrossFadeReceiver();
    }

    private void init() {
        mainHandler = new Handler();

        currentTitle = findViewById(R.id.auplayer_tv_title);
        currentArtist = findViewById(R.id.auplayer_tv_artist);
        art2Background = findViewById(R.id.aupalyer_iv_art2_background);
        currentArt = findViewById(R.id.auplayer_iv_art);
        playPauseIcon = findViewById(R.id.auplayer_btn_playpause);
        trackTimeCurrent = findViewById(R.id.auplayer_currentpos);
        trackTimeDuration = findViewById(R.id.auplayer_duration);
        btnFwd = findViewById(R.id.btn_skip_forward);
        btnBwd = findViewById(R.id.btn_skip_backward);
        crossFadeStatus = findViewById(R.id.crossfade_status);
        Button btnSetA = findViewById(R.id.btn_set_a);
        Button btnSetB = findViewById(R.id.btn_set_b);
        toggleABRepeat = findViewById(R.id.toggle_ab_repeat);

        seeker = findViewById(R.id.aupalyer_seeker);
        seeker.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					if (fromUser && audioService != null && seekTouch) {
						int targetProgress = progress;
						if (isABRepeatEnabled && repeatStart != -1 && repeatEnd != -1) {
							targetProgress = Math.max(repeatStart, Math.min(progress, repeatEnd));
							seekBar.setProgress(targetProgress);
						}
						audioService.seekTo(targetProgress);
						trackTimeCurrent.setText(formatTime(targetProgress));
					}
				}

				public void onStartTrackingTouch(SeekBar seekBar) {
					stopSeeker();
					seekTouch = true;
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
					seekTouch = false;
					if (audioService != null && audioService.isPlaying()) {
						startSeeker();
					}
				}
			});

        seekerTick = new Runnable() {
            public void run() {
                if (audioService != null) {
                    int pos = audioService.getCurrentPosition();
                    seeker.setProgress(pos);
                    trackTimeCurrent.setText(formatTime(pos));
                    int interval = isABRepeatEnabled ? AB_REPEAT_INTERVAL : NORMAL_INTERVAL;
                    mainHandler.postDelayed(this, interval);
                }
            }
        };
		setClickable(R.id.btn_skip_forward);
        setClickable(R.id.btn_skip_backward);
        setClickable(R.id.auplayer_btn_playpause);
        setClickable(R.id.auplayer_btn_prev);
        setClickable(R.id.auplayer_btn_next);
        setClickable(R.id.auplayer_btn_repeat);
        setClickable(R.id.auplayer_btn_options);
        setClickable(R.id.auplayer_btn_back);
        setClickable(R.id.auplayer_btn_shuffle);
        setClickable(R.id.btn_set_a);
        setClickable(R.id.btn_set_b);
        setClickable(R.id.crossfade_settings_button);
        setClickable(R.id.crossfade_preview_button);

        btnSetA.setOnClickListener(this);
        btnSetB.setOnClickListener(this);
        toggleABRepeat.setOnCheckedChangeListener(this);
    }

    private void initCrossFadeSettings() {
        crossFadeSettingsPanel = findViewById(R.id.crossfade_settings_panel);
        crossFadeToggle = findViewById(R.id.crossfade_toggle);
        crossFadeDurationSeek = findViewById(R.id.crossfade_duration_seek);
        crossFadeDurationText = findViewById(R.id.crossfade_duration_text);
        crossFadePreviewButton = findViewById(R.id.crossfade_preview_button);

        crossFadeToggle.setChecked(crossfadeConfig.isEnabled());
        crossFadeDurationSeek.setMax(crossfadeConfig.getMaxDuration() - crossfadeConfig.getMinDuration());
        crossFadeDurationSeek.setProgress(crossfadeConfig.getDuration() - crossfadeConfig.getMinDuration());
        crossFadeDurationText.setText(formatSeconds(crossfadeConfig.getDuration() / 1000));

        crossFadeToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					crossfadeConfig.setEnabled(isChecked);
					crossfadeConfig.saveConfig(PlayerActivity.this);
					updateCrossFadeStatus();
					crossFadeDurationSeek.setEnabled(isChecked);
					crossFadePreviewButton.setEnabled(isChecked);
				}
			});

        crossFadeDurationSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					int duration = progress + crossfadeConfig.getMinDuration();
					crossfadeConfig.setDuration(duration);
					crossFadeDurationText.setText(formatSeconds(duration / 1000));
					updateCrossFadeStatus();
					if (fromUser) {
						crossfadeConfig.saveConfig(PlayerActivity.this);
						if (audioService != null) {
							audioService.setCrossfadeDuration(duration);
						}
					}
				}

				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			});

        crossFadePreviewButton.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					if (audioService != null && crossfadeConfig.isEnabled()) {
						SongItem nextSong = audioService.getNextSong();
						if (nextSong != null) {
							crossfadeManager.previewCrossfade(audioService.getMediaPlayer(), nextSong);
							Toast.makeText(PlayerActivity.this, "Previewing crossfade", Toast.LENGTH_SHORT).show();
						} else {
							Toast.makeText(PlayerActivity.this, "No next song available", Toast.LENGTH_SHORT).show();
						}
					}
				}
			});

        crossFadeDurationSeek.setEnabled(crossfadeConfig.isEnabled());
        crossFadePreviewButton.setEnabled(crossfadeConfig.isEnabled());
        updateCrossFadeStatus();
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        if (audioService != null) {
            editor.putString(PREF_REPEAT_MODE, audioService.getRepeatMode().name());
        }
        editor.apply();
    }

    private void loadSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String repeatModeName = prefs.getString(PREF_REPEAT_MODE, AudioService.RepeatMode.NONE.name());
        try {
            AudioService.RepeatMode repeatMode = AudioService.RepeatMode.valueOf(repeatModeName);
            if (audioService != null) {
                audioService.setRepeatMode(repeatMode);
            }
        } catch (IllegalArgumentException e) {
            if (audioService != null) {
                audioService.setRepeatMode(AudioService.RepeatMode.NONE);
            }
        }
        updateCrossFadeStatus();
    }

    private void updateCrossFadeStatus() {
        String status = crossfadeConfig.isEnabled() ? "Crossfade (" + (crossfadeConfig.getDuration() / 1000) + "s)" : "Crossfade Off";
        crossFadeStatus.setText(status);
    }

    private void registerCrossFadeReceiver() {
        crossFadeReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (Constants.ACTION_CROSSFADE_STARTED.equals(action)) {
                    crossFadeStatus.setText("Crossfading...");
                } else if (Constants.ACTION_CROSSFADE_COMPLETED.equals(action)) {
                    updateCrossFadeStatus();
                }
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(Constants.ACTION_CROSSFADE_STARTED);
        filter.addAction(Constants.ACTION_CROSSFADE_COMPLETED);
        LocalBroadcastManager.getInstance(this).registerReceiver(crossFadeReceiver, filter);
    }

    private String formatSeconds(int seconds) {
        return String.format(Locale.getDefault(), "%ds", seconds);
    }

    private String formatTime(int time) {
        int hrs = time / (1000 * 60 * 60);
        int min = (time / (1000 * 60)) % 60;
        int sec = (time / 1000) % 60;
        return hrs > 0 ? String.format(Locale.getDefault(), "%02d:%02d:%02d", hrs, min, sec)
			: String.format(Locale.getDefault(), "%02d:%02d", min, sec);
    }

    private void updateInfo() {
        SongItem si = audioService != null ? audioService.getCurrentSong() : null;
        if (si == null) {
            return;
        }

        currentTitle.setText(si.title != null ? si.title : "");
        currentArtist.setText(si.artist != null ? si.artist : "");

        if (si.getThumbnail() != null) {
            currentArt.setImageBitmap(si.getThumbnail());
            setLargeArt(si.getThumbnail());
        } else {
            App.runInBackground(new Runnable() {
					public void run() {
						final Bitmap bmp = BitmapUtils.tint(getResources(), R.drawable.ic_menu_songs, ThemeManager.getTheme().icon);
						if (bmp != null) {
							mainHandler.post(new Runnable() {
									public void run() {
										currentArt.setImageBitmap(bmp);
									}
								});
						}
					}
				});
        }

        playPauseIcon.setBackgroundResource(audioService != null && audioService.isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);
        playPauseIcon.reset();

        int pos = audioService != null ? audioService.getCurrentPosition() : 0;
        int duration = audioService != null ? audioService.getDuration() : 0;
        trackTimeDuration.setText(formatTime(duration));
        trackTimeCurrent.setText(formatTime(pos));

        seeker.setMax(duration);
        seeker.setProgress(pos);
    }

    private void setLargeArt(final Bitmap bitmap) {
        App.runInBackground(new Runnable() {
				public void run() {
					final Bitmap blurred = FastBlur.fastblur(bitmap, 0.2f, 3);
					if (blurred != null) {
						App.runInUiThread(new Runnable() {
								public void run() {
									art2Background.setBackground(new BitmapDrawable(getResources(), blurred));
								}
							});
					}
				}
			});
    }

    private void startSeeker() {
        stopSeeker();
        mainHandler.post(seekerTick);
    }

    private void stopSeeker() {
        mainHandler.removeCallbacks(seekerTick);
    }

    private void skipForward() {
        if (audioService != null) {
            int currentPos = audioService.getCurrentPosition();
            int newPos = currentPos + 30000;
            int duration = audioService.getDuration();
            if (isABRepeatEnabled && repeatEnd != -1 && newPos > repeatEnd) {
                newPos = repeatEnd;
            }
            if (newPos > duration) {
                newPos = duration;
            }
            audioService.seekTo(newPos);
            trackTimeCurrent.setText(formatTime(newPos));
        }
    }

    private void skipBackward() {
        if (audioService != null) {
            int currentPos = audioService.getCurrentPosition();
            int newPos = currentPos - 30000;
            if (isABRepeatEnabled && repeatStart != -1 && newPos < repeatStart) {
                newPos = repeatStart;
            }
            if (newPos < 0) {
                newPos = 0;
            }
            audioService.seekTo(newPos);
            trackTimeCurrent.setText(formatTime(newPos));
        }
    }

    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.auplayer_btn_playpause:
                if (audioService != null) {
                    if (!audioService.isPlaying() && isABRepeatEnabled && repeatStart != -1 && repeatEnd != -1) {
                        int currentPos = audioService.getCurrentPosition();
                        if (currentPos < repeatStart || currentPos > repeatEnd) {
                            audioService.seekTo(repeatStart);
                        }
                    }
                    audioService.playPause();
                }
                break;
            case R.id.auplayer_btn_next:
                if (audioService != null) {
                    audioService.playNext();
                }
                break;
            case R.id.auplayer_btn_prev:
                if (audioService != null) {
                    audioService.playPrev();
                }
                break;
            case R.id.btn_skip_forward:
                skipForward();
                break;
            case R.id.btn_skip_backward:
                skipBackward();
                break;
            case R.id.auplayer_btn_back:
                finish();
                break;
            case R.id.auplayer_btn_shuffle:
                if (audioService != null) {
                    audioService.shuffleQueue();
                }
                break;
            case R.id.auplayer_btn_repeat:
                if (audioService != null) {
                    audioService.toggleRepeat();
                    saveSettings();
                    updateRepeatButtonUI();
                }
                break;
            case R.id.auplayer_btn_options:
                if (audioService != null && audioService.getCurrentSong() != null) {
                    new CurrentSongOptions(this, audioService.getCurrentSong()).show();
                }
                break;
            case R.id.crossfade_settings_button:
                boolean visible = crossFadeSettingsPanel.getVisibility() == View.VISIBLE;
                crossFadeSettingsPanel.setVisibility(visible ? View.GONE : View.VISIBLE);
                break;
            case R.id.btn_set_a:
                if (audioService != null) {
                    audioService.setRepeatPointA();
                    repeatStart = audioService.getCurrentPosition();
                    Toast.makeText(this, "A set to " + formatTime(repeatStart), Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.btn_set_b:
                if (audioService != null && repeatStart != -1) {
                    audioService.setRepeatPointB();
                    repeatEnd = audioService.getCurrentPosition();
                    if (repeatEnd <= repeatStart) {
                        Toast.makeText(this, "Point B must be after A", Toast.LENGTH_SHORT).show();
                        repeatEnd = -1;
                        audioService.clearABRepeat();
                    } else {
                        Toast.makeText(this, "B set to " + formatTime(repeatEnd), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Please set A first", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (buttonView.getId() == R.id.toggle_ab_repeat) {
            isABRepeatEnabled = isChecked;
            if (isChecked) {
                if (repeatStart == -1 || repeatEnd == -1 || repeatEnd <= repeatStart) {
                    Toast.makeText(this, "Please set valid A and B points", Toast.LENGTH_SHORT).show();
                    toggleABRepeat.setChecked(false);
                    isABRepeatEnabled = false;
                    if (audioService != null) {
                        audioService.clearABRepeat();
                    }
                    return;
                }
                if (audioService != null) {
                    int currentPos = audioService.getCurrentPosition();
                    if (currentPos < repeatStart || currentPos > repeatEnd) {
                        audioService.seekTo(repeatStart);
                    }
                }
            } else if (audioService != null) {
                audioService.clearABRepeat();
            }
            if (audioService != null && audioService.isPlaying()) {
                stopSeeker();
                startSeeker();
            }
            Toast.makeText(this, "A-B Repeat " + (isChecked ? "Enabled (" + formatTime(repeatStart) +
						   " - " + formatTime(repeatEnd) + ")" : "Disabled"), Toast.LENGTH_SHORT).show();
        }
    }

    private void updateRepeatButtonUI() {
        LinearLayout repeatLayout = findViewById(R.id.auplayer_btn_repeat);
        TintedImageView repeatImageView = repeatLayout.findViewById(R.id.au6);
        if (repeatImageView != null && audioService != null) {
            AudioService.RepeatMode currentRepeatMode = audioService.getRepeatMode();
            switch (currentRepeatMode) {
                case REPEAT_ALL:
                    repeatImageView.setImageResource(R.drawable.repeat_all);
                    repeatImageView.setTint(Color.GREEN);
                    break;
                case REPEAT_ONE:
                    repeatImageView.setImageResource(R.drawable.repeat_one);
                    repeatImageView.setTint(Color.YELLOW);
                    break;
                default:
                    repeatImageView.setImageResource(R.drawable.no_repeat);
                    repeatImageView.setTint(Color.RED);
                    break;
            }
        }
    }

    public void openEqualizerPanel(Activity activity) {
        if (EqualizerUtils.hasEqualizer(activity)) {
            EqualizerUtils.openEqualizer(activity, audioService.getMediaPlayer());
        } else {
            Toast.makeText(activity, "No equalizer available", Toast.LENGTH_SHORT).show();
        }
    }

    public void onAudioServiceConnect(AudioService service) {
        audioService = service;
        loadSettings();
        updateInfo();
        audioService.requestPlaystateUpdate();
        updateRepeatButtonUI();
    }

    public void onPlaybackStart() {
        playPauseIcon.setBackgroundResource(R.drawable.ic_pause);
        playPauseIcon.reset();
        startSeeker();
    }

    public void onPlaybackPause() {
        playPauseIcon.setBackgroundResource(R.drawable.ic_play);
        playPauseIcon.reset();
        stopSeeker();
    }

    public void onPlaybackStop() {
        updateInfo();
        playPauseIcon.setBackgroundResource(R.drawable.ic_play);
        playPauseIcon.reset();
        stopSeeker();
    }

    public void onSongChanged(SongItem newSong) {
        currentSong = newSong;
        updateInfo();
        if (queueAdapter != null) {
            queueAdapter.setCurrent(newSong);
        }
        repeatStart = -1;
        repeatEnd = -1;
        isABRepeatEnabled = false;
        toggleABRepeat.setChecked(false);
        if (audioService != null) {
            audioService.clearABRepeat();
        }
    }

    public void onSearchResultItemClick(SongItem song) {
        if (audioService != null) {
            audioService.playSong(song);
        }
    }

    public void onSongsListUpdated(List<SongItem> songs) {
        if (queueAdapter != null) {
            queueAdapter.notifyDataSetChanged();
        }
    }

    public void onQueueUpdated(List<SongItem> updatedQueue) {
        if (queueAdapter != null) {
            queueAdapter.update(updatedQueue);
        }
    }

    protected void onPause() {
        stopSeeker();
        APEvents.getInstance().removePlaybackEventListener(this);
        QueueManager.getInstance().removeQueueListener(this);
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        APEvents.getInstance().addPlaybackEventListener(this);
        AudioService.connect(this, this);
        QueueManager.getInstance().addQueueListener(this);
        if (audioService != null && audioService.isPlaying()) {
            startSeeker();
        }
    }

    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(crossFadeReceiver);
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
