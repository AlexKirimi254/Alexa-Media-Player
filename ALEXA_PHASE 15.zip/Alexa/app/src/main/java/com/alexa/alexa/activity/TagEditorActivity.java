package com.alexa.alexa.activity;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.alexa.alexa.R;
import com.alexa.alexa.database.DatabaseHelper;

public class TagEditorActivity extends Activity {

    private EditText titleEditText, artistEditText, albumEditText, genreEditText, yearEditText;
    private ImageView thumbnailImageView;
    private DatabaseHelper dbHelper;

    private String path, title, artist, album, genre, year;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tageditor);

        // Initialize the views
        titleEditText = findViewById(R.id.activity_tageditor_title);
        artistEditText = findViewById(R.id.activity_tageditor_artist);
        albumEditText = findViewById(R.id.activity_tageditor_album);
        genreEditText = findViewById(R.id.activity_tageditor_genre);
        yearEditText = findViewById(R.id.activity_tageditor_year);
        thumbnailImageView = findViewById(R.id.activity_tageditor_thumbnail);
        Button saveButton = findViewById(R.id.activity_tageditor_save_button);

        // Initialize the DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Retrieve the song details from the intent
        intent = getIntent();
        path = intent.getStringExtra("path");
        title = intent.getStringExtra("title");
        artist = intent.getStringExtra("artist");
        album = intent.getStringExtra("album");
        genre = intent.getStringExtra("genre");
        year = intent.getStringExtra("year");

        // Set the values in the EditText fields
        titleEditText.setText(title);
        artistEditText.setText(artist);
        albumEditText.setText(album);
        genreEditText.setText(genre);
        yearEditText.setText(year);

        // Retrieve and set the thumbnail from the intent
        byte[] thumbnailBytes = intent.getByteArrayExtra("thumbnail");
        if (thumbnailBytes != null) {
            Bitmap thumbnail = BitmapFactory.decodeByteArray(thumbnailBytes, 0, thumbnailBytes.length);
            thumbnailImageView.setImageBitmap(thumbnail);
        }

        // Set up the save button listener
        saveButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					saveTagInfo();
				}
			});
    }

    // Method to save tag information to the database
    private void saveTagInfo() {
        // Get the updated information from the EditText fields
        String updatedTitle = titleEditText.getText().toString();
        String updatedArtist = artistEditText.getText().toString();
        String updatedAlbum = albumEditText.getText().toString();
        String updatedGenre = genreEditText.getText().toString();
        String updatedYear = yearEditText.getText().toString();

        // Validate that path is available for updating the database
        if (path == null || path.isEmpty()) {
            Toast.makeText(TagEditorActivity.this, "Invalid song path", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update the song information in the database
        boolean success = dbHelper.updateSongMetadata(path, updatedTitle, updatedArtist, updatedAlbum, updatedGenre, updatedYear);

        // Show feedback to the user based on success or failure
        if (success) {
            Toast.makeText(TagEditorActivity.this, "Changes saved successfully", Toast.LENGTH_SHORT).show();
            finish(); // Optionally close the activity after saving
        } else {
            Toast.makeText(TagEditorActivity.this, "Failed to save changes", Toast.LENGTH_SHORT).show();
        }
    }
}
