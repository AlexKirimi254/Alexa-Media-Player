package com.alexa.alexa.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.library.SongLibrary;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.menu.AddMultipleToPlaylistDialog;
import com.alexa.alexa.menu.AddToPlaylistDialog;
import com.alexa.alexa.models.AlbumItem;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import java.util.List;

public class AlbumsListAdaptor extends RecyclerView.Adapter<AlbumsListAdaptor.AlbumViewHolder> {

    private Context context;
    private List<AlbumItem> albumList;
    private OnItemClickListener itemClickListener;
	private ThemeManager.Theme currentTheme;
    public interface OnItemClickListener {
        void onItemClick(AlbumItem selectedAlbum);
    }

    public AlbumsListAdaptor(Context context, List<AlbumItem> albumList) {
        this.context = context;
        this.albumList = albumList;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.itemClickListener = listener;
    }

    public void update(List<AlbumItem> newAlbumList) {
        this.albumList = newAlbumList;
        notifyDataSetChanged();
    }

    @Override
    public AlbumViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapteritem_album, parent, false);
        return new AlbumViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AlbumViewHolder holder, int position) {
        final AlbumItem album = albumList.get(position);
        holder.albumNameTextView.setText(album.getAlbumName());
        holder.songCountTextView.setText(album.getSongCount() + (album.getSongCount() > 1 ? " songs" : " song"));
        holder.artistCountTextView.setText(album.getArtistCount() + (album.getArtistCount() > 1 ? " artists" : " artist"));

        List<SongItem> songsInAlbum = album.getSongList();
        SongItem song = songsInAlbum.get(0);
        Bitmap thumbnail = song.getThumbnail(); // Assuming this method exists
        if (thumbnail != null) {
            holder.thumbnailImageView.setImageDrawable(new BitmapDrawable(holder.thumbnailImageView.getResources(), thumbnail));
        } else {
            holder.thumbnailImageView.setImageResource(R.drawable.cover_f); // Placeholder image
        }

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					showMenuForAlbum(v, album);
					return true;
				}
			});

        holder.moreIconImageView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showMenuForAlbum(v, album);
				}
			});
    }

    @Override
    public int getItemCount() {
        return albumList.size();
    }
	private void showAddToPlaylistDialog(AlbumItem album) {
        List<SongItem> songsInAlbum = album.getSongList();
        if (songsInAlbum == null || songsInAlbum.isEmpty()) {
            Toast.makeText(context, "This album has no songs.", Toast.LENGTH_SHORT).show();
            return;
        }

        AddToPlaylistDialog dialog = new AddToPlaylistDialog(context, songsInAlbum, new AddToPlaylistDialog.OnPlaylistAddListener() {
				@Override
				public void onPlaylistAddSuccess() {
					Toast.makeText(context, "Album songs added to playlist.", Toast.LENGTH_SHORT).show();
				}
			});
        dialog.show();
    }
    private void addAlbumSongsToPlaylist(final View view, final AlbumItem album) {
        SongLibrary.getInstance().getSongsByAlbum(album.getId(), new SongLibrary.ResultCallback<List<SongItem>>() {
				@Override
				public void onResult(List<SongItem> songs) {
					if (songs != null && !songs.isEmpty()) {
						AddMultipleToPlaylistDialog dialog = new AddMultipleToPlaylistDialog(view.getContext(), songs);
						dialog.show();
					} else {
						Toast.makeText(view.getContext(), "No songs found in this album.", Toast.LENGTH_SHORT).show();
					}
				}
			});
    }
	public void setTheme(ThemeManager.Theme theme) {
        this.currentTheme = theme;
        notifyDataSetChanged();
    }
    private void showMenuForAlbum(final View anchorView, final AlbumItem album) {
        PopupMenu popupMenu = new PopupMenu(anchorView.getContext(), anchorView);
        MenuInflater inflater = popupMenu.getMenuInflater();
        inflater.inflate(R.menu.song_options_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					switch (item.getItemId()) {
						case R.id.menu_play_next:
							addAlbumSongsToQueue(album);
							return true;
						case R.id.menu_add_to_playlist:
							showAddToPlaylistDialog(album);
							return true;
						default:
							return false;
					}
				}
			});

        popupMenu.show();
    }

    private void addAlbumSongsToQueue(AlbumItem album) {
        List<SongItem> songsInAlbum = album.getSongList();
        for (SongItem song : songsInAlbum) {
            AudioService.getInstance().addToQueue(song);
            QueueManager.getInstance().addSongToQueue(song);
        }
    }

    public class AlbumViewHolder extends RecyclerView.ViewHolder {
        public TextView albumNameTextView;
        public TextView songCountTextView;
        public TextView artistCountTextView;
        public ImageView thumbnailImageView;
        public ImageView moreIconImageView;

        public AlbumViewHolder(View itemView) {
            super(itemView);
            albumNameTextView = itemView.findViewById(R.id.albumslist_item_title);
            songCountTextView = itemView.findViewById(R.id.albumslist_songcount);
            artistCountTextView = itemView.findViewById(R.id.albumslist_artistcount);
            thumbnailImageView = itemView.findViewById(R.id.albumslist_item_albumart);
            moreIconImageView = itemView.findViewById(R.id.albumslist_item_more_icon);

            itemView.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						if (itemClickListener != null) {
							int position = getAdapterPosition();
							if (position != RecyclerView.NO_POSITION) {
								itemClickListener.onItemClick(albumList.get(position));
							}
						}
					}
				});
        }
    }
}
