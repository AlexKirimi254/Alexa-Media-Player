package com.alexa.alexa.activity;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.fragment.R;
import androidx.viewpager.widget.ViewPager;
import com.alexa.alexa.adapters.OnboardingPagerAdapter;



import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import androidx.viewpager.widget.ViewPager;
import java.util.ArrayList;
import java.util.List;

public class OnboardingActivity extends Activity {

    private ViewPager viewPager;
    private Button skipButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        viewPager = findViewById(R.id.onboarding_viewpager);
        skipButton = findViewById(R.id.onboarding_skip_button);

        // Create onboarding views
        final List<View> onboardingViews = new ArrayList<>();
        LayoutInflater inflater = LayoutInflater.from(this);
        onboardingViews.add(inflater.inflate(R.layout.onboarding_page_1, null));
        onboardingViews.add(inflater.inflate(R.layout.default_recyclerview_queue, null));
        onboardingViews.add(inflater.inflate(R.layout.activity_main, null));

        // Set up ViewPager with adapter
        OnboardingPagerAdapter adapter = new OnboardingPagerAdapter(onboardingViews);
        viewPager.setAdapter(adapter);

        skipButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    navigateToMainActivity();
                }
            });

        // Track onboarding completion
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    if (position == onboardingViews.size() - 1) { // Last page
                        skipButton.setText("Finish");
                    } else {
                        skipButton.setText("Skip");
                    }
                }

                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}

                @Override
                public void onPageScrollStateChanged(int state) {}
            });
    }

    private void navigateToMainActivity() {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        prefs.edit().putBoolean("OnboardingComplete", true).apply();
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
