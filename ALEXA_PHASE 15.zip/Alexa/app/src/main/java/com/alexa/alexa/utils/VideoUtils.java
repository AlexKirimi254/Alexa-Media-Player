package com.alexa.alexa.utils;


import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;
import java.util.ArrayList;
import java.util.List;

public class VideoUtils {

    public static List<String> getAllVideos(Context context) {
        List<String> videoPaths = new ArrayList<>();

        // Query the MediaStore to get video files
        Cursor cursor = context.getContentResolver().query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            null,
            null,
            null,
            null
        );

        if (cursor != null && cursor.moveToFirst()) {
            int videoPathColumnIndex = cursor.getColumnIndex(MediaStore.Video.Media.DATA);
            do {
                String videoPath = cursor.getString(videoPathColumnIndex);
                videoPaths.add(videoPath);
            } while (cursor.moveToNext());
            cursor.close();
        }

        return videoPaths;  // Return the list of video paths
    }
}

