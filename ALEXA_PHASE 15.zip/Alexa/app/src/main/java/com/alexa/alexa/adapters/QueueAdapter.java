package com.alexa.alexa.adapters;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alexa.alexa.R;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.models.SongItem;

import java.util.List;

public class QueueAdapter extends RecyclerView.Adapter<QueueAdapter.QueueViewHolder> {

    private List<SongItem> queue;
    private Context context;
    private OnItemClickListener itemClickListener;

    public interface OnItemClickListener {
        void onItemClick(SongItem song);
    }
    public QueueAdapter(Context context, List<SongItem> queue) {
        this.context = context;
        this.queue = queue;
    }

    @NonNull
    @Override
    public QueueViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.queue_itm, parent, false);
        return new QueueViewHolder(view);
    }
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.itemClickListener = listener;
    }
    
    
    @Override
    public void onBindViewHolder(@NonNull QueueViewHolder holder, int position) {
        final SongItem song = queue.get(position);
        holder.songTitle.setText(song.getTitle());
        holder.songArtist.setText(song.getArtist());

        holder.removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    QueueManager.getInstance().removeSongFromQueue(song);
                    notifyDataSetChanged();
                    Toast.makeText(context, "Removed from queue", Toast.LENGTH_SHORT).show();
                }
            });
    }

    @Override
    public int getItemCount() {
        return queue.size();
    }

    public void updateQueue(List<SongItem> newQueue) {
        queue = newQueue;
        notifyDataSetChanged();
    }

    public static class QueueViewHolder extends RecyclerView.ViewHolder {
        TextView songTitle, songArtist;
        ImageButton removeButton;

        public QueueViewHolder(@NonNull View itemView) {
            super(itemView);
            songTitle = itemView.findViewById(R.id.queue_song_title);
            songArtist = itemView.findViewById(R.id.queue_song_artist);
            removeButton = itemView.findViewById(R.id.queue_remove_button);
        }
    }
}
