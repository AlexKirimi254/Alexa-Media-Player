package com.alexa.alexa;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.menu.SongOptions;
import com.alexa.alexa.models.SearchResult;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.utils.SearchHelper;
import com.alexa.alexa.view.TintedImageView;
import java.util.ArrayList;
import java.util.List;
import com.alexa.alexa.activity.BaseActivity;

public class SearchPanel extends BaseActivity implements SearchHelper.ResultCallback {
    private final MainActivity act;
    private final EditText input;
    private final ListView list8;
    private final SearchResutlAdapter adapter;
    private List<SongItem> songList = new ArrayList<>();
    private final Dialog dlg;
    private final OnSearchResultItemClickListener ocl;
    SongItem currentSong;
    public SearchPanel(MainActivity activity, OnSearchResultItemClickListener listener) {
        this.act = activity;
        this.ocl = listener;
        dlg = new Dialog(activity, R.style.AppTheme); // Use a custom dialog theme
        dlg.setContentView(R.layout.dlg_searchpanel);

        input = dlg.findViewById(R.id.searchpanel_input);
        input.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    // No implementation needed
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    // No implementation needed
                }

                @Override
                public void afterTextChanged(Editable s) {
                    String query = input.getText().toString();
                    if (!query.isEmpty()) {
                        SearchHelper.get().search(query, songList, SearchPanel.this);
                    } else {
                        adapter.clear();
                    }
                }
            });

        list8 = dlg.findViewById(R.id.searchpanel_list8);
        list8.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                public void onItemClick(AdapterView av, View v, int pos, long p4){
                    SearchResult res = adapter.getItem(pos);
                    if(ocl!=null){
                        ocl.onSearchResultItemClick(res.si);
                    }

                }
            });
        adapter = new SearchResutlAdapter(activity);
        list8.setAdapter(adapter);
    }

    public void setSongList(List<SongItem> list) {
        songList = list;
    }

    @Override
    public void onSearchResult(List<SearchResult> list) {
        adapter.update(list);
    }

    public void show(List<SongItem> list){
        input.setText("");
        adapter.clear();
        setSongList(list);
        dlg.show();
        dlg.getWindow().setLayout(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        dlg.getWindow().setBackgroundDrawable(null);
        input.postDelayed(new Runnable(){
                public void run(){
                    act.showKeyboard(input); 
                }
            },10);

    }

    public void hide() {
        input.setText("");
        adapter.clear();
        dlg.dismiss();
    }

    private class SearchResutlAdapter extends BaseAdapter {
        private final LayoutInflater inflater;
        private List<SearchResult> resultList = new ArrayList<>();
        private ThemeManager.Theme theme;
        public SearchResutlAdapter(Context context) {
            this.inflater = LayoutInflater.from(context);
        }

        public void update(List<SearchResult> list) {
            resultList = list;
            notifyDataSetChanged();
        }

        public void clear() {
            resultList.clear();
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return resultList.size();
        }

        @Override
        public SearchResult getItem(int position) {
            return resultList.get(position);
        }
        public void setTheme(ThemeManager.Theme theme){
            this.theme = theme;
            notifyDataSetChanged();
        }
        @Override
        public long getItemId(int position) {
            return position;
        }

     @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            SearchResult result = resultList.get(position);
             final SongItem song = result.si;

            View view = inflater.inflate(R.layout.songlist_item, parent, false);
            TextView titleView = view.findViewById(R.id.songlist_itemTitle);
            TextView artistView = view.findViewById(R.id.songlist_itemArtist);
            
          ImageView art = (ImageView) view.findViewById(R.id.songlist_item_albumart);
    
         
         if(song.getIconPath()!=null){
             art.setBackgroundDrawable(new BitmapDrawable(act.getResources(),song.getThumbnail()));
         }else{
             //art.setBackgroundResource(R.color.black);
             art.setImageBitmap(BitmapUtils.tint(act.getResources(), R.drawable.cover_f, theme.icon));
         }
            titleView.setText(result.title);
            artistView.setText(song.artist);
         view.findViewById(R.id.songlist_item_more).setOnClickListener(new View.OnClickListener(){
         public void onClick(View v){
         new SongOptions(act, song).show();
         }
         });
            return view;
        }
    
    
    
   /* @Override
    public View getView(int pos, View p2, ViewGroup p3)
    {
        SearchResult result = resultList.get(pos);
        SongItem song = result.si;
        
        
        
      //  final SongItem item = songList.get(pos);

        View v = inflater.inflate(R.layout.songlist_item, null, false);
        TextView title = (TextView) v.findViewById(R.id.songlist_itemTitle);
        title.setText(song.title);
     //   title.setTextColor(theme.text);
        //
        TextView artist = (TextView) v.findViewById(R.id.songlist_itemArtist);
        artist.setText(song.artist);
     //   artist.setTextColor(theme.text);
        //
        final ImageView art = (ImageView) v.findViewById(R.id.songlist_item_albumart);
        if(song.getIconPath()!=null){
            art.setBackgroundDrawable(new BitmapDrawable(act.getResources(),song.getThumbnail()));
        }else{
            //art.setBackgroundResource(R.color.black);
            art.setImageBitmap(BitmapUtils.tint(act.getResources(), R.drawable.cover_f, theme.icon));
        }

        v.findViewById(R.id.songlist_item_more).setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    new SongOptions(act, currentSong).show();
                }
            });
        v.setBackgroundColor(theme.background);

        TintedImageView more_icon = (TintedImageView) v.findViewById(R.id.songlist_items_more_icon);
        more_icon.setTint(theme.icon);

        if(song!=null && song.equals(song)){
            v.setBackgroundColor(theme.text);
            title.setTextColor(theme.background);
            artist.setTextColor(theme.background);

            more_icon.setTint(theme.background);

            if(cj.color!=theme.background){
                App.runInBackground(new Runnable(){
                        public void run(){
                            final Bitmap b = BitmapUtils.tint(act.getResources(), R.drawable.cover_f, theme.background);
                            if(b!=null){
                                App.runInUiThread(new Runnable(){
                                        public void run(){
                                            art.setImageBitmap(b);
                                            cj.bmp = b;
                                            cj.color = theme.background;
                                        } 
                                    });
                            }
                        }
                    });
            }else{
                art.setImageBitmap(cj.bmp);
            }
        }

        v.setTag(song);
        return v;
    }
    
    }*/
}
    public interface OnSearchResultItemClickListener {
        
        
        void onSearchResultItemClick(SongItem song);
        
        
        
    }
    class J{
        Bitmap bmp;
        int color;
    }
    J cj = new J();

}
