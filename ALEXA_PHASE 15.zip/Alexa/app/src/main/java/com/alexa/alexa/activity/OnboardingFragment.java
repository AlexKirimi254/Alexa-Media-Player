package com.alexa.alexa.activity;




import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.alexa.alexa.R;

public class OnboardingFragment extends Fragment
 {

    private static final String ARG_TITLE = "title";
    private static final String ARG_DESCRIPTION = "description";

    public static OnboardingFragment newInstance(String title, String description) {
        OnboardingFragment fragment = new OnboardingFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TITLE, title);
        args.putString(ARG_DESCRIPTION, description);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_onboarding, container, false);

        TextView title = view.findViewById(R.id.onboarding_title);
        TextView description = view.findViewById(R.id.onboarding_description);

        if (getArguments() != null) {
            title.setText(getArguments().getString(ARG_TITLE));
            description.setText(getArguments().getString(ARG_DESCRIPTION));
        }

        return view;
    }
}
