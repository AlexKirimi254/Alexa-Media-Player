// SongListAdapter.java

package com.alexa.alexa.activityAdapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;

import java.util.List;

public class SongListAdapter extends BaseAdapter {

    private Context context;
    private List<SongItem> songs;
    private SongItem currentSong;

    public SongListAdapter(Context context, List<SongItem> songs) {
        this.context = context;
        this.songs = songs;
    }

    public void setCurrentSong(SongItem song) {
        this.currentSong = song;
    }

    @Override
    public int getCount() {
        return songs.size();
    }

    @Override
    public Object getItem(int position) {
        return songs.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.songlist_item, parent, false);
            holder = new ViewHolder();
            holder.titleTextView = convertView.findViewById(R.id.songlist_itemTitle);
            holder.artistTextView = convertView.findViewById(R.id.songlist_itemArtist);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        SongItem song = songs.get(position);
        holder.titleTextView.setText(song.getTitle());
        holder.artistTextView.setText(song.getArtist());

        // Highlight the current song
        if (currentSong != null && song.equals(currentSong)) {
            convertView.setBackgroundColor(context.getResources().getColor(R.color.color2));
        } else {
            convertView.setBackgroundColor(context.getResources().getColor(android.R.color.transparent));
        }

        return convertView;
    }

    private static class ViewHolder {
        TextView titleTextView;
        TextView artistTextView;
    }
}

