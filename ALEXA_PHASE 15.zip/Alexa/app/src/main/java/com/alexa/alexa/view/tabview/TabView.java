package com.alexa.alexa.view.tabview;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import java.util.ArrayList;
import java.util.List;
import com.alexa.alexa.view.RoundedLinearLayout;

public class TabView extends LinearLayout {
	RoundedLinearLayout tabcontainer;
    private Context ctx;
    private LinearLayout tabstrip;
    private ViewPager viewPager;
	int cornerRadius=0;
    int colorBorder;

    boolean showStrip = true;
    Tab currentTab=null;

    int currentIndex=0;
    int borderWidth=0;



    List<Tab> tablist = new ArrayList<>();
    List<TextView> tabTitles = new ArrayList<>();

    GradientDrawable gdrc;

    public TabView(Context ctx) {
        super(ctx);
        _init();
    }

    public TabView(Context ctx, AttributeSet attrs) {
        super(ctx, attrs);
        _init();
    }

    private void _init() {
        ctx = getContext();
        View v = LayoutInflater.from(ctx).inflate(R.layout.customview_tabview, this, true);

        tabstrip = v.findViewById(R.id.customview_tabview_tabstrip);
        viewPager = v.findViewById(R.id.customview_tabview_viewpager);

        viewPager.setAdapter(new TabPagerAdapter());
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
				@Override
				public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}

				@Override
				public void onPageSelected(int position) {
					showTab(position);
				}

				@Override
				public void onPageScrollStateChanged(int state) {}
			});
    }

    public void addTab(String title, Tab tab) {
        tablist.add(tab);
        _addTitle(title);
        viewPager.getAdapter().notifyDataSetChanged();
    }

    private void _addTitle(String title) {
		final TextView tv = new TextView(ctx);
		tv.setText(title);
		tv.setPadding(10, 5, 10, 5); // Add padding for spacing
		tv.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					int index = tabTitles.indexOf(tv);
					viewPager.setCurrentItem(index);
				}
			});
		tabTitles.add(tv);
		tabstrip.addView(tv);
	}

    private void _setTitles(int index) {
        for (int i = 0; i < tabTitles.size(); i++) {
            TextView tv = tabTitles.get(i);
            tv.setBackgroundColor(i == index ? 0xFFCCCCCC : 0x00000000); // Example color
        }
    }

    public void showTab(int index) {
		if (index >= 0 && index < tablist.size()) {
			currentIndex = index;
			viewPager.setCurrentItem(index, false); // Sync ViewPager to the selected tab
			_setTitles(index); // Update tab titles
		}
	}
	public void onApplyTheme(ThemeManager.Theme theme){
        setBackgroundColor(theme.background);
        for(Tab t : tablist){
            t.onApplyTheme(theme);
        }
        for(TextView tv : tabTitles){
            tv.setTextColor(theme.text);
        }
        colorBorder = theme.dividers;
        //
        gdrc.setStroke(borderWidth, colorBorder);
        _setTitles(currentIndex);
        tabcontainer.setBorderColor(theme.dividers);
    }
    private class TabPagerAdapter extends PagerAdapter {

        @Override
        public int getCount() {
            return tablist.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            Tab tab = tablist.get(position);
            View view = tab.getView();
            container.addView(view);
            return view;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }
    }
}
