package com.alexa.alexa.view;

public class ColorTextView
{
}
