package com.alexa.alexa.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import java.util.List;

public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.PlaylistViewHolder> {

    private Context context;
    private List<Playlist> playlists;
    private OnItemClickListener itemClickListener;

    public interface OnItemClickListener {
        void onItemClick(Playlist playlist);
    }

    public PlaylistAdapter(Context context, List<Playlist> playlists, OnItemClickListener itemClickListener) {
        this.context = context;
        this.playlists = playlists;
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public PlaylistViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapteritem_playlist, parent, false);
        return new PlaylistViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlaylistViewHolder holder, final int position) {
        final Playlist playlist = playlists.get(position);

        // Set playlist name
        holder.playlistName.setText(playlist.getName());
        holder.art.setBackgroundResource(R.drawable.cover_f); // Placeholder image

        // Item click listener
        holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (itemClickListener != null) {
                        itemClickListener.onItemClick(playlist);
                    }
                }
            });

        // Popup menu for more options
        holder.moreOptions.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showPopupMenu(v, playlist);
                }
            });
    }

    @Override
    public int getItemCount() {
        return playlists.size();
    }

    private void showPopupMenu(View view, final Playlist playlist) {
        PopupMenu popupMenu = new PopupMenu(context, view);
        MenuInflater inflater = popupMenu.getMenuInflater();
        inflater.inflate(R.menu.song_options_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.menu_play_next:
                            addPlaylistSongsToQueue(playlist);
                            return true;
                        default:
                            return false;
                    }
                }
            });
        popupMenu.show();
    }

    private void addPlaylistSongsToQueue(Playlist playlist) {
        List<SongItem> songsInPlaylist = playlist.getSongs(); // Get all songs from the playlist
        for (SongItem song : songsInPlaylist) {
            // Add each song to the "play next" queue using QueueManager and AudioService
            QueueManager.getInstance().addSongToQueue(song);
            AudioService.getInstance().addToQueue(song);
        }
    }

    public void updateList(List<Playlist> newPlaylists) {
        playlists.clear();
        playlists.addAll(newPlaylists);
        notifyDataSetChanged();
    }

    public static class PlaylistViewHolder extends RecyclerView.ViewHolder {
        TextView playlistName;
        ImageView art, moreOptions;

        public PlaylistViewHolder(@NonNull View itemView) {
            super(itemView);
            playlistName = itemView.findViewById(R.id.playlist_name);
            art = itemView.findViewById(R.id.playlist_item_albumart);
            moreOptions = itemView.findViewById(R.id.playlist_item_more);
        }
    }
}
