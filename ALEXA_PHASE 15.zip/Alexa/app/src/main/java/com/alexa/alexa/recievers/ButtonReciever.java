package com.alexa.alexa.recievers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.view.KeyEvent;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.Constants;

public class ButtonReciever extends BroadcastReceiver {    
    @Override
    public void onReceive(final Context ctx, Intent intent)
    {
        String act = intent.getAction();
        switch(act){
            case Intent.ACTION_MEDIA_BUTTON:
                KeyEvent evt = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                if(evt!=null){
                    int action = evt.getAction();
                    switch(evt.getKeyCode()){
                        case KeyEvent.KEYCODE_HEADSETHOOK:
                            if(action == KeyEvent.ACTION_DOWN){
                                Intent i = new Intent(ctx, AudioService.class);
                                i.setAction(Constants.CMD_MEDIA_BUTTON);
                                ctx.startService(i);
                                //Utils.toast(ctx, "a: "+i.getAction());
                            }
                            break;
                    }
                }
                break;
        }
    } 
}
