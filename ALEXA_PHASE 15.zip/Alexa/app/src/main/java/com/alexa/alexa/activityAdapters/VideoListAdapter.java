package com.alexa.alexa.activityAdapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import java.io.File;
import java.util.List;

public class VideoListAdapter extends RecyclerView.Adapter<VideoListAdapter.VideoViewHolder> {

    private List<String> videoList;
    private Context context;
    private OnItemClickListener onItemClickListener;

    public VideoListAdapter(Context context) {
        this.context = context;
    }

    @Override
    public VideoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_video, parent, false);
        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(VideoViewHolder holder, int position) {
        String videoPath = videoList.get(position);
        holder.bind(videoPath);
    }

    @Override
    public int getItemCount() {
        return videoList != null ? videoList.size() : 0;
    }

    public void update(List<String> videoList) {
        this.videoList = videoList;
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    public class VideoViewHolder extends RecyclerView.ViewHolder {

        private TextView videoTitle;
        private ImageView videoThumbnail; // For displaying the thumbnail

        public VideoViewHolder(View itemView) {
            super(itemView);
            videoTitle = itemView.findViewById(R.id.videoTitle);
            videoThumbnail = itemView.findViewById(R.id.videoThumbnail); // Add an ImageView to your item_video layout
        }

        public void bind(final String videoPath) {
            videoTitle.setText(new File(videoPath).getName());

            // Extract the thumbnail
            Bitmap thumbnail = getVideoThumbnail(videoPath);
            if (thumbnail != null) {
                videoThumbnail.setImageBitmap(thumbnail);
            } else {
                videoThumbnail.setImageResource(R.drawable.cover_f); // A placeholder thumbnail
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (onItemClickListener != null) {
                            onItemClickListener.onItemClick(videoPath);
                        }
                    }
                });
        }

        private Bitmap getVideoThumbnail(String videoPath) {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            try {
                retriever.setDataSource(videoPath);
                // Extract the frame at the first second (1000000 microseconds)
                return retriever.getFrameAtTime(1000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            } finally {
                retriever.release();
            }
        }
    }

    public interface OnItemClickListener {
        void onItemClick(String videoPath);
    }
}


