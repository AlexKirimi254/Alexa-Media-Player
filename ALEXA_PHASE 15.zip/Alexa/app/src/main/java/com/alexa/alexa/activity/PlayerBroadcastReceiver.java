package com.alexa.alexa.activity;

import android.content.BroadcastReceiver; import android.content.Context; import android.content.Intent; import android.widget.Toast;

import com.alexa.alexa.Constants;

public class PlayerBroadcastReceiver extends BroadcastReceiver {

	private PlayerActivity activity;

	public PlayerBroadcastReceiver(PlayerActivity activity) {
		this.activity = activity;
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		if (Constants.ACTION_CROSSFADE_STARTED.equals(action)) {
			Toast.makeText(context, "Crossfade started", Toast.LENGTH_SHORT).show();
		} else if (Constants.ACTION_CROSSFADE_COMPLETED.equals(action)) {
			Toast.makeText(context, "Crossfade completed", Toast.LENGTH_SHORT).show();
		}
	}

}


