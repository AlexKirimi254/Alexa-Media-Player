package com.alexa.alexa.menu;

import android.app.Dialog;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.models.SongItem;
import android.content.Context;

public class EditFileTagsDialog {
    private Context ctx;
    private SongItem si;
    private Dialog dlg;
    private EditText titleEditText, artistEditText, albumEditText;
    MainActivity act;
    public EditFileTagsDialog(Context ctx, SongItem si){
        this.ctx = ctx;
        this.si = si;
        dlg = new Dialog(ctx);
        Window w = dlg.getWindow();
        if (w != null) {
            w.requestFeature(Window.FEATURE_NO_TITLE);
        }
        dlg.setContentView(R.layout.dlg_edit_file_tags);

        // Initialize Views
        titleEditText = dlg.findViewById(R.id.edit_tag_title);
        artistEditText = dlg.findViewById(R.id.edit_tag_artist);
        albumEditText = dlg.findViewById(R.id.edit_tag_album);

        // Set current values
        titleEditText.setText(si.getTitle());
        artistEditText.setText(si.getArtist());
        albumEditText.setText(si.getAlbum());

        Button saveButton = dlg.findViewById(R.id.save_edit_tags_button);
        Button cancelButton = dlg.findViewById(R.id.cancel_edit_tags_button);

        saveButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                  //  handleSave();
                }
            });

        cancelButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    dlg.dismiss();
                }
            });
    }

    /**
     * Displays the dialog.
     */
    public void show(){
        dlg.show();
    }

    /**
     * Handles saving the edited tags.
     *
    private void handleSave(){
        String newTitle = titleEditText.getText().toString().trim();
        String newArtist = artistEditText.getText().toString().trim();
        String newAlbum = albumEditText.getText().toString().trim();

        if(newTitle.isEmpty() || newArtist.isEmpty() || newAlbum.isEmpty()){
            Toast.makeText(ctx, "All fields must be filled.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = act.updateSongTags(si, newTitle, newArtist, newAlbum);
        if(success){
            Toast.makeText(ctx, "Tags updated successfully.", Toast.LENGTH_SHORT).show();
            dlg.dismiss();
        } else {
            Toast.makeText(ctx, "Failed to update tags.", Toast.LENGTH_SHORT).show();
        }
    }*/
}
