package com.alexa.alexa.utils;

import java.io.File;

public class FileUtils {

    public static boolean isAudioFile(File file) {
        if (file == null || !file.isFile()) {
            return false;
        }
        String name = file.getName().toLowerCase();
        return name.endsWith(".mp3") || name.endsWith(".wav") ||
			name.endsWith(".m4a") || name.endsWith(".aac");
    }

    public static boolean isVideoFile(File file) {
        if (file == null || !file.isFile()) {
            return false;
        }
        String name = file.getName().toLowerCase();
        return name.endsWith(".mp4") || name.endsWith(".mkv") ||
			name.endsWith(".avi") || name.endsWith(".mov");
    }
}
