package com.alexa.alexa.activity;


import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.adapters.ColorAdapter;
import com.alexa.alexa.service.AudioService;
import java.util.HashMap;
import java.util.Map;





public class SettingsActivity extends BaseActivity implements ColorAdapter.OnColorClickListener {
    public static final int requestCode = 333749;
    private Map<String, SettingsTab> tabs = new HashMap<>();
    private LinearLayout tabContainer;
    private boolean isTabOpen = false;
    public static final String PREFS_NAME = "AppPrefs";
    public static final String KEY_ACCENT_COLOR = "accent_color";
    public static final String KEY_THEME_INVERTED = "theme_inverted";

    private Switch themeSwitch;
    private Button btnSave, btnCancel;

    private AudioService audioService;
    private boolean isBound = false;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            AudioService.LocalBinder binder = (AudioService.LocalBinder) service;
            audioService = binder.getService();
            isBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        setThemeable(true);
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean themeInverted = prefs.getBoolean(KEY_THEME_INVERTED, false);
        int accentColor = prefs.getInt(KEY_ACCENT_COLOR, Color.WHITE);
        ThemeManager.setTheme(this, themeInverted, accentColor);

        setContentView(R.layout.activity_settings);
        tabContainer = findViewById(R.id.tabContainer);
        initTabs();

        setupListeners();
    }

    private void initTabs() {
        // Registering each tab
        registerTab("interface", new SettingsTab(getLayoutInflater().inflate(R.layout.tab_interface, null)));
        registerTab("library", new SettingsTab(getLayoutInflater().inflate(R.layout.tab_library, null)));
        registerTab("headset", new SettingsTab(getLayoutInflater().inflate(R.layout.tab_headset, null)));
        registerTab("notifications", new SettingsTab(getLayoutInflater().inflate(R.layout.tab_notifications, null)));

        // Setup button click listeners
        findViewById(R.id.interface_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showTab("interface");
                }
            });
        findViewById(R.id.library_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showTab("library");
                }
            });
        findViewById(R.id.headset_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showTab("headset");
                }
            });
        findViewById(R.id.notifications_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showTab("notifications");
                }
            });
    }

    private void registerTab(String name, SettingsTab tab) {
        tabs.put(name, tab);
    }

    private void showTab(String name) {
        if (tabs.containsKey(name)) {
            SettingsTab tab = tabs.get(name);
            tabContainer.removeAllViews();
            tabContainer.addView(tab.getView());
            isTabOpen = true;

            if ("interface".equals(name)) {
                View interfaceView = tab.getView();
                RecyclerView colorRecyclerView = interfaceView.findViewById(R.id.recyclerView_colors);
                setupColorPicker(colorRecyclerView);
            }
        }
    }

    private void closeTab() {
        tabContainer.removeAllViews();
        isTabOpen = false;
    }

    @Override
    public void onBackPressed() {
        if (isTabOpen) {
            closeTab();
        } else {
            super.onBackPressed();
        }
    }

    private void setupColorPicker(RecyclerView colorRecyclerView) {
        int[] colors = {
            Color.RED, Color.GREEN,Color.WHITE, Color.BLUE,
            Color.BLACK, Color.YELLOW, Color.CYAN, Color.MAGENTA
        };

        colorRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        ColorAdapter colorAdapter = new ColorAdapter(this, colors, this);
        colorRecyclerView.setAdapter(colorAdapter);
    }

    private void setupListeners() {
        themeSwitch = findViewById(R.id.theme_switch);
        btnSave = findViewById(R.id.btn_save);
        btnCancel = findViewById(R.id.btn_cancel);

        themeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
                    editor.putBoolean(KEY_THEME_INVERTED, isChecked);
                    editor.apply();
                    recreateActivity();
                }
            });

        btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveSettings();
                }
            });

        btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
    }

    @Override
    public void onColorClick(int color) {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        editor.putInt(KEY_ACCENT_COLOR, color);
        editor.apply();
        recreateActivity();
    }

    private void recreateActivity() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        finish();
    }

    private void saveSettings() {
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private static class SettingsTab {
        private final View view;

        public SettingsTab(View view) {
            this.view = view;
        }

        public View getView() {
            return view;
        }
    }
}


  
