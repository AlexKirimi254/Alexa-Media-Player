package com.alexa.alexa.menu;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.activity.TagEditorActivity;
import com.alexa.alexa.models.SongItem;
import java.io.ByteArrayOutputStream;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.manager.QueueManager;

public class SongOptions implements View.OnClickListener {

    private MainActivity ctx;
    private SongItem si;
    private RelativeLayout container;
    private TextView title, artist;
    private Dialog dlg;

    public SongOptions(MainActivity ctx, SongItem si) {


        this.ctx = ctx;
        this.si = si;
        dlg = new Dialog(ctx);
        Window w = dlg.getWindow();
        if (w != null) {
            w.requestFeature(Window.FEATURE_NO_TITLE);
        }

        dlg.setContentView(R.layout.dlg_songitem_options);

        title = ftv(R.id.popup_auplayer_songoptions_title);
        artist = ftv(R.id.popup_auplayer_songoptions_artist);

        title.setText(si.getTitle());
        artist.setText(si.getArtist());

        LinearLayout ops = (LinearLayout) fv(R.id.popup_auplayer_songoptions_clk);
        int cc = ops.getChildCount();
        for (int i = 0; i < cc; i++) {
            ops.getChildAt(i).setOnClickListener(this);
        }

        fv(R.id.btn_setA).setOnClickListener(this);
        fv(R.id.btn_setB).setOnClickListener(this);
        fv(R.id.btn_clearAB).setOnClickListener(this);
    }

    private String getFlag(View v) {
        String[] p = getValues(v);
        if (p != null && p.length >= 2) {
            return p[1];
        }
        return null;
    }

    private String[] getValues(View v) {
        if (v.getTag() != null && (v.getTag() instanceof String)) {
            String t = v.getTag().toString();
            return t.split(" ");
        }
        return null;
    }

    private View fv(int resid) {
        return dlg.findViewById(resid);
    }

    private TextView ftv(int resid) {
        return (TextView) fv(resid);
    }

    public void show() {
        dlg.show();
    }

    public void hide() {
        dlg.dismiss();
        title.setText("");
        artist.setText("");
        si = null;
    }

    @Override
    public void onClick(View v) {
        if (v.getTag() != null) {
            String tag = v.getTag().toString();
            if (tag != null) {
                tag = tag.split(" ")[0];
            }
            switch (tag) {
                case "playnext":
                    AudioService.getInstance().addToQueue(si);
					QueueManager.getInstance().addSongToQueue(si);
					// ctx.launchCurrentQueueActivity(); // Launch the CurrentQueue activity after adding to the queue
                    break;

				case "removefromqueue":
					//  AudioService.getInstance().addToQueue(si);
					QueueManager.getInstance().removeSongFromQueue(si);
					// ctx.launchCurrentQueueActivity(); // Launch the CurrentQueue activity after adding to the queue
                    break;	
				case "playall":
					AudioService.getInstance().playAll(); // Uncomment this line if playAll method is implemented
                    break;
                case "resetshuffle":
					AudioService.getInstance().resetShuffle(); // Uncomment this line if playAll method is implemented
                    break;
                case "shuffle":
                    AudioService.getInstance().shuffleAll();
                    break;
                case "addtoplaylist":
                    new AddToPlaylistDialog(ctx,si).show(); // Show the Add to Playlist dialog
                    break;
                case "editfiletags":
					Intent intent = new Intent(ctx, TagEditorActivity.class);
					intent.putExtra("title", si.getTitle());
					intent.putExtra("artist", si.getArtist());
					intent.putExtra("album", si.getAlbum());
					intent.putExtra("genre", si.getGenre());
					intent.putExtra("year", si.getYear());
					intent.putExtra("path", si.getPath());

					// Add the thumbnail to the intent as a byte array
					if (si.getThumbnail() != null) {
						Bitmap thumbnail = si.getThumbnail(); // Assuming getThumbnail returns a Bitmap
						ByteArrayOutputStream stream = new ByteArrayOutputStream();
						thumbnail.compress(Bitmap.CompressFormat.PNG, 100, stream);
						byte[] thumbnailBytes = stream.toByteArray();
						intent.putExtra("thumbnail", thumbnailBytes);
					}

					ctx.startActivity(intent);
					break;

                case "setA":
                    AudioService.getInstance().setRepeatPointA();
                    break;

                case "setB":
                    AudioService.getInstance().setRepeatPointB();
                    break;

                case "clearAB":
                    AudioService.getInstance().clearABRepeat();
                    break;
                case "deletesong":
                    new ConfirmDeleteDialog(ctx, si).show();
                    break;
                default:
                    break;
            }
        }
        hide();
    }


}
