package com.alexa.alexa;
import com.alexa.alexa.models.SongItem;
import java.util.List;

public class FavouritesPlaylist
{
    public static void save(SongItem si){
        //
    }
    
    public static void remove(SongItem si){
        //
    }
    
    public static List<SongItem> get(){
        //
        return null;
    }
}
