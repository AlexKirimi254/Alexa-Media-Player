package com.alexa.alexa.manager;

import com.alexa.alexa.models.SongItem; import java.util.ArrayList; import java.util.List;

public class QueueManager { private static QueueManager instance; private List<SongItem> queue; private List<QueueListener> listeners; private SongItem currentSong; private long totalDuration;

    private QueueManager() {
        queue = new ArrayList<>();
        listeners = new ArrayList<>();
        currentSong = null;
        totalDuration = 0;
    }

    public static synchronized QueueManager getInstance() {
        if (instance == null) {
            instance = new QueueManager();
        }
        return instance;
    }

    public void initQueue() {
        queue.clear();
        currentSong = null;
        totalDuration = 0;
        notifyQueueUpdated();
        notifySongChanged();
    }

    public void playNext() {
        if (!queue.isEmpty()) {
            currentSong = queue.remove(0);
            notifyQueueUpdated();
            notifySongChanged();
        }
    }
	public int getCurrentIndex() {
		if (currentSong == null || queue == null || queue.isEmpty()) {
			return -1; // Indicates no current song or empty queue
		}

		// Search for the current song in the queue
		for (int i = 0; i < queue.size(); i++) {
			if (currentSong.equals(queue.get(i))) {
				return i;
			}
		}

		return -1; // Current song not found in queue
	}
    public SongItem getCurrentSong() {
        return currentSong;
    }

    public void setCurrentSong(SongItem song) {
        currentSong = song;
        notifySongChanged();
    }

    public boolean isQueueEmpty() {
        return queue.isEmpty();
    }

    public void setQueue(List<SongItem> newQueue) {
        queue.clear();
        queue.addAll(newQueue);
        calculateTotalDuration();
        notifyQueueUpdated();
    }

    public void addSongToQueue(SongItem song) {
        queue.add(song);
        calculateTotalDuration();
        notifyQueueUpdated();
    }

    public void removeSongFromQueue(SongItem song) {
        queue.remove(song);
        calculateTotalDuration();
        notifyQueueUpdated();
    }

    public void clearQueue() {
        queue.clear();
        currentSong = null;
        totalDuration = 0;
        notifyQueueUpdated();
        notifySongChanged();
    }

    private void calculateTotalDuration() {
        totalDuration = 0;
        for (SongItem song : queue) {
            totalDuration += song.getDuration();
        }
    }

    public List<SongItem> getQueue() {
        return queue;
    }

    public void addQueueListener(QueueListener listener) {
        listeners.add(listener);
    }

    public void removeQueueListener(QueueListener listener) {
        listeners.remove(listener);
    }

    private void notifyQueueUpdated() {
        for (QueueListener listener : listeners) {
            listener.onQueueUpdated(queue);
        }
    }

    private void notifySongChanged() {
        for (QueueListener listener : listeners) {
            listener.onSongChanged(currentSong);
        }
    }

    public interface QueueListener {
        void onQueueUpdated(List<SongItem> updatedQueue);
        void onSongChanged(SongItem currentSong);
    }

}


