package com.alexa.alexa.tabs;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.SongsQueueAdapter;
import com.alexa.alexa.interfaces.SongTouchHelperCallback;
import com.alexa.alexa.manager.QueueManager;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.view.tabview.Tab;
import java.util.ArrayList;
import java.util.List;

public class SongsQueueTab extends Tab implements QueueManager.QueueListener {
    private View root;
    private RecyclerView recyclerView;
    private SongsQueueAdapter adapter;
    private MainActivity activity;
    private Button clearQueueButton;
    private TextView totalDurationView;
    private static final String PREFS_NAME = "AppPrefs";
    private static final String GRID_SIZE_KEY = "grid_size";
    private int gridSize;

    public SongsQueueTab(final MainActivity act) {
        this.activity = act;
        root = LayoutInflater.from(act).inflate(R.layout.default_recyclerview_queue, null, false);

        recyclerView = root.findViewById(R.id.recycler_view);
        clearQueueButton = root.findViewById(R.id.btn_clear_queue);
        totalDurationView = root.findViewById(R.id.queue_total_duration);

        recyclerView.setLayoutManager(new LinearLayoutManager(act));

        adapter = new SongsQueueAdapter(act, QueueManager.getInstance().getQueue(), totalDurationView);
        recyclerView.setAdapter(adapter);

        SharedPreferences prefs = act.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gridSize = prefs.getInt(GRID_SIZE_KEY, 2);

        setGridSize(gridSize);

        ItemTouchHelper touchHelper = new ItemTouchHelper(new SongTouchHelperCallback(adapter));
        touchHelper.attachToRecyclerView(recyclerView);

        clearQueueButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					clearQueue();
					AudioService.getInstance().clearQueue();
				}
			});

        QueueManager.getInstance().addQueueListener(this);
    }

    public void setGridSize(int size) {
        gridSize = size;
        recyclerView.setLayoutManager(new GridLayoutManager(activity, gridSize));
        adapter.notifyDataSetChanged();

        SharedPreferences prefs = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(GRID_SIZE_KEY, gridSize).apply();
    }

    public int getGridSize() {
        return gridSize;
    }

    @Override
    public void onQueueUpdated(List<SongItem> updatedQueue) {
        if (adapter != null) {
            adapter.update(updatedQueue);
        }
    }

    @Override
    public void onSongChanged(SongItem currentSong) {
        if (adapter != null) {
            adapter.setCurrent(currentSong);
        }
    }

    private void clearQueue() {
        QueueManager.getInstance().clearQueue();
        if (adapter != null) {
            adapter.update(new ArrayList<SongItem>());
        }
    }

    @Override
    public View getView() {
        return root;
    }

    public void cleanup() {
        QueueManager.getInstance().removeQueueListener(this);
    }
}

