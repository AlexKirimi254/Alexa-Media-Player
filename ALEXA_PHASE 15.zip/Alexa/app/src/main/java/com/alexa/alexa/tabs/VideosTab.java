package com.alexa.alexa.tabs;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.activityAdapters.VideoListAdapter;
import com.alexa.alexa.utils.VideoUtils;
import com.alexa.alexa.view.tabview.Tab;
import java.util.List;

public class VideosTab extends Tab {
    private View root;
    private VideoListAdapter adapter;
    private RecyclerView recyclerView;
    private MainActivity act;

    public VideosTab(MainActivity ctx) {
        act = ctx;
        root = LayoutInflater.from(ctx).inflate(R.layout.default_recyclerview, null, false);
        recyclerView = root.findViewById(R.id.recycler_view);
        adapter = new VideoListAdapter(ctx);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(ctx));

        // Set up item click listener for adapter
        adapter.setOnItemClickListener(new VideoListAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(String videoPath) {
                    // Display a toast message with the video path
                    Toast.makeText(act, "Playing video: " + videoPath, Toast.LENGTH_SHORT).show();
                    // Trigger video playback in MainActivity
                    act.playVideo(videoPath);  // Assuming MainActivity has a playVideo method
                }
            });

        // Load videos (This could be moved to a method or onTabShown depending on when you want to load)
        loadAllVideos();
    }

    private void loadAllVideos() {
        // Logic to query MediaStore for videos and update the adapter
        List<String> videoPaths = VideoUtils.getAllVideos(act);  // VideoUtils fetches all video file paths
        adapter.update(videoPaths);  // Updates the adapter with the video paths
    }

    @Override
    public void onTabShown() {
        super.onTabShown();
        loadAllVideos(); // Refresh videos when the tab is shown
    }

    @Override
    public View getView() {
        return root;
    }
}

