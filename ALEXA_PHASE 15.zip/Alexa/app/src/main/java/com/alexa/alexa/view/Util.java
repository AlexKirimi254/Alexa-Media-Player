package com.alexa.alexa.view;
import android.graphics.*;

public class Util
{
    public Util(){}
    
    public static int getColor(String hexValue){
        return Color.parseColor(hexValue);
    }
}
