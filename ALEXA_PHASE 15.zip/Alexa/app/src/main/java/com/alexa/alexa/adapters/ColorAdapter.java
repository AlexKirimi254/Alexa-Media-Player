package com.alexa.alexa.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;




import androidx.recyclerview.widget.RecyclerView;

public class ColorAdapter extends RecyclerView.Adapter<ColorAdapter.ColorViewHolder> {

    private Context context;
    private int[] colors;
    private OnColorClickListener onColorClickListener;

    public interface OnColorClickListener {
        void onColorClick(int color);
    }

    public ColorAdapter(Context context, int[] colors, OnColorClickListener listener) {
        this.context = context;
        this.colors = colors;
        this.onColorClickListener = listener;
    }

    @Override
    public ColorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.color_item, parent, false);
        return new ColorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ColorViewHolder holder, int position) {
        final int color = colors[position];
        holder.colorView.setBackgroundColor(color);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onColorClickListener.onColorClick(color);
                }
            });
    }

    @Override
    public int getItemCount() {
        return colors.length;
    }

    public static class ColorViewHolder extends RecyclerView.ViewHolder {
        ImageView colorView;

        public ColorViewHolder(View itemView) {
            super(itemView);
            colorView = itemView.findViewById(R.id.color_view);
        }
    }
}

