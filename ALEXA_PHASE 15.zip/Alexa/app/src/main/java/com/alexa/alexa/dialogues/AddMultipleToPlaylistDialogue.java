package com.alexa.alexa.dialogues;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.PlaylistAdapter;
import com.alexa.alexa.manager.PlaylistManager;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;
import java.util.ArrayList;
import java.util.List;

public class AddMultipleToPlaylistDialogue {

    private final Context context;
    private final PlaylistManager playlistManager;
    private final List<SongItem> songs;
    private AlertDialog dialog;

    public AddMultipleToPlaylistDialogue(Context context, List<SongItem> songs) {
        this.context = context;
        this.songs = songs;
        this.playlistManager = PlaylistManager.getInstance();
    }

    public void show() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Add to Playlist");

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_add_to_playlist, null);
        builder.setView(view);

        final RecyclerView playlistsRecyclerView = view.findViewById(R.id.recycler_view_playlists);
        Button cancelButton = view.findViewById(R.id.button_cancel_add_to_playlist);
        Button createNewPlaylistButton = view.findViewById(R.id.button_create_new_playlist);

        final List<Playlist> playlists = playlistManager.getPlaylists();

        if (context instanceof MainActivity) {
            playlistsRecyclerView.setLayoutManager(new LinearLayoutManager(context));
            PlaylistAdapter adapter = new PlaylistAdapter((MainActivity) context, playlists, new PlaylistAdapter.OnItemClickListener() {
					@Override
					public void onItemClick(Playlist playlist) {
						handleAddToPlaylist(playlist);
					}
				});
            playlistsRecyclerView.setAdapter(adapter);
        } else {
            Log.e("AddMultipleToPlaylist", "Context is not an instance of MainActivity.");
            return;
        }

        dialog = builder.create();

        cancelButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if (dialog != null && dialog.isShowing()) {
						dialog.dismiss();
					}
				}
			});

        createNewPlaylistButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					showCreateNewPlaylistDialog();
				}
			});

        dialog.show();
    }

    private void handleAddToPlaylist(Playlist playlist) {
        boolean allAdded = true;
        for (SongItem song : songs) {
            if (!playlistManager.addSongToPlaylist(playlist.getName(), song)) {
                allAdded = false;
            }
        }

        if (allAdded) {
            Toast.makeText(context, "Added to '" + playlist.getName() + "'.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Some songs failed to add to '" + playlist.getName() + "'.", Toast.LENGTH_SHORT).show();
        }

        if (context instanceof MainActivity) {
            ((MainActivity) context).refreshPlaylistsTab();
        }

        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    private void showCreateNewPlaylistDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Create New Playlist");

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_create_playlist, null);
        builder.setView(view);

        final EditText playlistNameInput = view.findViewById(R.id.edittext_playlist_name);
        Button createButton = view.findViewById(R.id.button_create_playlist);
        Button cancelButton = view.findViewById(R.id.button_cancel_create_playlist);

        final AlertDialog createDialog = builder.create();

        createButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					String playlistName = playlistNameInput.getText().toString().trim();
					if (!playlistName.isEmpty()) {
						Playlist newPlaylist = playlistManager.createPlaylist(playlistName);
						if (newPlaylist != null) {
							handleAddToPlaylist(newPlaylist);
						} else {
							Toast.makeText(context, "Failed to create playlist. It may already exist.", Toast.LENGTH_SHORT).show();
						}
						createDialog.dismiss();
					} else {
						Toast.makeText(context, "Playlist name cannot be empty.", Toast.LENGTH_SHORT).show();
					}
				}
			});

        cancelButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					createDialog.dismiss();
				}
			});

        createDialog.show();
    }
}
