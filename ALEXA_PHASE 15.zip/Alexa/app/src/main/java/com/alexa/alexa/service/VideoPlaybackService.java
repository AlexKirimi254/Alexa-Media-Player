package com.alexa.alexa.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.SurfaceHolder;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.VideoPlayerActivity;
import java.io.IOException;
import java.util.ArrayList;

public class VideoPlaybackService extends Service implements 
MediaPlayer.OnPreparedListener,
MediaPlayer.OnCompletionListener,
MediaPlayer.OnErrorListener,
MediaPlayer.OnVideoSizeChangedListener,
AudioManager.OnAudioFocusChangeListener {

    private static final String TAG = "VideoPlaybackService";
    private static final String PREF_PLAYBACK_MODE = "playback_mode";
    public static final int MODE_VIDEO = 0;
    public static final int MODE_AUDIO_ONLY = 1;
    private static final String ACTION_STOP = "com.alexa.alexa.action.STOP";
    private static final String ACTION_PAUSE = "com.alexa.alexa.action.PAUSE";
    private static final String ACTION_PLAY = "com.alexa.alexa.action.PLAY";
    private static final int NOTIFICATION_ID = 101;
    private static final String CHANNEL_ID = "media_playback_channel";

    private final IBinder binder = new LocalBinder();
    private MediaPlayer mediaPlayer;
    private ArrayList<String> videoList;
    private int currentIndex = 0;
    private int currentPlaybackMode = MODE_VIDEO;
    private VideoPlayerActivity.PlaybackStateListener playbackListener;
    private SurfaceHolder currentSurfaceHolder;
    private AudioManager audioManager;
    private boolean isPausedByTransientLossOfFocus = false;
    private boolean isPrepared = false;

    public class LocalBinder extends Binder {
        public VideoPlaybackService getService() {
            return VideoPlaybackService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Service created");
        initializeMediaPlayer();
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        currentPlaybackMode = prefs.getInt(PREF_PLAYBACK_MODE, MODE_VIDEO);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case ACTION_STOP:
                    stopSelf();
                    break;
                case ACTION_PAUSE:
                    pause();
                    break;
                case ACTION_PLAY:
                    resume();
                    break;
					
				case "NEXT":
					playNextVideo();
					break;
				case "PREVIOUS":
					playPreviousVideo();
					break;
					
            }
        } else if (intent != null) {
            // Handle normal start with extras
            if (intent.hasExtra("videoList")) {
                videoList = intent.getStringArrayListExtra("videoList");
                currentIndex = intent.getIntExtra("videoIndex", 0);
                currentPlaybackMode = intent.getIntExtra("playbackMode", currentPlaybackMode);
                playCurrentVideo();
            }
        }
        return START_STICKY;
    }

    private void initializeMediaPlayer() {
        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.setOnPreparedListener(this);
            mediaPlayer.setOnCompletionListener(this);
            mediaPlayer.setOnErrorListener(this);
            mediaPlayer.setOnVideoSizeChangedListener(this);
        } else {
            mediaPlayer.reset();
            isPrepared = false;
        }
    }

    private boolean requestAudioFocus() {
        int result = audioManager.requestAudioFocus(
            this,
            AudioManager.STREAM_MUSIC,
            AudioManager.AUDIOFOCUS_GAIN);
        return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    @Override
    public void onAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_GAIN:
                if (isPausedByTransientLossOfFocus && mediaPlayer != null && !mediaPlayer.isPlaying()) {
                    resume();
                    isPausedByTransientLossOfFocus = false;
                }
                mediaPlayer.setVolume(1.0f, 1.0f);
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                pause();
                isPausedByTransientLossOfFocus = true;
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                mediaPlayer.setVolume(0.1f, 0.1f);
                break;
        }
    }

    public void setVideoList(ArrayList<String> videoList, int index) {
        this.videoList = videoList;
        this.currentIndex = index;
        playCurrentVideo();
    }

    public void setPlaybackMode(int mode) {
        if (mode != currentPlaybackMode) {
            currentPlaybackMode = mode;
            updatePlaybackMode();

            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            prefs.edit().putInt(PREF_PLAYBACK_MODE, currentPlaybackMode).apply();

            if (playbackListener != null) {
                playbackListener.onPlaybackModeChanged(currentPlaybackMode);
            }

            updateNotification();
        }
    }

    private void updatePlaybackMode() {
        if (mediaPlayer != null) {
            if (currentPlaybackMode == MODE_AUDIO_ONLY) {
                mediaPlayer.setScreenOnWhilePlaying(false);
                mediaPlayer.setDisplay(null);
            } else {
                mediaPlayer.setScreenOnWhilePlaying(true);
                if (currentSurfaceHolder != null) {
                    mediaPlayer.setDisplay(currentSurfaceHolder);
                }
            }
        }
    }

    private void playCurrentVideo() {
        if (videoList == null || videoList.isEmpty() || currentIndex < 0 || currentIndex >= videoList.size()) {
            Log.e(TAG, "Invalid video list or index");
            notifyPlaybackError();
            return;
        }

        if (!requestAudioFocus()) {
            Log.e(TAG, "Failed to get audio focus");
            notifyPlaybackError();
            return;
        }

        String videoPath = videoList.get(currentIndex);
        try {
            initializeMediaPlayer();
            mediaPlayer.setDataSource(videoPath);
            mediaPlayer.prepareAsync();
            updateNotification();
            notifyPlaybackStarted();
        } catch (IOException e) {
            Log.e(TAG, "Error setting data source", e);
            notifyPlaybackError();
        }
    }

    private void updateNotification() {
        if (currentPlaybackMode == MODE_AUDIO_ONLY && isPrepared) {
            startForegroundService();
        } else {
            stopForeground(false);
        }
    }

    private void startForegroundService() {
        createNotificationChannel();
        Notification notification = buildMediaNotification();
        startForeground(NOTIFICATION_ID, notification);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Media Playback",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Media playback controls");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification buildMediaNotification() {
		RemoteViews customView = new RemoteViews(getPackageName(), R.layout.notification_media);

		// Extract title from file path
		String fullPath = (videoList != null && currentIndex < videoList.size())
            ? videoList.get(currentIndex) : null;

		String contentTitle = "Media Player";
		String contentText = "Playing media";

		if (fullPath != null) {
			int lastSlash = fullPath.lastIndexOf('/');
			String fileName = (lastSlash != -1 && lastSlash < fullPath.length() - 1)
                ? fullPath.substring(lastSlash + 1)
                : fullPath;

			int dotIndex = fileName.lastIndexOf('.');
			if (dotIndex > 0) {
				fileName = fileName.substring(0, dotIndex);
			}
			contentText = fileName;
		}

		// Set text and icon
		customView.setTextViewText(R.id.notification_title, contentTitle);
		customView.setTextViewText(R.id.notification_text, contentText);
		customView.setImageViewResource(R.id.btn_play_pause, isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);

		// Setup intents
		PendingIntent playPauseIntent = PendingIntent.getService(
            this, 0,
            new Intent(this, VideoPlaybackService.class).setAction(isPlaying() ? ACTION_PAUSE : ACTION_PLAY),
            PendingIntent.FLAG_IMMUTABLE);

		PendingIntent stopIntent = PendingIntent.getService(
            this, 1,
            new Intent(this, VideoPlaybackService.class).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE);

		PendingIntent nextIntent = PendingIntent.getService(
            this, 2,
            new Intent(this, VideoPlaybackService.class).setAction("NEXT"),
            PendingIntent.FLAG_IMMUTABLE);

		PendingIntent prevIntent = PendingIntent.getService(
            this, 3,
            new Intent(this, VideoPlaybackService.class).setAction("PREVIOUS"),
            PendingIntent.FLAG_IMMUTABLE);

		// Bind intents to buttons
		customView.setOnClickPendingIntent(R.id.btn_play_pause, playPauseIntent);
		customView.setOnClickPendingIntent(R.id.btn_stop, stopIntent);
		customView.setOnClickPendingIntent(R.id.btn_next, nextIntent);
		customView.setOnClickPendingIntent(R.id.btn_previous, prevIntent);

		// Content intent to reopen player
		Intent contentIntent = new Intent(this, VideoPlayerActivity.class);
		contentIntent.putExtra("from_notification", true);
		contentIntent.putStringArrayListExtra("videoList", videoList);
		contentIntent.putExtra("videoIndex", currentIndex);

		PendingIntent contentPendingIntent = PendingIntent.getActivity(
            this, 99,
            contentIntent,
            PendingIntent.FLAG_IMMUTABLE);

		return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_audio)
            .setCustomContentView(customView)
            .setContentIntent(contentPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build();
	}

    public void start() {
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            if (requestAudioFocus()) {
                if (isPrepared) {
                    mediaPlayer.start();
                    updateNotification();
                    notifyPlaybackStarted();
                }
            }
        }
    }

    public void pause() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            updateNotification();
            notifyPlaybackPaused();
        }
    }

    public void resume() {
        start();
    }

    public void stop() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            updateNotification();
            notifyPlaybackStopped();
            audioManager.abandonAudioFocus(this);
        }
    }

    public void seekTo(int position) {
        if (mediaPlayer != null && isPrepared) {
            mediaPlayer.seekTo(position);
        }
    }

    public void playNextVideo() {
        if (videoList == null || videoList.isEmpty()) {
            return;
        }
        currentIndex = (currentIndex + 1) % videoList.size();
        playCurrentVideo();
    }

    public void playPreviousVideo() {
        if (videoList == null || videoList.isEmpty()) {
            return;
        }
        currentIndex = (currentIndex - 1 + videoList.size()) % videoList.size();
        playCurrentVideo();
    }

    public boolean isPlaying() {
        return mediaPlayer != null && mediaPlayer.isPlaying();
    }

    public int getCurrentPosition() {
        return mediaPlayer != null && isPrepared ? mediaPlayer.getCurrentPosition() : 0;
    }

    public int getDuration() {
        return mediaPlayer != null && isPrepared ? mediaPlayer.getDuration() : 0;
    }

    public ArrayList<String> getVideoList() {
        return videoList;
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    public int getPlaybackMode() {
        return currentPlaybackMode;
    }

    public void setDisplay(SurfaceHolder holder) {
        currentSurfaceHolder = holder;
        if (mediaPlayer != null) {
            if (currentPlaybackMode == MODE_VIDEO && holder != null) {
                mediaPlayer.setDisplay(holder);
            } else {
                mediaPlayer.setDisplay(null);
            }
        }
    }

    public MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }

    public void setPlaybackStateListener(VideoPlayerActivity.PlaybackStateListener listener) {
        this.playbackListener = listener;
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        Log.d(TAG, "MediaPlayer prepared");
        isPrepared = true;
        mp.start();
        updateNotification();
        notifyPlaybackStarted();
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        Log.d(TAG, "Playback completed");
        notifyPlaybackCompleted();
        playNextVideo();
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        Log.e(TAG, "MediaPlayer error: " + what + ", " + extra);
        notifyPlaybackError();
        return true;
    }

    @Override
    public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
        Log.d(TAG, "Video size changed: " + width + "x" + height);
        if (playbackListener != null) {
            playbackListener.onPlaybackStarted();
        }
    }

    private void notifyPlaybackStarted() {
        if (playbackListener != null) {
            playbackListener.onPlaybackStarted();
        }
    }

    private void notifyPlaybackPaused() {
        if (playbackListener != null) {
            playbackListener.onPlaybackPaused();
        }
    }

    private void notifyPlaybackStopped() {
        if (playbackListener != null) {
            playbackListener.onPlaybackStopped();
        }
    }

    private void notifyPlaybackCompleted() {
        if (playbackListener != null) {
            playbackListener.onPlaybackCompleted();
        }
    }

    private void notifyPlaybackError() {
        if (playbackListener != null) {
            playbackListener.onPlaybackError();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Service destroyed");
        stopForeground(true);
        audioManager.abandonAudioFocus(this);
        releaseMediaPlayer();
    }

    private void releaseMediaPlayer() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
            isPrepared = false;
        }
    }
}
