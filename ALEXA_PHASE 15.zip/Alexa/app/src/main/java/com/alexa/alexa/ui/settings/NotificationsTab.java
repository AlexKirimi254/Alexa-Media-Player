package com.alexa.alexa.ui.settings;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.Switch;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.SettingsActivity;

public class NotificationsTab extends SettingsTab {

    public NotificationsTab(SettingsActivity act) {
        super(act);
    }

    @Override
    public View getView() {
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.tab_notifications_settings, null);

        Switch notificationSwitch = view.findViewById(R.id.switch_notifications);
        notificationSwitch.setChecked(true);

        return view;
    }
}
