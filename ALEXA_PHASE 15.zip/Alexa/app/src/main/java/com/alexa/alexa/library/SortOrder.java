package com.alexa.alexa.library;
public class SortOrder {

    public static class SongSortOrder {
        public static final String SONG_A_Z = "TITLE ASC";
        public static final String SONG_Z_A = "TITLE DESC";
        public static final String SONG_ARTIST_A_Z = "ARTIST ASC";
        public static final String SONG_ARTIST_Z_A = "ARTIST DESC";
        public static final String SONG_YEAR_ASC = "YEAR ASC";
        public static final String SONG_YEAR_DESC = "YEAR DESC";
        public static final String SONG_DATE_ASC = "DATE_ADDED ASC";
        public static final String SONG_DATE_DESC = "DATE_ADDED DESC";
        public static final String SONG_DURATION_ASC = "DURATION ASC";
        public static final String SONG_DURATION_DESC = "DURATION DESC";
    }

    private static String currentSortOrder = SongSortOrder.SONG_A_Z;

    public static String getCurrentSortOrder() {
        return currentSortOrder;
    }

    public static void setSortOrder(String sortOrder) {
        currentSortOrder = sortOrder;
    }
}
