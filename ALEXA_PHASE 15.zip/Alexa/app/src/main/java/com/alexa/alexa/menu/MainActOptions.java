package com.alexa.alexa.menu;

import android.content.DialogInterface;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import com.alexa.alexa.R;
import com.alexa.alexa.XApp;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.activity.SettingsActivity;
import com.alexa.alexa.helper.SortOrder;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import com.alexa.alexa.service.AudioService;

public class MainActOptions extends MDialog {
    private MainActivity act;

    public MainActOptions(MainActivity a) {
        super(a, R.layout.dlg_mainact_options);
        act = a;
        init();
    }

    void init() {
        // Initialize existing options
        setClickable(R.id.mainact_options_settings);
        setClickable(R.id.mainact_options_exit);

        // Initialize the grid size options dynamically
        setupGridSizeOptions();

        // Initialize sort options dynamically
        setupSortOptions();
    }

    private void setupGridSizeOptions() {
        RadioGroup gridSizeGroup = findViewById(R.id.grid_size_group);

        if (gridSizeGroup != null) {
            int currentGridSize = act.getSongsListTab().getGridSize();

            // Dynamically add radio buttons for grid size
            String[] options = {"List (1 column)", "Grid (2 columns)", "Grid (3 columns)"};
            int[] gridSizes = {1, 2, 3};

            for (int i = 0; i < options.length; i++) {
                RadioButton radioButton = (RadioButton) LayoutInflater.from(act).inflate(R.layout.radio_button, gridSizeGroup, false);
                radioButton.setText(options[i]);
                radioButton.setId(gridSizes[i]);
                radioButton.setChecked(gridSizes[i] == currentGridSize);

                // Add to the RadioGroup
                gridSizeGroup.addView(radioButton);
            }

            // Handle grid size selection
            gridSizeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
					@Override
					public void onCheckedChanged(RadioGroup group, int checkedId) {
						act.getSongsListTab().setGridSize(checkedId);
						act.getSongsQueueTab().setGridSize(checkedId);
						act.getArtistsTab().setGridSize(checkedId);
						act.getAlbumsTab().setGridSize(checkedId);
						act.getPlayListTab().setGridSize(checkedId);
						// Dismiss the dialog after selection
						dismiss();
					}
				});
        }
    }

    private void setupSortOptions() {
        RadioGroup sortGroup = findViewById(R.id.sort_group); // Add a RadioGroup in your dialog layout

        if (sortGroup != null) {
            // Define sort options and their corresponding sort orders
            String[] sortOptions = {"Newest", "Oldest", "Artist A-Z", "Artist Z-A", "Album A-Z", "Album Z-A", "Duration Ascending", "Duration Descending"};
            final String[] sortOrders = {
                SortOrder.SongSortOrder.SONG_DATE,
                SortOrder.SongSortOrder.SONG_DATE_ASC,
                SortOrder.ArtistSortOrder.ARTIST_A_Z,
                SortOrder.ArtistSortOrder.ARTIST_Z_A,
                SortOrder.AlbumSortOrder.ALBUM_A_Z,
                SortOrder.AlbumSortOrder.ALBUM_Z_A,
                SortOrder.SongSortOrder.SONG_DURATION_ASC,
                SortOrder.SongSortOrder.SONG_DURATION
            };

            // Add sort options as RadioButtons
            for (int i = 0; i < sortOptions.length; i++) {
                RadioButton radioButton = (RadioButton) LayoutInflater.from(act).inflate(R.layout.radio_button, sortGroup, false);
                radioButton.setText(sortOptions[i]);
                radioButton.setId(i); // Unique ID for each option

                // Add the RadioButton to the RadioGroup
                sortGroup.addView(radioButton);
            }

            // Load the saved sort order from SharedPreferences
            int savedSortOrderId = getSavedSortOrderId();
            sortGroup.check(savedSortOrderId);

            // Handle sort option selection
            sortGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

					private static final int order = 0;
					@Override
					public void onCheckedChanged(RadioGroup group, int checkedId) {
						// Save the selected sort option to SharedPreferences
						saveSortOrderId(checkedId);

						// Map ID to sort order and apply it
						String selectedSortOrder = sortOrders[checkedId];
						act.getSongsListTab().setSortOrder(selectedSortOrder); // Pass to SongsListTab
						;
						// Dismiss the dialog after selection
						dismiss();
					}
				});
        }
    }

    private void saveSortOrderId(int sortOrderId) {
        SharedPreferences sharedPreferences = act.getSharedPreferences("SortPreferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("sort_order", sortOrderId); // Save the selected sort option ID
        editor.apply();
    }

    private int getSavedSortOrderId() {
        SharedPreferences sharedPreferences = act.getSharedPreferences("SortPreferences", Context.MODE_PRIVATE);
        return sharedPreferences.getInt("sort_order", 1); // Default to the first option if not found
    }

    @Override
    public void onShow(DialogInterface i) {
        getWindow().setGravity(Gravity.RIGHT | Gravity.TOP);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.mainact_options_settings:
                act.startActivity(SettingsActivity.class);
                break;
            case R.id.mainact_options_exit:
                XApp.exit();
                break;
        }
        dismiss();
    }
}




