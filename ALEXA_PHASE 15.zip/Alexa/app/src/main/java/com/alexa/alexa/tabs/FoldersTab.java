package com.alexa.alexa.tabs;

import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activity.FolderMediaActivity;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.view.tabview.Tab;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FoldersTab extends Tab {

    private MainActivity act;
    private View root;
    private RecyclerView recyclerView;
    private FolderAdapter adapter;
    private List<File> folderList = new ArrayList<>();

    private static final String PREFS_NAME = "AppPrefs";
    private static final String GRID_SIZE_KEY = "folder_grid_size";
    private int gridSize = 2;

    public FoldersTab(MainActivity act) {
        this.act = act;
        root = LayoutInflater.from(act).inflate(R.layout.default_recyclerview, null, false);
        recyclerView = root.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(act, gridSize));

        adapter = new FolderAdapter(folderList);
        recyclerView.setAdapter(adapter);

        loadRootFolders();
    }

    public void setGridSize(int size) {
        gridSize = size;
        recyclerView.setLayoutManager(new GridLayoutManager(act, gridSize));
        act.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putInt(GRID_SIZE_KEY, gridSize).apply();
    }

    private void loadRootFolders() {
        folderList.clear();
        File internal = Environment.getExternalStorageDirectory();
        if (internal != null && internal.exists()) {
            folderList.add(internal);
        }

        File[] externalDirs = act.getExternalFilesDirs(null);
        for (File dir : externalDirs) {
            if (dir != null && Environment.isExternalStorageRemovable(dir)) {
                File root = dir.getParentFile().getParentFile().getParentFile().getParentFile(); // Navigate to mount point
                if (root.exists() && !folderList.contains(root)) {
                    folderList.add(root);
                }
            }
        }

        adapter.notifyDataSetChanged();
    }

    @Override
    public View getView() {
        return root;
    }

    @Override
    public void onApplyTheme(ThemeManager.Theme theme) {
        // Optional
    }

    private class FolderAdapter extends RecyclerView.Adapter<FolderAdapter.FolderViewHolder> {

        private List<File> folders;

        public FolderAdapter(List<File> folders) {
            this.folders = folders;
        }

        @Override
        public FolderViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(act).inflate(R.layout.item_folder, parent, false);
            return new FolderViewHolder(view);
        }

        @Override
        public void onBindViewHolder(FolderViewHolder holder, int position) {
            holder.bind(folders.get(position));
        }

        @Override
        public int getItemCount() {
            return folders.size();
        }

        class FolderViewHolder extends RecyclerView.ViewHolder {

            private TextView folderName;

            public FolderViewHolder(View itemView) {
                super(itemView);
                folderName = itemView.findViewById(R.id.folder_name);
            }

            public void bind(final File folder) {
                folderName.setText(folder.getName());
                itemView.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							Intent intent = new Intent(act, FolderMediaActivity.class);
							intent.putExtra("folder_path", folder.getAbsolutePath());
							act.startActivity(intent);
						}
					});
            }
        }
    }
}
