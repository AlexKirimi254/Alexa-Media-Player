package com.alexa.alexa.models;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;
import com.alexa.alexa.utils.BitmapUtils;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SongItem implements Comparable<SongItem>, Parcelable {

    public String id = "";
    public String title = "";
    public String artist = "";
    public String path = "";
    public String album = "";
    public long duration = 0;
    private boolean updated = false;
    public long artId;
    private int songcount;
    private String genre = "";
    private String lyrics = "";
    private String trackNumber = "";
    private String composer = "";
    private String mimeType = "";
    private String bitrate = "";
    private String albumArtist = "";
    private int year;
    private long dateAdded;
    private long ids;
    private String iconPath = "";
    private boolean isVideo; // Indicates if the item is a video (true) or audio (false)

    // Default Constructor
    public SongItem() {
        this.isVideo = false; // Default to audio
    }

    // Constructor for creating SongItem with minimal required fields
    public SongItem(String title, String path, String artist, String album, long duration, boolean isVideo) {
        this.title = title != null ? title : "";
        this.path = path != null ? path : "";
        this.artist = artist != null ? artist : "";
        this.album = album != null ? album : "";
        this.duration = duration;
        this.isVideo = isVideo;
    }

    // Parcelable constructor
    protected SongItem(Parcel in) {
        id = in.readString();
        title = in.readString();
        artist = in.readString();
        path = in.readString();
        album = in.readString();
        duration = in.readLong();
        updated = in.readByte() != 0;
        artId = in.readLong();
        songcount = in.readInt();
        genre = in.readString();
        lyrics = in.readString();
        trackNumber = in.readString();
        composer = in.readString();
        mimeType = in.readString();
        bitrate = in.readString();
        albumArtist = in.readString();
        year = in.readInt();
        dateAdded = in.readLong();
        ids = in.readLong();
        iconPath = in.readString();
        isVideo = in.readByte() != 0;
    }

    // Parcelable implementation
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(title);
        dest.writeString(artist);
        dest.writeString(path);
        dest.writeString(album);
        dest.writeLong(duration);
        dest.writeByte((byte) (updated ? 1 : 0));
        dest.writeLong(artId);
        dest.writeInt(songcount);
        dest.writeString(genre);
        dest.writeString(lyrics);
        dest.writeString(trackNumber);
        dest.writeString(composer);
        dest.writeString(mimeType);
        dest.writeString(bitrate);
        dest.writeString(albumArtist);
        dest.writeInt(year);
        dest.writeLong(dateAdded);
        dest.writeLong(ids);
        dest.writeString(iconPath);
        dest.writeByte((byte) (isVideo ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<SongItem> CREATOR = new Creator<SongItem>() {
        @Override
        public SongItem createFromParcel(Parcel in) {
            return new SongItem(in);
        }

        @Override
        public SongItem[] newArray(int size) {
            return new SongItem[size];
        }
    };

    // Comparable implementation - Compare by title, then artist if titles are equal
    @Override
    public int compareTo(SongItem other) {
        int titleComparison = this.title.compareToIgnoreCase(other.title);
        if (titleComparison == 0) {
            return this.artist.compareToIgnoreCase(other.artist);
        }
        return titleComparison;
    }

    // Getter and Setter methods
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title != null ? title : "";
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist != null ? artist : "";
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path != null ? path : "";
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album != null ? album : "";
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public String getIconPath() {
        return iconPath;
    }

    public void setIconPath(String iconPath) {
        this.iconPath = iconPath != null ? iconPath : "";
    }

    public boolean isVideo() {
        return isVideo;
    }

    public void setVideo(boolean isVideo) {
        this.isVideo = isVideo;
    }

    public boolean isUpdated() {
        return updated;
    }

    public void setUpdated(boolean updated) {
        this.updated = updated;
    }

    public long getAlbumId() {
        return artId;
    }

    public void setAlbumId(long albumId) {
        this.artId = albumId;
    }

    public int getSongCount() {
        return songcount;
    }

    public void setSongCount(int songcount) {
        this.songcount = songcount;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre != null ? genre : "";
    }

    public String getLyrics() {
        return lyrics;
    }

    public void setLyrics(String lyrics) {
        this.lyrics = lyrics != null ? lyrics : "";
    }

    public String getTrackNumber() {
        return trackNumber;
    }

    public void setTrackNumber(String trackNumber) {
        this.trackNumber = trackNumber != null ? trackNumber : "";
    }

    public String getComposer() {
        return composer;
    }

    public void setComposer(String composer) {
        this.composer = composer != null ? composer : "";
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType != null ? mimeType : "";
    }

    public String getBitrate() {
        return bitrate;
    }

    public void setBitrate(String bitrate) {
        this.bitrate = bitrate != null ? bitrate : "";
    }

    public String getAlbumArtist() {
        return albumArtist;
    }

    public void setAlbumArtist(String albumArtist) {
        this.albumArtist = albumArtist != null ? albumArtist : "";
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public long getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(long dateAdded) {
        this.dateAdded = dateAdded;
    }

    public long getIds() {
        return ids;
    }

    public void setIds(long ids) {
        this.ids = ids;
    }

    // Method to format duration in mm:ss format
    public String getFormattedDuration() {
        if (duration <= 0) {
            return "00:00";
        }
        long minutes = duration / 60000;
        long seconds = (duration % 60000) / 1000;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    // Method for deep copying the SongItem object
    public SongItem copy() {
        SongItem copy = new SongItem();
        copy.id = this.id;
        copy.title = this.title;
        copy.artist = this.artist;
        copy.path = this.path;
        copy.album = this.album;
        copy.duration = this.duration;
        copy.updated = this.updated;
        copy.artId = this.artId;
        copy.songcount = this.songcount;
        copy.genre = this.genre;
        copy.lyrics = this.lyrics;
        copy.trackNumber = this.trackNumber;
        copy.composer = this.composer;
        copy.mimeType = this.mimeType;
        copy.bitrate = this.bitrate;
        copy.albumArtist = this.albumArtist;
        copy.year = this.year;
        copy.dateAdded = this.dateAdded;
        copy.ids = this.ids;
        copy.iconPath = this.iconPath;
        copy.isVideo = this.isVideo;
        return copy;
    }

    // Method to retrieve the thumbnail
    public Bitmap getThumbnail() {
        return BitmapUtils.getSongThumbnailFromFile(path);
    }

    @Override
    public String toString() {
        return String.format(Locale.getDefault(), "SongItem{id='%s', title='%s', artist='%s', album='%s', duration=%d, isVideo=%b}",
							 id, title, artist, album, duration, isVideo);
    }
}
