package com.alexa.alexa.menu;

import android.content.DialogInterface;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.VideoFilePickerActivity;

public class VideoFilePickerDialog extends MDialog {
    private VideoFilePickerActivity activity;
    private int currentSortOption;

    public VideoFilePickerDialog(VideoFilePickerActivity activity) {
        super(activity, R.layout.dlg_video_picker_options);
        this.activity = activity;
        this.currentSortOption = activity.getCurrentSortOption();
        init();
    }

    void init() {
        // Initialize existing options
        setClickable(R.id.video_options_play);
        setClickable(R.id.video_options_share);
        setClickable(R.id.video_options_delete);
        setClickable(R.id.video_options_details);

        // Initialize sort options
        setupSortOptions();
    }

    private void setupSortOptions() {
        RadioGroup sortGroup = findViewById(R.id.video_sort_group);

        if (sortGroup != null) {
            // Define sort options
            String[] sortOptions = {
                "Name (A-Z)",
                "Name (Z-A)",
                "Newest",
                "Oldest",
                "Largest", 
                "Smallest",
                "Longest",
                "Shortest"
            };

            int[] sortIds = {
                R.id.menu_sort_name_asc,
                R.id.menu_sort_name_desc,
                R.id.menu_sort_date_desc,
                R.id.menu_sort_date_asc,
                R.id.menu_sort_size_desc,
                R.id.menu_sort_size_asc,
                R.id.menu_sort_duration_desc,
                R.id.menu_sort_duration_asc
            };

            // Add sort options as RadioButtons
            for (int i = 0; i < sortOptions.length; i++) {
                RadioButton radioButton = (RadioButton) LayoutInflater.from(activity)
                    .inflate(R.layout.radio_button, sortGroup, false);
                radioButton.setText(sortOptions[i]);
                radioButton.setId(sortIds[i]);
                sortGroup.addView(radioButton);
            }

            // Set current selection from SharedPreferences
            sortGroup.check(currentSortOption);

            // Handle sort option selection
            sortGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
					@Override
					public void onCheckedChanged(RadioGroup group, int checkedId) {
						currentSortOption = checkedId;
						activity.setSortOption(checkedId);
						dismiss();
					}
				});
        }
    }

    @Override
    public void onShow(DialogInterface dialog) {
        getWindow().setGravity(Gravity.RIGHT | Gravity.TOP);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.video_options_play:
                activity.playSelectedVideo();
                break;
            case R.id.video_options_share:
                activity.shareSelectedVideo();
                break;
            case R.id.video_options_delete:
                activity.deleteSelectedVideo();
                break;
            case R.id.video_options_details:
                activity.showVideoDetails();
                break;
        }
        dismiss();
    }
}
