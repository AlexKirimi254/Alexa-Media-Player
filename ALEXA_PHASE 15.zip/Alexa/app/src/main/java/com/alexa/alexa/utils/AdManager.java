/*package com.alexa.alexa.utils;
/*
import android.app.Activity;
import android.util.Log;
import android.view.ViewGroup;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxError;

import com.applovin.mediation.ads.MaxInterstitialAd;
import com.alexa.alexa.R;
import com.applovin.mediation.ads.MaxAdView;

public class AdManager {
    private static AdManager instance;
    private MaxInterstitialAd interstitialAd;
    private Activity activity;
    private boolean isInterstitialLoaded = false;

    private AdManager() {}

    public static AdManager getInstance() {
        if (instance == null) {
            instance = new AdManager();
        }
        return instance;
    }

    public void initialize(Activity activity) {
        this.activity = activity;
    }

    public void loadBannerAd(ViewGroup bannerContainer) {
        if (bannerContainer == null || activity == null) {
            Log.e("AdManager", "Banner container or activity is null");
            return;
        }

        MaxAdView adView = new MaxAdView("YOUR_BANNER_AD_UNIT_ID", activity);
      /*  adView.setListener(new MaxAdListener() {
				@Override
				public void onAdLoaded(MaxAd ad) {
					Log.d("AdManager", "Banner ad loaded");
				}
				@Override
				public void onAdDisplayed(MaxAd ad) {}
				@Override
				public void onAdHidden(MaxAd ad) {}
				@Override
				public void onAdClicked(MaxAd ad) {}
				@Override
				public void onAdLoadFailed(String adUnitId, MaxError error) {
					Log.e("AdManager", "Banner ad failed to load: " + error.getMessage());
				}
				@Override
				public void onAdDisplayFailed(MaxAd ad, MaxError error) {}
			});
*
        int width = ViewGroup.LayoutParams.MATCH_PARENT;
        int heightPx = activity.getResources().getDimensionPixelSize(R.dimen.border_width_bw2);
        adView.setLayoutParams(new ViewGroup.LayoutParams(width, heightPx));
        bannerContainer.addView(adView);
        adView.loadAd();
    }

    public void loadInterstitialAd() {
        if (activity == null) {
            Log.e("AdManager", "Activity is null, cannot load interstitial");
            return;
        }

        interstitialAd = new MaxInterstitialAd("YOUR_INTERSTITIAL_AD_UNIT_ID", activity);
        interstitialAd.setListener(new MaxAdListener() {
				@Override
				public void onAdLoaded(MaxAd ad) {
					isInterstitialLoaded = true;
					Log.d("AdManager", "Interstitial ad loaded");
				}
				@Override
				public void onAdDisplayed(MaxAd ad) {
					isInterstitialLoaded = false;
				}
				@Override
				public void onAdHidden(MaxAd ad) {
					loadInterstitialAd(); // Preload next ad
				}
				@Override
				public void onAdClicked(MaxAd ad) {}
				@Override
				public void onAdLoadFailed(String adUnitId, MaxError error) {
					isInterstitialLoaded = false;
					Log.e("AdManager", "Interstitial ad failed to load: " + error.getMessage());
				}
				@Override
				public void onAdDisplayFailed(MaxAd ad, MaxError error) {
					isInterstitialLoaded = false;
					loadInterstitialAd();
				}
			});
        interstitialAd.loadAd();
    }

    public void showInterstitialAd(Activity activity) {
        if (isInterstitialLoaded && interstitialAd != null && interstitialAd.isReady()) {
            interstitialAd.showAd();
        } else {
            Log.d("AdManager", "Interstitial ad not ready, loading new one");
            loadInterstitialAd();
        }
    }
}*/
