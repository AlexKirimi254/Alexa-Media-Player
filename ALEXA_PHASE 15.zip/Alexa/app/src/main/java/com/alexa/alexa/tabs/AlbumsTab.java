package com.alexa.alexa.tabs;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activity.AlbumDetailsActivity;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.AlbumsListAdaptor;
import com.alexa.alexa.models.AlbumItem;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.view.tabview.Tab;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AlbumsTab extends Tab {
    private MainActivity act;
    private View root;
    private RecyclerView recyclerView;
    private AlbumsListAdaptor adapter;
    private List<AlbumItem> albumList;
	private static final String PREFS_NAME = "AppPrefs";
    private static final String GRID_SIZE_KEY = "grid_size";
	private int gridSize = 2;
    public AlbumsTab(MainActivity act) {
        this.act = act;
        root = LayoutInflater.from(act).inflate(R.layout.default_recyclerview, null, false);
        recyclerView = root.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(act));

        // Initialize album list and adapter
        albumList = new ArrayList<>();
        adapter = new AlbumsListAdaptor(act, albumList);

        // Set adapter and item click listener
        recyclerView.setAdapter(adapter);
		
		SharedPreferences prefs = act.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gridSize = prefs.getInt(GRID_SIZE_KEY, 1); // Default to 2 columns
		// Default sort order

        setGridSize(gridSize);
		
		
        adapter.setOnItemClickListener(new AlbumsListAdaptor.OnItemClickListener() {
                @Override
                public void onItemClick(AlbumItem selectedAlbum) {
                    openAlbumDetails(selectedAlbum);
                }
            });
    }
	public void setGridSize(int size) {
        gridSize = size;
        recyclerView.setLayoutManager(new GridLayoutManager(act, gridSize));
        adapter.notifyDataSetChanged();

        // Save grid size to SharedPreferences
        SharedPreferences prefs = act.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(GRID_SIZE_KEY, gridSize).apply();
    }

    public int getGridSize() {
        return gridSize;
    }

	
    private void openAlbumDetails(AlbumItem selectedAlbum) {
        Intent intent = new Intent(act, AlbumDetailsActivity.class);
        intent.putExtra("albumName", selectedAlbum.getAlbumName());
        intent.putExtra("song_count", selectedAlbum.getSongCount());
        intent.putExtra("album_count", selectedAlbum.getAlbumCount());
        intent.putExtra("artist_count", selectedAlbum.getArtistCount()); // Pass artist count
        intent.putParcelableArrayListExtra("songList", new ArrayList<>(selectedAlbum.getSongList()));
        act.startActivity(intent);
    }

    public void update(List<SongItem> songList) {
        HashMap<String, List<SongItem>> albumMap = new HashMap<>();

        for (SongItem song : songList) {
            String albumName = song.getAlbum();
            albumMap.putIfAbsent(albumName, new ArrayList<>());
            albumMap.get(albumName).add(song);
        }

        albumList.clear();
        for (String albumName : albumMap.keySet()) {
            List<SongItem> songsInAlbum = albumMap.get(albumName);
            int thumbnailResId = R.drawable.cover_f;  // You can set a default thumbnail or load dynamically
            albumList.add(new AlbumItem(albumName, songsInAlbum, thumbnailResId));
        }

        adapter.update(albumList);
    }

    @Override
    public View getView() {
        return root;
    }

    @Override
    public void onApplyTheme(ThemeManager.Theme theme) {
        adapter.setTheme(theme);
    }
}

