/*
 * Copyright (C) 2012 Andrew Neal Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.alexa.alexa.helper;

import android.provider.MediaStore;

public final class SortOrder {

    /**
     * This class should not be instantiated.
     */
    private SortOrder() {
    }

    /**
     * Artist sort order entries.
     */
    public interface ArtistSortOrder {
        String ARTIST_A_Z = MediaStore.Audio.Artists.DEFAULT_SORT_ORDER;
        String ARTIST_Z_A = ARTIST_A_Z + " DESC";
        String ARTIST_NUMBER_OF_SONGS = MediaStore.Audio.Artists.NUMBER_OF_TRACKS + " DESC";
        String ARTIST_NUMBER_OF_ALBUMS = MediaStore.Audio.Artists.NUMBER_OF_ALBUMS + " DESC";
    }

    /**
     * Album sort order entries.
     */
    public interface AlbumSortOrder {
        String ALBUM_A_Z = MediaStore.Audio.Albums.DEFAULT_SORT_ORDER;
        String ALBUM_Z_A = ALBUM_A_Z + " DESC";
        String ALBUM_NUMBER_OF_SONGS = MediaStore.Audio.Albums.NUMBER_OF_SONGS + " DESC";
        String ALBUM_ARTIST = MediaStore.Audio.Artists.DEFAULT_SORT_ORDER + ", " + MediaStore.Audio.Albums.DEFAULT_SORT_ORDER;
        String ALBUM_YEAR = MediaStore.Audio.Media.YEAR + " DESC";
        String ALBUM_YEAR_ASC = MediaStore.Audio.Media.YEAR + " ASC";
    }

    /**
     * Song sort order entries.
     */
    public interface SongSortOrder {
        String SONG_A_Z = MediaStore.Audio.Media.DEFAULT_SORT_ORDER;
        String SONG_Z_A = SONG_A_Z + " DESC";
        String SONG_ARTIST = MediaStore.Audio.Artists.DEFAULT_SORT_ORDER;
        String SONG_ALBUM = MediaStore.Audio.Albums.DEFAULT_SORT_ORDER;
        String SONG_YEAR = MediaStore.Audio.Media.YEAR + " DESC";
        String SONG_YEAR_ASC = MediaStore.Audio.Media.YEAR + " ASC";
        String SONG_DURATION = MediaStore.Audio.Media.DURATION + " DESC";
        String SONG_DURATION_ASC = MediaStore.Audio.Media.DURATION + " ASC";
        String SONG_DATE = MediaStore.Audio.Media.DATE_ADDED + " DESC";
        String SONG_DATE_ASC = MediaStore.Audio.Media.DATE_ADDED + " ASC";
        String SONG_GENRE = MediaStore.Audio.Genres.DEFAULT_SORT_ORDER;
    }

    /**
     * Album song sort order entries.
     */
    public interface AlbumSongSortOrder {
        String SONG_A_Z = MediaStore.Audio.Media.DEFAULT_SORT_ORDER;
        String SONG_Z_A = SONG_A_Z + " DESC";
        String SONG_TRACK_LIST = MediaStore.Audio.Media.TRACK + ", " + MediaStore.Audio.Media.DEFAULT_SORT_ORDER;
        String SONG_DURATION = SongSortOrder.SONG_DURATION;
    }

    /**
     * Artist song sort order entries.
     */
    public interface ArtistSongSortOrder {
        String SONG_A_Z = MediaStore.Audio.Media.DEFAULT_SORT_ORDER;
        String SONG_Z_A = SONG_A_Z + " DESC";
        String SONG_ALBUM = MediaStore.Audio.Media.ALBUM;
        String SONG_YEAR = MediaStore.Audio.Media.YEAR + " DESC";
        String SONG_YEAR_ASC = MediaStore.Audio.Media.YEAR + " ASC";
        String SONG_DURATION = MediaStore.Audio.Media.DURATION + " DESC";
        String SONG_DURATION_ASC = MediaStore.Audio.Media.DURATION + " ASC";
        String SONG_DATE = MediaStore.Audio.Media.DATE_ADDED + " DESC";
        String SONG_DATE_ASC = MediaStore.Audio.Media.DATE_ADDED + " ASC";
    }

    /**
     * Artist album sort order entries.
     */
    public interface ArtistAlbumSortOrder {
        String ALBUM_A_Z = MediaStore.Audio.Albums.DEFAULT_SORT_ORDER;
        String ALBUM_Z_A = ALBUM_A_Z + " DESC";
        String ALBUM_YEAR = MediaStore.Audio.Media.YEAR + " DESC";
        String ALBUM_YEAR_ASC = MediaStore.Audio.Media.YEAR + " ASC";
    }

    /**
     * Genre sort order entries.
     */
    public interface GenreSortOrder {
        String GENRE_A_Z = MediaStore.Audio.Genres.DEFAULT_SORT_ORDER;
        String GENRE_Z_A = GENRE_A_Z + " DESC";
    }

    /**
     * Retrieves the appropriate sort order based on the provided type and direction.
     * @param sortType The type of sort (e.g., "newest", "oldest", "artist").
     * @param isAscending Whether the sort should be ascending.
     * @return The corresponding SQL sort order.
     */
    public static String getSortOrder(String sortType, boolean isAscending) {
        switch (sortType) {
            case "newest":
                return isAscending ? SongSortOrder.SONG_DATE_ASC : SongSortOrder.SONG_DATE;
            case "oldest":
                return isAscending ? SongSortOrder.SONG_DATE : SongSortOrder.SONG_DATE_ASC;
            case "artist":
                return isAscending ? ArtistSortOrder.ARTIST_A_Z : ArtistSortOrder.ARTIST_Z_A;
            case "album":
                return isAscending ? AlbumSortOrder.ALBUM_A_Z : AlbumSortOrder.ALBUM_Z_A;
            case "length":
                return isAscending ? SongSortOrder.SONG_DURATION_ASC : SongSortOrder.SONG_DURATION;
            case "year":
                return isAscending ? SongSortOrder.SONG_YEAR_ASC : SongSortOrder.SONG_YEAR;
            case "genre":
                return isAscending ? GenreSortOrder.GENRE_A_Z : GenreSortOrder.GENRE_Z_A;
            default:
                throw new IllegalArgumentException("Invalid sort type: " + sortType);
        }
    }

    /**
     * Applies sorting based on the type and direction to a query.
     * @param sortType The type of sort to apply.
     * @param isAscending Whether the sort should be ascending.
     * @return The SQL ORDER BY clause for the query.
     */
    public static String applySortOrder(String sortType, boolean isAscending) {
        return getSortOrder(sortType, isAscending);
    }
}



