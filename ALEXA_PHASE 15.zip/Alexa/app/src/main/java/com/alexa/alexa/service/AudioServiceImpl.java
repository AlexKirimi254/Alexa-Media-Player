package com.alexa.alexa.service;

import android.content.ComponentName;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.PowerManager;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.library.SongLibrary;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.utils.SPrefs;
import com.alexa.alexa.utils.Utils;
import java.util.ArrayList;
import java.util.List;

class AudioServiceImpl
 {
    static final String CMD_START = "sleepchild.aupod.service.cmd.start_service";
    static final String CMD_END = "sleepchild.aupod.service.cmd.end.exit";
    static final String CMD_PLAY = "sleepchild.aupod.service.CMD_PLAY";
    static final String CMD_PAUSE = "sleepchild.aupod.service.CMD_PAUSE";
    static final String CMD_PLAY_NEXT = "sleepchild.aupod.service.CMD_PLAY_NEXT";
    static final String CMD_PLAY_PREV = "sleepchild.aupod.service.CMD_PLAY_PREV";
	 final int NID = 5374;
    //
    
    SPrefs prefs;


     boolean songset = false;
    boolean recieversRegistered = false;

    
	
     final AudioService service;
     MediaPlayer mediaPlayer;
     List<SongItem> songlist = new ArrayList<>();
     SongItem currentSong;
	 Handler handle = new Handler();
    AudioServiceImpl(AudioService service) {
        this.service = service;
    }

    void init() {
		mediaPlayer = new MediaPlayer();
		mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
				@Override
				public void onCompletion(MediaPlayer mp) {
					playNext();
				}
			});
		// Additional initialization logic
	}

    void handleCommand(String cmd) {
        switch (cmd) {
            case CMD_START:
                startService();
                break;
            case CMD_END:
                stopService();
                break;
            case CMD_PLAY:
                resume();
                break;
            case CMD_PAUSE:
                pause();
                break;
            case CMD_PLAY_NEXT:
                playNext();
                break;
            case CMD_PLAY_PREV:
                playPrev();
                break;
        }
    }

    void cleanup() {
        stop();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    void startService() {
        // Logic for starting the service
    }

    void stopService() {
        stop();
        service.stopSelf();
    }

    void playSong(SongItem song) {
        if (song == null) return;
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(song.getPath());
            mediaPlayer.prepare();
            currentSong = song;
            resume();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void pause() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    void resume() {
        if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    boolean playNext() {
        // Logic for playing next song
        return true;
    }

    void playPrev() {
        // Logic for playing previous song
    }

    boolean isPlaying() {
        return mediaPlayer.isPlaying();
    }

    SongItem getCurrentSong() {
        return currentSong;
    }

    void stop() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
        }
    }
	 SongLibrary.ResultCallback getsonglistresult = new SongLibrary.ResultCallback(){
        @Override
        public void onResult(final Object result){
            handle.post(new Runnable(){
					public void run(){
						List<SongItem> sl = (List<SongItem>) result;
						_ongetsongslist(sl);// delegate because 'this' refers to sth else in here.
					}
				});
        }
    };
	
	 void _ongetsongslist(List<SongItem> sl){
        boolean currentSongUpdated = false;
        boolean listChanged=false;

        if(songlist!=null){
            if(sl.containsAll(songlist) && songlist.containsAll(sl)){
                //
            }else{
                songlist = sl;
                listChanged = true;
            }
        }else{
            songlist = sl;
        }

        if(currentSong!=null){
            //if(listChanged){
			for(SongItem si : songlist){
				if(si.path.equalsIgnoreCase(currentSong.path)){
					currentSong = si;
					currentSongUpdated = true;
					break;
				}
			}
            //}

        }else{
            String p = prefs.getLastPath();
            if(Utils.exists(p)){
                for(SongItem si : songlist){
                    if(si.path.equalsIgnoreCase(p)){
                        currentSong = si;
                        break;
                    }
                }
                if(currentSong==null && !songlist.isEmpty()){
                    currentSong = songlist.get(0);
                }
            }else{
                if(!songlist.isEmpty()){
                    currentSong = songlist.get(0);
                }
            }
            //
        }

        if(!songset){
            if(currentSong!=null){
               // setSong(currentSong);
                //mPlayer.start();
                //mPlayer.stop();
            }
        }

        if(songlist!=null){
            APEvents.getInstance().postSongsListUpdated(songlist);
        }
        //
        if(currentSong!=null){
            APEvents.getInstance().postSongChangeEvent(currentSong);
        }
    }
	
}
