package com.alexa.alexa.activity;

import android.content.Context;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;
import com.alexa.alexa.R;

public class VideoOptionsMenu {
    private Context context;
    private VideoPlayerActivity videoPlayer;

    public VideoOptionsMenu(Context context, VideoPlayerActivity videoPlayer) {
        this.context = context;
        this.videoPlayer = videoPlayer;
    }

    public void showMenu(View view) {
        PopupMenu popup = new PopupMenu(context, view);
        popup.getMenuInflater().inflate(R.menu.video_options_menu, popup.getMenu());

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_lock:
                        Toast.makeText(context, "Lock selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_sleep_timer:
                        Toast.makeText(context, "Sleep timer selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_playback_speed:
                        Toast.makeText(context, "Playback speed selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_jump_to_time:
                        Toast.makeText(context, "Jump to Time selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_equalizer:
                        Toast.makeText(context, "Equalizer selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_play_as_audio:
                        videoPlayer.togglePlaybackMode();
                        Toast.makeText(context, "Play as audio selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_popup_player:
                        Toast.makeText(context, "Pop-Up player selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_repeat_mode:
                        Toast.makeText(context, "Repeat mode selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_video_info:
                        Toast.makeText(context, "Video information selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_bookmarks:
                        Toast.makeText(context, "Bookmarks selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_a_b_repeat:
                        Toast.makeText(context, "A-B repeat selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_save_playlist:
                        Toast.makeText(context, "Save Playlist selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_control_settings:
                        Toast.makeText(context, "Control settings selected", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.action_video_tips:
                        Toast.makeText(context, "Video player tips selected", Toast.LENGTH_SHORT).show();
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.show();
    }
}
