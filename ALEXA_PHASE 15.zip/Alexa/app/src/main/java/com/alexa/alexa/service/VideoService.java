package com.alexa.alexa.service;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.Nullable;
import com.alexa.alexa.models.VideoItem;

public class VideoService extends android.app.Service {
    private static final String TAG = "VideoService";
    private final IBinder binder = new LocalBinder();
    private MediaPlayer mediaPlayer;
    private VideoItem currentVideo;
    private boolean isPrepared = false;

    public class LocalBinder extends Binder {
        public VideoService getService() {
            return VideoService.this;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mediaPlayer = new MediaPlayer();
        setupMediaPlayerListeners();
    }

    private void setupMediaPlayerListeners() {
        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
				@Override
				public void onPrepared(MediaPlayer mp) {
					isPrepared = true;
					mp.start();
					Log.d(TAG, "Video playback started: " + currentVideo.getTitle());
				}
			});

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
				@Override
				public void onCompletion(MediaPlayer mp) {
					Log.d(TAG, "Video playback completed: " + currentVideo.getTitle());
					stopSelf();
				}
			});

        mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
				@Override
				public boolean onError(MediaPlayer mp, int what, int extra) {
					Log.e(TAG, "Video playback error: " + what + ", " + extra);
					stopSelf();
					return true;
				}
			});
    }

    public void playVideo(Context context, VideoItem video) {
        try {
            if (currentVideo != null && currentVideo.getPath().equals(video.getPath()) && isPrepared) {
                mediaPlayer.start();
                return;
            }

            currentVideo = video;
            isPrepared = false;

            mediaPlayer.reset();
            mediaPlayer.setDataSource(context, Uri.parse(video.getPath()));
            mediaPlayer.prepareAsync();

            // Notify system to keep service running
            startService(new Intent(context, VideoService.class));

        } catch (Exception e) {
            Log.e(TAG, "Error playing video: " + video.getTitle(), e);
            stopSelf();
        }
    }

    public void pauseVideo() {
        if (isPrepared && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    public void resumeVideo() {
        if (isPrepared && !mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    public void seekTo(int position) {
        if (isPrepared) {
            mediaPlayer.seekTo(position);
        }
    }

    public int getCurrentPosition() {
        return isPrepared ? mediaPlayer.getCurrentPosition() : 0;
    }

    public int getDuration() {
        return isPrepared ? mediaPlayer.getDuration() : 0;
    }

    public boolean isPlaying() {
        return isPrepared && mediaPlayer.isPlaying();
    }

    public VideoItem getCurrentVideo() {
        return currentVideo;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        Log.d(TAG, "VideoService destroyed");
    }

    // Singleton pattern implementation
    private static volatile VideoService instance;

    public static VideoService getInstance() {
        if (instance == null) {
            synchronized (VideoService.class) {
                if (instance == null) {
                    instance = new VideoService();
                }
            }
        }
        return instance;
    }

    private VideoService() {
        // Private constructor to enforce singleton
    }
}
