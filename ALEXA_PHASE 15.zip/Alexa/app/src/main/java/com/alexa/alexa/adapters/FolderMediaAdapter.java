package com.alexa.alexa.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.media.ThumbnailUtils;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;
import java.io.File;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class FolderMediaAdapter extends BaseAdapter {
    private Context context;
    private List<Object> items;
    private LayoutInflater inflater;
    private ConcurrentHashMap<String, Bitmap> thumbnailCache;

    public FolderMediaAdapter(Context context, List<Object> items) {
        this.context = context;
        this.items = items;
        this.inflater = LayoutInflater.from(context);
        this.thumbnailCache = new ConcurrentHashMap<>();
    }

    @Override
    public int getCount() {
        return items != null ? items.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return items != null && position < items.size() ? items.get(position) : null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_folder_media, parent, false);
            holder = new ViewHolder();
            holder.icon = convertView.findViewById(R.id.media_icon);
            holder.title = convertView.findViewById(R.id.media_title);
            holder.subtitle = convertView.findViewById(R.id.media_subtitle);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Object item = getItem(position);
        if (item instanceof File) {
            File file = (File) item;
            String name = file.getName();
            if ("..".equals(name)) {
                holder.icon.setImageResource(R.drawable.ic_prev);
                holder.title.setText("Parent Directory");
                holder.subtitle.setText("");
            } else {
                holder.icon.setImageResource(R.drawable.ic_folder);
                holder.title.setText(name);
                holder.subtitle.setText("Folder");
            }
        } else if (item instanceof SongItem) {
            SongItem song = (SongItem) item;
            holder.title.setText(song.getTitle());
            if (song.isVideo()) {
                holder.subtitle.setText("Video • " + formatDuration(song.getDuration()));
                loadThumbnail(holder.icon, song.getPath(), true);
            } else {
                holder.subtitle.setText(song.getArtist() + " • " + formatDuration(song.getDuration()));
                loadThumbnail(holder.icon, song.getPath(), false);
            }
        }

        return convertView;
    }

    private void loadThumbnail(ImageView imageView, String filePath, boolean isVideo) {
        // Check cache first
        Bitmap cachedBitmap = thumbnailCache.get(filePath);
        if (cachedBitmap != null) {
            imageView.setImageBitmap(cachedBitmap);
            return;
        }

        // Set placeholder
        imageView.setImageResource(isVideo ? R.drawable.ic_menu_home : R.drawable.ic_menu_songs);

        // Load thumbnail asynchronously
        new ThumbnailLoaderTask(imageView, filePath, isVideo).execute();
    }

    private class ThumbnailLoaderTask extends AsyncTask<Void, Void, Bitmap> {
        private ImageView imageView;
        private String filePath;
        private boolean isVideo;
        private String tag;

        ThumbnailLoaderTask(ImageView imageView, String filePath, boolean isVideo) {
            this.imageView = imageView;
            this.filePath = filePath;
            this.isVideo = isVideo;
            this.tag = filePath; // Use file path as tag to verify view reuse
            imageView.setTag(tag);
        }

        @Override
        protected Bitmap doInBackground(Void... params) {
            try {
                if (isVideo) {
                    // Generate video thumbnail
                    return ThumbnailUtils.createVideoThumbnail(filePath, MediaStore.Images.Thumbnails.MINI_KIND);
                } else {
                    // Extract audio album art
                    MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                    try {
                        retriever.setDataSource(filePath);
                        byte[] artBytes = retriever.getEmbeddedPicture();
                        if (artBytes != null) {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.length);
                            if (bitmap != null) {
                                // Resize to thumbnail size
                                return Bitmap.createScaledBitmap(bitmap, 48, 48, true);
                            }
                        }
                    } finally {
                        retriever.release();
                    }
                }
                return null; // No thumbnail available
            } catch (Exception e) {
                return null; // Handle errors gracefully
            }
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null && imageView.getTag().equals(tag)) {
                thumbnailCache.put(filePath, bitmap);
                imageView.setImageBitmap(bitmap);
            }
        }
    }

    private static class ViewHolder {
        ImageView icon;
        TextView title;
        TextView subtitle;
    }

    private String formatDuration(long duration) {
        if (duration <= 0) {
            return "Unknown";
        }
        long seconds = duration / 1000;
        long minutes = seconds / 60;
        seconds = seconds % 60;
        return String.format("%d:%02d", minutes, seconds);
    }
}
