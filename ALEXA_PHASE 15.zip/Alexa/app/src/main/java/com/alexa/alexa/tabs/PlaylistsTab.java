package com.alexa.alexa.tabs;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.activity.PlaylistDetailsActivity;
import com.alexa.alexa.adapters.PlaylistAdapter;
import com.alexa.alexa.manager.PlaylistManager;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.view.tabview.Tab;
import java.util.ArrayList;
import java.util.List;

/**
 * Tab class to display and manage playlists using RecyclerView.
 */
public class PlaylistsTab extends Tab {

    private MainActivity ctx;
    private View root;
    private RecyclerView recyclerView;
    private List<Playlist> playlists;
    private PlaylistAdapter playlistAdapter;
    private PlaylistManager playlistManager;
	private static final String PREFS_NAME = "AppPrefs";
    private static final String GRID_SIZE_KEY = "grid_size";
	private int gridSize = 2;
	
    public PlaylistsTab(MainActivity act) {
        this.ctx = act;
        root = LayoutInflater.from(act).inflate(R.layout.default_recyclerview, null, false);
        recyclerView = root.findViewById(R.id.recycler_view);

        playlistManager = PlaylistManager.getInstance();
        playlists = playlistManager.getPlaylists();

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(ctx));
        playlistAdapter = new PlaylistAdapter(ctx, playlists, new PlaylistAdapter.OnItemClickListener() {
				@Override
				public void onItemClick(Playlist playlist) {
					if (playlist.getSongs() == null || playlist.getSongs().isEmpty()) {
						Toast.makeText(ctx, "This playlist has no songs.", Toast.LENGTH_SHORT).show();
					} else {
						openPlaylistActivity(playlist);
					}
				}
			});
        recyclerView.setAdapter(playlistAdapter);
		SharedPreferences prefs = act.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gridSize = prefs.getInt(GRID_SIZE_KEY, 1); // Default to 2 columns
		// Default sort order

        setGridSize(gridSize);
		
    }

    @Override
    public View getView() {
        return root;
    }
	public void setGridSize(int size) {
        gridSize = size;
        recyclerView.setLayoutManager(new GridLayoutManager(ctx, gridSize));
        playlistAdapter.notifyDataSetChanged();

        // Save grid size to SharedPreferences
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(GRID_SIZE_KEY, gridSize).apply();
    }

    public int getGridSize() {
        return gridSize;
    }
	
    private void openPlaylistActivity(Playlist selectedPlaylist) {
        Intent intent = new Intent(ctx, PlaylistDetailsActivity.class);
        intent.putExtra("PLAYLIST_NAME", selectedPlaylist.getName());
        intent.putParcelableArrayListExtra("PLAYLIST_SONGS", new ArrayList<>(selectedPlaylist.getSongs()));
        ctx.startActivity(intent);
    }

    public void refreshData() {
        playlists.clear();
        playlists.addAll(playlistManager.getPlaylists());
        playlistAdapter.notifyDataSetChanged();
    }
}
