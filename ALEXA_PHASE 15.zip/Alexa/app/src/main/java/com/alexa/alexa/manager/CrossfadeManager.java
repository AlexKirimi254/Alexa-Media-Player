package com.alexa.alexa.manager;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import com.alexa.alexa.models.CrossfadeConfig;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.utils.Utils;

public class CrossfadeManager {
    private static final int CROSSFADE_START_OFFSET = 30000; // 30 seconds before end
    private final Context context;
    private final CrossfadeConfig config;
    private final Handler handler;
    private MediaPlayer outgoingPlayer;
    private MediaPlayer incomingPlayer;
    private boolean isCrossfading = false;
    private Runnable crossfadeRunnable;

    public CrossfadeManager(Context context, CrossfadeConfig config) {
        this.context = context;
        this.config = config;
        this.handler = new Handler();
    }

    public void startCrossfade(MediaPlayer currentPlayer, SongItem nextSong) {
        if (isCrossfading || nextSong == null) return;

        try {
            isCrossfading = true;
            outgoingPlayer = currentPlayer;
            incomingPlayer = new MediaPlayer();
            incomingPlayer.setAudioStreamType(3); // STREAM_MUSIC
            incomingPlayer.setDataSource(nextSong.path);
            incomingPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
					@Override
					public void onPrepared(MediaPlayer mp) {
						beginCrossfadeProcess();
					}
				});
            incomingPlayer.prepareAsync();
        } catch (Exception e) {
         //   Utils.log("Crossfade error: " + e.getMessage());
            cleanup();
        }
    }

    private void beginCrossfadeProcess() {
        if (outgoingPlayer == null || incomingPlayer == null) {
            cleanup();
            return;
        }

        incomingPlayer.start();
        incomingPlayer.setVolume(0f, 0f);

        final int steps = 50;
        final long interval = config.getDuration() / steps;
        final float volumeStep = 1.0f / steps;

        crossfadeRunnable = new Runnable() {
            private int currentStep = 0;

            @Override
            public void run() {
                if (!isCrossfading || outgoingPlayer == null || incomingPlayer == null) {
                    cleanup();
                    return;
                }

                float outgoingVolume = 1.0f - (volumeStep * currentStep);
                float incomingVolume = volumeStep * currentStep;

                outgoingPlayer.setVolume(outgoingVolume, outgoingVolume);
                incomingPlayer.setVolume(incomingVolume, incomingVolume);

                currentStep++;
                if (currentStep <= steps) {
                    handler.postDelayed(this, interval);
                } else {
                    completeCrossfade();
                }
            }
        };
        handler.post(crossfadeRunnable);
    }

    private void completeCrossfade() {
        if (outgoingPlayer != null) {
            outgoingPlayer.stop();
            outgoingPlayer.release();
        }
        outgoingPlayer = null;
        isCrossfading = false;
    }

    public void cleanup() {
        handler.removeCallbacks(crossfadeRunnable);
        if (incomingPlayer != null) {
            incomingPlayer.release();
            incomingPlayer = null;
        }
        isCrossfading = false;
    }

    public boolean isCrossfading() {
        return isCrossfading;
    }

    public void previewCrossfade(MediaPlayer currentPlayer, SongItem nextSong) {
        startCrossfade(currentPlayer, nextSong);
    }
}
