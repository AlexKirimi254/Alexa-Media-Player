package com.alexa.alexa;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.support.v4.media.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.IOException;
import java.util.List;

public class AudioService extends Service {

    public static final String CHANNEL_ID = "ALEXA_AUDIO_CHANNEL";
    public static final int NOTIFICATION_ID = 1001;

    private final IBinder binder = new AudioServiceBinder();

    private MediaPlayer mediaPlayer;
    private MediaSessionCompat mediaSession;
    private List<String> playlist;
    private int currentTrackIndex = 0;

    public class AudioServiceBinder extends Binder {
        public AudioService getService() {
            return AudioService.this;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        initMediaSession();
        createNotificationChannel();
    }

    private void initMediaSession() {
        mediaSession = new MediaSessionCompat(this, "AudioServiceSession");
        mediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS |
                              MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
        updatePlaybackState(PlaybackStateCompat.STATE_STOPPED);
    }

    public void setPlaylist(List<String> audioPaths) {
        this.playlist = audioPaths;
        this.currentTrackIndex = 0;
    }

    public void play() {
        if (playlist == null || playlist.isEmpty()) {
            stopSelf();
            return;
        }

        String path = playlist.get(currentTrackIndex);

        if (mediaPlayer != null) {
            mediaPlayer.release();
        }

        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(path);
            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            mediaPlayer.setOnPreparedListener(mp -> {
                mp.start();
                startForeground(NOTIFICATION_ID, buildNotification("Playing"));
                updatePlaybackState(PlaybackStateCompat.STATE_PLAYING);
            });
            mediaPlayer.setOnCompletionListener(mp -> {
                playNext();
            });
            mediaPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void pause() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            updatePlaybackState(PlaybackStateCompat.STATE_PAUSED);
            startForeground(NOTIFICATION_ID, buildNotification("Paused"));
        }
    }

    public void stop() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        updatePlaybackState(PlaybackStateCompat.STATE_STOPPED);
        stopForeground(true);
        stopSelf();
    }

    public void playNext() {
        if (playlist != null && !playlist.isEmpty()) {
            currentTrackIndex = (currentTrackIndex + 1) % playlist.size();
            play();
        }
    }

    public void playPrevious() {
        if (playlist != null && !playlist.isEmpty()) {
            currentTrackIndex = (currentTrackIndex - 1 + playlist.size()) % playlist.size();
            play();
        }
    }

    private Notification buildNotification(String status) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Alexa Music Player")
                .setContentText(status)
                .setSmallIcon(R.drawable.ic_music_note)
                .setContentIntent(contentIntent)
                .addAction(generateAction(R.drawable.ic_skip_previous, "Previous", "ACTION_PREVIOUS"))
                .addAction(generateAction(R.drawable.ic_pause, "Pause", "ACTION_PAUSE"))
                .addAction(generateAction(R.drawable.ic_skip_next, "Next", "ACTION_NEXT"))
                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken()))
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(status.equals("Playing"));

        return builder.build();
    }

    private NotificationCompat.Action generateAction(int icon, String title, String intentAction) {
        Intent intent = new Intent(this, NotificationActionReceiver.class);
        intent.setAction(intentAction);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent,
                PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Action.Builder(icon, title, pendingIntent).build();
    }

    private void updatePlaybackState(int state) {
        PlaybackStateCompat.Builder stateBuilder = new PlaybackStateCompat.Builder()
                .setActions(PlaybackStateCompat.ACTION_PLAY |
                            PlaybackStateCompat.ACTION_PAUSE |
                            PlaybackStateCompat.ACTION_SKIP_TO_NEXT |
                            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS |
                            PlaybackStateCompat.ACTION_STOP)
                .setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1.0f);
        mediaSession.setPlaybackState(stateBuilder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Alexa Music Playback", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stop();
        if (mediaSession != null) {
            mediaSession.release();
        }
    }
}