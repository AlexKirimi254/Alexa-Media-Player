
package com.alexa.alexa.services;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.alexa.alexa.events.APEvents;
import com.alexa.alexa.model.Playlist;
import com.alexa.alexa.model.SongItem;
import com.alexa.alexa.utils.AlexaPrefs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AudioService extends Service {

    private static final String TAG = "AudioService";

    private MediaPlayer mPlayer;
    private List<SongItem> songQueue;
    private SongItem currentSong;
    private int currentSongIndex;
    private AlexaPrefs prefs;

    @Override
    public void onCreate() {
        super.onCreate();
        songQueue = new ArrayList<SongItem>();
        prefs = AlexaPrefs.getInstance(this);
        initMPlayer();
    }

    private void initMPlayer() {
        if (mPlayer == null) {
            mPlayer = new MediaPlayer();
            mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    playNext();
                }
            });
        }
    }

    public void addToQueue(Object item) {
        boolean shouldStartPlayback = songQueue.isEmpty() && !isPlaying();
        boolean newSongsAdded = false;

        if (item instanceof SongItem) {
            SongItem song = (SongItem) item;
            if (!songQueue.contains(song)) {
                songQueue.add(song);
                newSongsAdded = true;
            }
        } else if (item instanceof List<?>) {
            List<?> list = (List<?>) item;
            for (Object obj : list) {
                if (obj instanceof SongItem && !songQueue.contains(obj)) {
                    songQueue.add((SongItem) obj);
                    newSongsAdded = true;
                }
            }
        } else if (item instanceof Playlist) {
            Playlist playlist = (Playlist) item;
            for (SongItem song : playlist.getSongs()) {
                if (!songQueue.contains(song)) {
                    songQueue.add(song);
                    newSongsAdded = true;
                }
            }
        } else {
            throw new IllegalArgumentException("Unsupported parameter type for addToQueue");
        }

        if (newSongsAdded) {
            saveQueueToPreferences();
            if (shouldStartPlayback) {
                currentSongIndex = 0;
                playSong(songQueue.get(currentSongIndex));
            }
        }
    }

    public void playFromIntent(Context context, String path) {
        initMPlayer();

        if (path == null || path.trim().isEmpty()) {
            Toast.makeText(context, "No file path provided", Toast.LENGTH_SHORT).show();
            return;
        }

        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        int result = audioManager.requestAudioFocus(
            new AudioManager.OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int focusChange) {
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                        pause();
                    }
                }
            },
            AudioManager.STREAM_MUSIC,
            AudioManager.AUDIOFOCUS_GAIN
        );

        if (result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            Toast.makeText(context, "Unable to gain audio focus", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            mPlayer.stop();
            mPlayer.reset();
            mPlayer.setDataSource(path);
            mPlayer.prepare();
            mPlayer.start();

            currentSong = new SongItem();
            currentSong.path = path;
            prefs.saveLastPath(path);

            APEvents.getInstance().postSongChangeEvent(currentSong);
            APEvents.getInstance().postPlayStateEvent_start();

        } catch (IOException e) {
            Log.e(TAG, "Error playing song from intent path: " + path, e);
            Toast.makeText(context, "Unable to play file", Toast.LENGTH_SHORT).show();
        }
    }

    public void playSong(SongItem song) {
        if (song == null) return;
        try {
            mPlayer.reset();
            mPlayer.setDataSource(song.getPath());
            mPlayer.prepare();
            mPlayer.start();

            currentSong = song;
            APEvents.getInstance().postSongChangeEvent(song);
            APEvents.getInstance().postPlayStateEvent_start();

        } catch (IOException e) {
            Log.e(TAG, "Error playing song", e);
        }
    }

    public void playNext() {
        if (currentSongIndex < songQueue.size() - 1) {
            currentSongIndex++;
            playSong(songQueue.get(currentSongIndex));
        }
    }

    public void pause() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.pause();
        }
    }

    public boolean isPlaying() {
        return mPlayer != null && mPlayer.isPlaying();
    }

    private void saveQueueToPreferences() {
        // Serialize and save to preferences if needed
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
